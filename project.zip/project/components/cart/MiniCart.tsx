import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShoppingBag, Plus, Minus, X, ArrowRight } from 'lucide-react';
import { useCart } from './CartContext';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Card } from '../ui/card';

interface MiniCartProps {
  onCheckout?: () => void;
  className?: string;
}

export function MiniCart({ onCheckout, className = '' }: MiniCartProps) {
  const [isOpen, setIsOpen] = useState(false);
  const { state, updateQuantity, removeItem, openCart } = useCart();

  const formatPrice = (price: number | string) => {
    const numPrice = typeof price === 'string' ? parseFloat(price.replace('€', '')) : price;
    return `€${numPrice.toFixed(2)}`;
  };

  const getItemTotal = (price: number | string, quantity: number) => {
    const numPrice = typeof price === 'string' ? parseFloat(price.replace('€', '')) : price;
    return numPrice * quantity;
  };

  const total = state.items.reduce((sum, item) => sum + getItemTotal(item.price, item.quantity), 0);

  const handleViewCart = () => {
    setIsOpen(false);
    openCart();
  };

  const handleCheckout = () => {
    setIsOpen(false);
    onCheckout?.();
  };

  // Display only first 3 items
  const displayItems = state.items.slice(0, 3);
  const remainingItems = state.items.length - 3;

  return (
    <div className={`relative ${className}`}>
      {/* Cart Trigger */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="relative p-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl hover:bg-white/20 transition-all duration-300 group"
        aria-label="Warenkorb öffnen"
      >
        <ShoppingBag className="w-6 h-6 text-white group-hover:scale-110 transition-transform" />
        
        {/* Item Count Badge */}
        <AnimatePresence>
          {state.itemCount > 0 && (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0 }}
              className="absolute -top-2 -right-2 bg-gradient-to-r from-cyan-500 to-cyan-600 text-white text-xs font-bold rounded-full w-6 h-6 flex items-center justify-center shadow-lg"
            >
              {state.itemCount > 99 ? '99+' : state.itemCount}
            </motion.div>
          )}
        </AnimatePresence>
        
        {/* Pulse Animation */}
        {state.itemCount > 0 && (
          <motion.div
            initial={{ scale: 1, opacity: 0.7 }}
            animate={{ scale: 1.5, opacity: 0 }}
            transition={{ duration: 2, repeat: Infinity }}
            className="absolute -top-2 -right-2 bg-cyan-400 rounded-full w-6 h-6"
          />
        )}
      </button>

      {/* Mini Cart Dropdown */}
      <AnimatePresence>
        {isOpen && (
          <>
            {/* Backdrop for mobile */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/20 z-30 md:hidden"
              onClick={() => setIsOpen(false)}
            />

            {/* Dropdown */}
            <motion.div
              initial={{ opacity: 0, y: -10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.95 }}
              transition={{ type: 'spring', damping: 30, stiffness: 300 }}
              className="absolute right-0 top-full mt-2 w-80 md:w-96 z-40"
            >
              <Card className="bg-white/95 backdrop-blur-xl border border-white/20 shadow-2xl rounded-2xl overflow-hidden">
                {state.items.length === 0 ? (
                  /* Empty State */
                  <div className="p-6 text-center">
                    <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-3">
                      <ShoppingBag className="w-6 h-6 text-gray-400" />
                    </div>
                    <h3 className="font-semibold text-gray-900 mb-1">Warenkorb ist leer</h3>
                    <p className="text-sm text-gray-600">Fügen Sie Artikel hinzu, um zu beginnen</p>
                  </div>
                ) : (
                  <>
                    {/* Header */}
                    <div className="p-4 border-b border-gray-200/50 bg-gradient-to-r from-white/90 to-gray-50/90">
                      <div className="flex items-center justify-between">
                        <h3 className="font-semibold text-gray-900">
                          Warenkorb ({state.itemCount})
                        </h3>
                        <button
                          onClick={() => setIsOpen(false)}
                          className="p-1 hover:bg-gray-100 rounded-lg transition-colors"
                          aria-label="Schließen"
                        >
                          <X className="w-4 h-4 text-gray-600" />
                        </button>
                      </div>
                    </div>

                    {/* Items */}
                    <div className="max-h-64 overflow-y-auto custom-scrollbar">
                      <div className="p-4 space-y-3">
                        <AnimatePresence mode="popLayout">
                          {displayItems.map((item, index) => (
                            <motion.div
                              key={`${item.id}-${item.size}-${item.color}`}
                              initial={{ opacity: 0, x: -20 }}
                              animate={{ opacity: 1, x: 0 }}
                              exit={{ opacity: 0, x: 20, height: 0 }}
                              transition={{ delay: index * 0.05 }}
                              className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 transition-colors"
                            >
                              {/* Product Image */}
                              <div className="w-12 h-12 rounded-lg overflow-hidden bg-gray-100">
                                <img
                                  src={item.image}
                                  alt={item.name}
                                  className="w-full h-full object-cover"
                                />
                              </div>

                              {/* Product Info */}
                              <div className="flex-1 min-w-0">
                                <h4 className="text-sm font-medium text-gray-900 truncate">
                                  {item.name}
                                </h4>
                                <div className="flex items-center gap-1 mt-1">
                                  {item.size && (
                                    <Badge variant="outline" className="text-xs px-1.5 py-0.5">
                                      {item.size}
                                    </Badge>
                                  )}
                                  {item.color && (
                                    <Badge variant="outline" className="text-xs px-1.5 py-0.5">
                                      {item.color}
                                    </Badge>
                                  )}
                                </div>
                              </div>

                              {/* Quantity Controls */}
                              <div className="flex items-center gap-2">
                                <button
                                  onClick={() => updateQuantity(item.id, item.quantity - 1, item.size, item.color)}
                                  className="w-6 h-6 rounded border border-gray-300 flex items-center justify-center hover:bg-gray-50 transition-colors"
                                  disabled={item.quantity <= 1}
                                >
                                  <Minus className="w-3 h-3" />
                                </button>
                                <span className="text-sm font-medium w-4 text-center">
                                  {item.quantity}
                                </span>
                                <button
                                  onClick={() => updateQuantity(item.id, item.quantity + 1, item.size, item.color)}
                                  className="w-6 h-6 rounded border border-gray-300 flex items-center justify-center hover:bg-gray-50 transition-colors"
                                >
                                  <Plus className="w-3 h-3" />
                                </button>
                              </div>

                              {/* Price */}
                              <div className="text-sm font-semibold text-gray-900">
                                {formatPrice(getItemTotal(item.price, item.quantity))}
                              </div>
                            </motion.div>
                          ))}
                        </AnimatePresence>

                        {/* More Items Indicator */}
                        {remainingItems > 0 && (
                          <div className="text-center py-2">
                            <button
                              onClick={handleViewCart}
                              className="text-sm text-cyan-600 hover:text-cyan-700 font-medium"
                            >
                              +{remainingItems} weitere Artikel anzeigen
                            </button>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Footer */}
                    <div className="p-4 border-t border-gray-200/50 bg-gradient-to-r from-white/90 to-gray-50/90">
                      {/* Total */}
                      <div className="flex justify-between items-center mb-3">
                        <span className="font-semibold text-gray-900">Gesamt:</span>
                        <span className="font-bold text-lg text-gray-900">
                          {formatPrice(total)}
                        </span>
                      </div>

                      {/* Action Buttons */}
                      <div className="space-y-2">
                        <Button
                          onClick={handleCheckout}
                          className="w-full bg-gradient-to-r from-cyan-500 to-cyan-600 hover:from-cyan-600 hover:to-cyan-700 text-white font-semibold rounded-xl"
                        >
                          Zur Kasse
                          <ArrowRight className="w-4 h-4 ml-2" />
                        </Button>
                        
                        <Button
                          variant="outline"
                          onClick={handleViewCart}
                          className="w-full border-gray-300 hover:bg-gray-50"
                        >
                          Warenkorb anzeigen
                        </Button>
                      </div>
                    </div>
                  </>
                )}
              </Card>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}