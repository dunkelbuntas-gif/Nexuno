import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Heart, 
  ShoppingCart, 
  Eye, 
  Star, 
  Filter,
  Grid3X3,
  List,
  Search,
  SortAsc,
  SortDesc,
  Check,
  X
} from 'lucide-react';
import { useCart } from './cart/CartContext';
import { useWishlist } from './wishlist/WishlistContext';
import { toast } from 'sonner@2.0.3';

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  image: string;
  category: string;
  colors: string[];
  sizes: string[];
  rating: number;
  reviews: number;
  isNew?: boolean;
  isSale?: boolean;
  stock: number;
  tags: string[];
}

interface AccessibleProductGridProps {
  selectedCategory?: string | null;
  searchQuery?: string;
  className?: string;
}

export function AccessibleProductGrid({ 
  selectedCategory = null, 
  searchQuery = '',
  className = '' 
}: AccessibleProductGridProps) {
  const [products, setProducts] = useState<Product[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [sortBy, setSortBy] = useState<'name' | 'price' | 'rating' | 'newest'>('newest');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [announceMessage, setAnnounceMessage] = useState('');
  
  // Filter states
  const [priceRange, setPriceRange] = useState({ min: 0, max: 200 });
  const [selectedColors, setSelectedColors] = useState<string[]>([]);
  const [selectedSizes, setSizes] = useState<string[]>([]);
  const [showOnlyInStock, setShowOnlyInStock] = useState(false);
  const [showFilters, setShowFilters] = useState(false);

  const { addItem } = useCart();
  const { addToWishlist, isInWishlist } = useWishlist();
  const gridRef = useRef<HTMLDivElement>(null);
  const filtersRef = useRef<HTMLDivElement>(null);

  // Mock products data
  const mockProducts: Product[] = [
    {
      id: '1',
      name: 'Future Tech T-Shirt Schwarz',
      description: 'Minimalistisches T-Shirt mit futuristischem Design und hochwertigem Bio-Baumwoll-Material',
      price: 39.99,
      originalPrice: 49.99,
      image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=500&h=500&fit=crop',
      category: 'tshirts',
      colors: ['Schwarz', 'Weiß', 'Grau'],
      sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
      rating: 4.8,
      reviews: 127,
      isNew: true,
      isSale: true,
      stock: 15,
      tags: ['bio', 'nachhaltig', 'futuristisch']
    },
    {
      id: '2',
      name: 'Cyber Hoodie Premium',
      description: 'Premium Hoodie mit LED-Details und thermoregulierender Funktion für maximalen Komfort',
      price: 89.99,
      image: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=500&h=500&fit=crop',
      category: 'hoodies',
      colors: ['Schwarz', 'Navy', 'Grau'],
      sizes: ['S', 'M', 'L', 'XL', 'XXL'],
      rating: 4.9,
      reviews: 89,
      isNew: false,
      stock: 8,
      tags: ['premium', 'led', 'thermo']
    },
    {
      id: '3',
      name: 'Neural Interface Armband',
      description: 'Smartes Armband mit biometrischen Sensoren und holographischer Anzeige',
      price: 149.99,
      image: 'https://images.unsplash.com/photo-1611652022419-a9419f74343d?w=500&h=500&fit=crop',
      category: 'accessories',
      colors: ['Neon Grün', 'Cyber Blau', 'Hot Pink'],
      sizes: ['One Size'],
      rating: 4.7,
      reviews: 234,
      stock: 12,
      tags: ['smart', 'biometric', 'holographic']
    }
  ];

  // Screen reader announcements
  const announceToScreenReader = (message: string) => {
    setAnnounceMessage(message);
    setTimeout(() => setAnnounceMessage(''), 1000);
  };

  // Load products (simulated)
  useEffect(() => {
    setIsLoading(true);
    setTimeout(() => {
      setProducts(mockProducts);
      setIsLoading(false);
      announceToScreenReader('Produkte geladen');
    }, 500);
  }, []);

  // Filter and sort products
  useEffect(() => {
    let filtered = [...products];

    // Category filter
    if (selectedCategory) {
      filtered = filtered.filter(product => product.category === selectedCategory);
    }

    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(product => 
        product.name.toLowerCase().includes(query) ||
        product.description.toLowerCase().includes(query) ||
        product.tags.some(tag => tag.toLowerCase().includes(query))
      );
    }

    // Price filter
    filtered = filtered.filter(product => 
      product.price >= priceRange.min && product.price <= priceRange.max
    );

    // Color filter
    if (selectedColors.length > 0) {
      filtered = filtered.filter(product =>
        product.colors.some(color => selectedColors.includes(color))
      );
    }

    // Size filter
    if (selectedSizes.length > 0) {
      filtered = filtered.filter(product =>
        product.sizes.some(size => selectedSizes.includes(size))
      );
    }

    // Stock filter
    if (showOnlyInStock) {
      filtered = filtered.filter(product => product.stock > 0);
    }

    // Sort products
    filtered.sort((a, b) => {
      let comparison = 0;
      
      switch (sortBy) {
        case 'name':
          comparison = a.name.localeCompare(b.name);
          break;
        case 'price':
          comparison = a.price - b.price;
          break;
        case 'rating':
          comparison = a.rating - b.rating;
          break;
        case 'newest':
          comparison = (a.isNew ? 1 : 0) - (b.isNew ? 1 : 0);
          break;
      }
      
      return sortOrder === 'asc' ? comparison : -comparison;
    });

    setFilteredProducts(filtered);
    
    // Announce filter results
    const categoryText = selectedCategory ? ` in ${selectedCategory}` : '';
    const searchText = searchQuery ? ` für "${searchQuery}"` : '';
    announceToScreenReader(`${filtered.length} Produkte gefunden${categoryText}${searchText}`);
  }, [products, selectedCategory, searchQuery, priceRange, selectedColors, selectedSizes, showOnlyInStock, sortBy, sortOrder]);

  // Handle add to cart with accessibility
  const handleAddToCart = (product: Product) => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      category: product.category,
      size: product.sizes[0],
      color: product.colors[0]
    });
    
    toast.success(`${product.name} wurde zum Warenkorb hinzugefügt`);
    announceToScreenReader(`${product.name} zum Warenkorb hinzugefügt`);
  };

  // Handle add to wishlist
  const handleAddToWishlist = (product: Product) => {
    if (!isInWishlist(product.id)) {
      addToWishlist({
        id: product.id,
        name: product.name,
        price: `€${product.price}`,
        image: product.image,
        category: product.category
      });
      toast.success(`${product.name} zur Wunschliste hinzugefügt`);
      announceToScreenReader(`${product.name} zur Wunschliste hinzugefügt`);
    }
  };

  // Handle view mode change
  const handleViewModeChange = (mode: 'grid' | 'list') => {
    setViewMode(mode);
    announceToScreenReader(`Ansicht geändert zu ${mode === 'grid' ? 'Raster' : 'Liste'}`);
  };

  // Handle sort change
  const handleSortChange = (newSortBy: typeof sortBy) => {
    if (newSortBy === sortBy) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(newSortBy);
      setSortOrder('desc');
    }
    
    const orderText = sortOrder === 'asc' ? 'aufsteigend' : 'absteigend';
    announceToScreenReader(`Sortierung geändert: ${newSortBy} ${orderText}`);
  };

  // Get all available colors and sizes
  const allColors = Array.from(new Set(products.flatMap(p => p.colors)));
  const allSizes = Array.from(new Set(products.flatMap(p => p.sizes)));

  return (
    <section 
      className={`py-12 ${className}`}
      aria-label="Produktkatalog"
    >
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Header with controls */}
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6 mb-8">
          <div>
            <h2 className="text-2xl font-bold text-white mb-2">
              {selectedCategory ? `${selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1)}` : 'Alle Produkte'}
            </h2>
            <p className="text-cyan-200" id="product-count">
              {filteredProducts.length} {filteredProducts.length === 1 ? 'Produkt' : 'Produkte'} gefunden
            </p>
          </div>

          {/* Controls */}
          <div className="flex flex-wrap items-center gap-4">
            
            {/* View Mode Toggle */}
            <div className="flex items-center bg-slate-800/50 rounded-lg p-1" role="group" aria-label="Ansichtsmodus">
              <button
                onClick={() => handleViewModeChange('grid')}
                className={`p-2 rounded-md transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-yellow-400 ${
                  viewMode === 'grid' 
                    ? 'bg-cyan-500 text-white' 
                    : 'text-cyan-200 hover:text-white hover:bg-slate-700'
                }`}
                aria-label="Rasteransicht"
                aria-pressed={viewMode === 'grid'}
              >
                <Grid3X3 className="w-5 h-5" aria-hidden="true" />
              </button>
              <button
                onClick={() => handleViewModeChange('list')}
                className={`p-2 rounded-md transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-yellow-400 ${
                  viewMode === 'list' 
                    ? 'bg-cyan-500 text-white' 
                    : 'text-cyan-200 hover:text-white hover:bg-slate-700'
                }`}
                aria-label="Listenansicht"
                aria-pressed={viewMode === 'list'}
              >
                <List className="w-5 h-5" aria-hidden="true" />
              </button>
            </div>

            {/* Sort Dropdown */}
            <div className="relative">
              <select
                value={`${sortBy}-${sortOrder}`}
                onChange={(e) => {
                  const [newSortBy, newSortOrder] = e.target.value.split('-') as [typeof sortBy, typeof sortOrder];
                  setSortBy(newSortBy);
                  setSortOrder(newSortOrder);
                }}
                className="bg-slate-800/50 text-cyan-200 border border-slate-600 rounded-lg px-4 py-2 pr-8 focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
                aria-label="Sortierung auswählen"
              >
                <option value="newest-desc">Neueste zuerst</option>
                <option value="name-asc">Name A-Z</option>
                <option value="name-desc">Name Z-A</option>
                <option value="price-asc">Preis niedrig-hoch</option>
                <option value="price-desc">Preis hoch-niedrig</option>
                <option value="rating-desc">Bewertung hoch-niedrig</option>
              </select>
            </div>

            {/* Filter Toggle */}
            <button
              onClick={() => {
                setShowFilters(!showFilters);
                announceToScreenReader(showFilters ? 'Filter geschlossen' : 'Filter geöffnet');
              }}
              className="flex items-center gap-2 bg-slate-800/50 text-cyan-200 hover:text-white hover:bg-slate-700 border border-slate-600 rounded-lg px-4 py-2 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-yellow-400"
              aria-label="Filter ein-/ausblenden"
              aria-expanded={showFilters}
              aria-controls="product-filters"
            >
              <Filter className="w-5 h-5" aria-hidden="true" />
              <span>Filter</span>
            </button>
          </div>
        </div>

        {/* Filters Panel */}
        <AnimatePresence>
          {showFilters && (
            <motion.div
              ref={filtersRef}
              id="product-filters"
              className="bg-slate-800/30 backdrop-blur-sm rounded-lg p-6 mb-8 border border-slate-600"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              role="region"
              aria-label="Produktfilter"
            >
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                
                {/* Price Range */}
                <div>
                  <label className="block text-cyan-200 font-semibold mb-3">
                    Preisbereich: €{priceRange.min} - €{priceRange.max}
                  </label>
                  <div className="space-y-2">
                    <input
                      type="range"
                      min="0"
                      max="200"
                      value={priceRange.min}
                      onChange={(e) => setPriceRange(prev => ({ ...prev, min: parseInt(e.target.value) }))}
                      className="w-full accent-cyan-500"
                      aria-label="Mindestpreis"
                    />
                    <input
                      type="range"
                      min="0"
                      max="200"
                      value={priceRange.max}
                      onChange={(e) => setPriceRange(prev => ({ ...prev, max: parseInt(e.target.value) }))}
                      className="w-full accent-cyan-500"
                      aria-label="Höchstpreis"
                    />
                  </div>
                </div>

                {/* Colors */}
                <div>
                  <fieldset>
                    <legend className="text-cyan-200 font-semibold mb-3">Farben</legend>
                    <div className="space-y-2 max-h-32 overflow-y-auto">
                      {allColors.map(color => (
                        <label key={color} className="flex items-center gap-2 text-cyan-200 hover:text-white cursor-pointer">
                          <input
                            type="checkbox"
                            checked={selectedColors.includes(color)}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedColors(prev => [...prev, color]);
                              } else {
                                setSelectedColors(prev => prev.filter(c => c !== color));
                              }
                            }}
                            className="rounded border-slate-600 text-cyan-500 focus:ring-cyan-500"
                          />
                          <span>{color}</span>
                        </label>
                      ))}
                    </div>
                  </fieldset>
                </div>

                {/* Sizes */}
                <div>
                  <fieldset>
                    <legend className="text-cyan-200 font-semibold mb-3">Größen</legend>
                    <div className="flex flex-wrap gap-2">
                      {allSizes.map(size => (
                        <label key={size} className="cursor-pointer">
                          <input
                            type="checkbox"
                            checked={selectedSizes.includes(size)}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSizes(prev => [...prev, size]);
                              } else {
                                setSizes(prev => prev.filter(s => s !== size));
                              }
                            }}
                            className="sr-only"
                          />
                          <span className={`
                            inline-block px-3 py-1 rounded-md text-sm font-medium transition-all duration-200
                            ${selectedSizes.includes(size)
                              ? 'bg-cyan-500 text-white'
                              : 'bg-slate-700 text-cyan-200 hover:bg-slate-600'
                            }
                          `}>
                            {size}
                          </span>
                        </label>
                      ))}
                    </div>
                  </fieldset>
                </div>

                {/* Stock Filter */}
                <div>
                  <label className="flex items-center gap-2 text-cyan-200 hover:text-white cursor-pointer">
                    <input
                      type="checkbox"
                      checked={showOnlyInStock}
                      onChange={(e) => setShowOnlyInStock(e.target.checked)}
                      className="rounded border-slate-600 text-cyan-500 focus:ring-cyan-500"
                    />
                    <span>Nur verfügbare Artikel</span>
                  </label>
                </div>
              </div>

              {/* Clear Filters */}
              <div className="mt-6 pt-4 border-t border-slate-600">
                <button
                  onClick={() => {
                    setPriceRange({ min: 0, max: 200 });
                    setSelectedColors([]);
                    setSizes([]);
                    setShowOnlyInStock(false);
                    announceToScreenReader('Filter zurückgesetzt');
                  }}
                  className="text-cyan-400 hover:text-cyan-300 font-medium focus:outline-none focus:underline"
                >
                  Alle Filter zurücksetzen
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Loading State */}
        {isLoading && (
          <div className="flex justify-center items-center py-12" role="status" aria-live="polite">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-400"></div>
            <span className="sr-only">Produkte werden geladen...</span>
          </div>
        )}

        {/* No Results */}
        {!isLoading && filteredProducts.length === 0 && (
          <div className="text-center py-12">
            <div className="text-cyan-200 mb-4">
              <Search className="w-16 h-16 mx-auto mb-4 opacity-50" aria-hidden="true" />
              <h3 className="text-xl font-semibold mb-2">Keine Produkte gefunden</h3>
              <p>Versuchen Sie es mit anderen Filtereinstellungen oder Suchbegriffen.</p>
            </div>
            <button
              onClick={() => {
                setPriceRange({ min: 0, max: 200 });
                setSelectedColors([]);
                setSizes([]);
                setShowOnlyInStock(false);
              }}
              className="mt-4 bg-cyan-500 hover:bg-cyan-600 text-white px-6 py-2 rounded-lg font-medium transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-yellow-400"
            >
              Filter zurücksetzen
            </button>
          </div>
        )}

        {/* Products Grid/List */}
        <div ref={gridRef}>
          <AnimatePresence mode="popLayout">
            <motion.div
              className={
                viewMode === 'grid'
                  ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6'
                  : 'space-y-6'
              }
              layout
            >
              {filteredProducts.map((product, index) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  viewMode={viewMode}
                  index={index}
                  onAddToCart={handleAddToCart}
                  onAddToWishlist={handleAddToWishlist}
                  isInWishlist={isInWishlist(product.id)}
                />
              ))}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* Screen Reader Live Region */}
      <div
        role="status"
        aria-live="polite"
        aria-atomic="true"
        className="sr-only"
      >
        {announceMessage}
      </div>
    </section>
  );
}

// Individual Product Card Component
interface ProductCardProps {
  product: Product;
  viewMode: 'grid' | 'list';
  index: number;
  onAddToCart: (product: Product) => void;
  onAddToWishlist: (product: Product) => void;
  isInWishlist: boolean;
}

function ProductCard({ 
  product, 
  viewMode, 
  index, 
  onAddToCart, 
  onAddToWishlist, 
  isInWishlist 
}: ProductCardProps) {
  const [imageLoaded, setImageLoaded] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  const cardClasses = viewMode === 'grid' 
    ? 'bg-slate-800/30 backdrop-blur-sm rounded-xl overflow-hidden border border-slate-600 hover:border-cyan-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-cyan-500/10'
    : 'bg-slate-800/30 backdrop-blur-sm rounded-xl overflow-hidden border border-slate-600 hover:border-cyan-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-cyan-500/10 flex gap-6';

  return (
    <motion.article
      className={cardClasses}
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ delay: index * 0.05 }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      role="article"
      aria-labelledby={`product-name-${product.id}`}
    >
      {/* Product Image */}
      <div className={`relative ${viewMode === 'grid' ? 'aspect-square' : 'w-48 h-48 flex-shrink-0'} overflow-hidden bg-slate-700`}>
        <img
          src={product.image}
          alt={`${product.name} - ${product.description}`}
          className={`w-full h-full object-cover transition-all duration-300 ${imageLoaded ? 'opacity-100' : 'opacity-0'} ${isHovered ? 'scale-105' : 'scale-100'}`}
          onLoad={() => setImageLoaded(true)}
          loading="lazy"
        />
        
        {/* Loading placeholder */}
        {!imageLoaded && (
          <div className="absolute inset-0 bg-slate-700 animate-pulse" />
        )}

        {/* Badges */}
        <div className="absolute top-2 left-2 flex flex-col gap-1">
          {product.isNew && (
            <span className="bg-cyan-500 text-white text-xs font-bold px-2 py-1 rounded-full">
              NEU
            </span>
          )}
          {product.isSale && (
            <span className="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full">
              SALE
            </span>
          )}
          {product.stock <= 5 && product.stock > 0 && (
            <span className="bg-orange-500 text-white text-xs font-bold px-2 py-1 rounded-full">
              Nur {product.stock} verfügbar
            </span>
          )}
          {product.stock === 0 && (
            <span className="bg-gray-500 text-white text-xs font-bold px-2 py-1 rounded-full">
              Ausverkauft
            </span>
          )}
        </div>

        {/* Wishlist Button */}
        <button
          onClick={() => onAddToWishlist(product)}
          className="absolute top-2 right-2 p-2 bg-black/50 backdrop-blur-sm rounded-full text-white hover:bg-black/70 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-yellow-400"
          aria-label={`${product.name} ${isInWishlist ? 'von Wunschliste entfernen' : 'zur Wunschliste hinzufügen'}`}
        >
          <Heart 
            className={`w-4 h-4 ${isInWishlist ? 'fill-red-500 text-red-500' : ''}`} 
            aria-hidden="true" 
          />
        </button>
      </div>

      {/* Product Information */}
      <div className={`p-4 ${viewMode === 'list' ? 'flex-1' : ''}`}>
        <div className="space-y-3">
          {/* Name and Category */}
          <div>
            <h3 
              id={`product-name-${product.id}`}
              className="font-semibold text-white text-lg leading-tight"
            >
              {product.name}
            </h3>
            <p className="text-cyan-200 text-sm">{product.category}</p>
          </div>

          {/* Description */}
          <p className="text-slate-300 text-sm leading-relaxed line-clamp-2">
            {product.description}
          </p>

          {/* Rating */}
          <div className="flex items-center gap-2">
            <div className="flex items-center" role="img" aria-label={`Bewertung: ${product.rating} von 5 Sternen`}>
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-4 h-4 ${
                    i < Math.floor(product.rating)
                      ? 'text-yellow-400 fill-current'
                      : 'text-slate-600'
                  }`}
                  aria-hidden="true"
                />
              ))}
            </div>
            <span className="text-slate-400 text-sm">
              ({product.reviews} Bewertungen)
            </span>
          </div>

          {/* Available Colors */}
          <div>
            <span className="text-slate-400 text-sm">Verfügbare Farben: </span>
            <span className="text-cyan-200 text-sm">{product.colors.join(', ')}</span>
          </div>

          {/* Available Sizes */}
          <div>
            <span className="text-slate-400 text-sm">Verfügbare Größen: </span>
            <span className="text-cyan-200 text-sm">{product.sizes.join(', ')}</span>
          </div>

          {/* Price and Actions */}
          <div className="flex items-center justify-between pt-2">
            <div className="flex items-center gap-2">
              <span className="text-white font-bold text-lg">
                €{product.price.toFixed(2)}
              </span>
              {product.originalPrice && (
                <span className="text-slate-400 line-through text-sm">
                  €{product.originalPrice.toFixed(2)}
                </span>
              )}
            </div>

            <div className="flex items-center gap-2">
              <button
                className="p-2 bg-slate-700 hover:bg-slate-600 text-cyan-200 hover:text-white rounded-lg transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-yellow-400"
                aria-label={`${product.name} Produktdetails anzeigen`}
              >
                <Eye className="w-4 h-4" aria-hidden="true" />
              </button>

              <button
                onClick={() => onAddToCart(product)}
                disabled={product.stock === 0}
                className="flex items-center gap-2 bg-cyan-500 hover:bg-cyan-600 disabled:bg-slate-600 text-white px-4 py-2 rounded-lg font-medium transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-yellow-400 disabled:cursor-not-allowed"
                aria-label={`${product.name} zum Warenkorb hinzufügen${product.stock === 0 ? ' - Ausverkauft' : ''}`}
              >
                <ShoppingCart className="w-4 h-4" aria-hidden="true" />
                <span className="hidden sm:inline">
                  {product.stock === 0 ? 'Ausverkauft' : 'In den Warenkorb'}
                </span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </motion.article>
  );
}