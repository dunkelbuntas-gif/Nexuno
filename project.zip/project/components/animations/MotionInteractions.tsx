import React from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface MotionButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  className?: string;
  variant?: 'primary' | 'secondary' | 'outline' | 'tech';
  size?: 'sm' | 'md' | 'lg';
  disabled?: boolean;
}

export function MotionButton({ 
  children, 
  onClick, 
  className = '', 
  variant = 'primary',
  size = 'md',
  disabled = false
}: MotionButtonProps) {
  const baseClasses = 'relative overflow-hidden font-inter font-semibold transition-colors cursor-pointer select-none';
  
  const variantClasses = {
    primary: 'bg-gradient-to-r from-store-green to-green-500 text-white border border-store-green/30',
    secondary: 'bg-gradient-to-r from-store-orange to-orange-500 text-white border border-store-orange/30',
    outline: 'bg-transparent text-store-green border-2 border-store-green hover:bg-store-green hover:text-white',
    tech: 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white border border-cyan-400/30'
  };
  
  const sizeClasses = {
    sm: 'px-4 py-2 text-sm rounded-lg',
    md: 'px-6 py-3 text-base rounded-xl',
    lg: 'px-8 py-4 text-lg rounded-2xl'
  };

  return (
    <motion.button
      className={`${baseClasses} ${variantClasses[variant]} ${sizeClasses[size]} ${className}`}
      onClick={onClick}
      disabled={disabled}
      whileHover={{ 
        scale: disabled ? 1 : 1.02,
        boxShadow: disabled ? 'none' : '0 8px 25px rgba(34, 197, 94, 0.3)'
      }}
      whileTap={{ 
        scale: disabled ? 1 : 0.98 
      }}
      transition={{
        type: "spring",
        stiffness: 400,
        damping: 17
      }}
    >
      {/* Hover Overlay Effect */}
      <motion.div
        className="absolute inset-0 bg-white/20"
        initial={{ x: '-100%' }}
        whileHover={{ x: '100%' }}
        transition={{ duration: 0.5, ease: "easeOut" }}
      />
      
      {/* Content */}
      <span className="relative z-10">{children}</span>
    </motion.button>
  );
}

interface MotionCardProps {
  children: React.ReactNode;
  className?: string;
  hoverEffect?: 'lift' | 'glow' | 'scale' | 'tilt';
  clickable?: boolean;
  onClick?: () => void;
}

export function MotionCard({ 
  children, 
  className = '', 
  hoverEffect = 'lift',
  clickable = false,
  onClick
}: MotionCardProps) {
  const hoverEffects = {
    lift: {
      y: -8,
      boxShadow: '0 20px 40px rgba(0, 0, 0, 0.1)'
    },
    glow: {
      boxShadow: '0 0 20px rgba(34, 197, 94, 0.3)'
    },
    scale: {
      scale: 1.03
    },
    tilt: {
      rotateY: 5,
      rotateX: 5,
      scale: 1.02
    }
  };

  return (
    <motion.div
      className={`${className} ${clickable ? 'cursor-pointer' : ''}`}
      whileHover={hoverEffects[hoverEffect]}
      whileTap={clickable ? { scale: 0.98 } : {}}
      transition={{
        type: "spring",
        stiffness: 300,
        damping: 20
      }}
      onClick={onClick}
      style={{ 
        transformStyle: 'preserve-3d',
        willChange: 'transform'
      }}
    >
      {children}
    </motion.div>
  );
}

interface FloatingElementProps {
  children: React.ReactNode;
  className?: string;
  intensity?: 'subtle' | 'medium' | 'strong';
  delay?: number;
}

export function FloatingElement({ 
  children, 
  className = '', 
  intensity = 'medium',
  delay = 0
}: FloatingElementProps) {
  const intensitySettings = {
    subtle: { y: [-5, 5], duration: 4 },
    medium: { y: [-10, 10], duration: 3 },
    strong: { y: [-20, 20], duration: 2.5 }
  };

  const settings = intensitySettings[intensity];

  return (
    <motion.div
      className={className}
      animate={{
        y: settings.y,
        transition: {
          duration: settings.duration,
          repeat: Infinity,
          repeatType: "reverse",
          ease: "easeInOut",
          delay
        }
      }}
    >
      {children}
    </motion.div>
  );
}

interface PulseGlowProps {
  children: React.ReactNode;
  className?: string;
  color?: 'green' | 'blue' | 'cyan' | 'orange';
  intensity?: number;
}

export function PulseGlow({ 
  children, 
  className = '', 
  color = 'green',
  intensity = 0.3
}: PulseGlowProps) {
  const colors = {
    green: `rgba(34, 197, 94, ${intensity})`,
    blue: `rgba(59, 130, 246, ${intensity})`,
    cyan: `rgba(6, 182, 212, ${intensity})`,
    orange: `rgba(251, 146, 60, ${intensity})`
  };

  return (
    <motion.div
      className={className}
      animate={{
        boxShadow: [
          `0 0 0px ${colors[color]}`,
          `0 0 20px ${colors[color]}`,
          `0 0 0px ${colors[color]}`
        ]
      }}
      transition={{
        duration: 2,
        repeat: Infinity,
        ease: "easeInOut"
      }}
    >
      {children}
    </motion.div>
  );
}

interface MagneticElementProps {
  children: React.ReactNode;
  className?: string;
  strength?: number;
}

export function MagneticElement({ 
  children, 
  className = '', 
  strength = 0.3
}: MagneticElementProps) {
  const [position, setPosition] = React.useState({ x: 0, y: 0 });

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    
    const deltaX = (e.clientX - centerX) * strength;
    const deltaY = (e.clientY - centerY) * strength;
    
    setPosition({ x: deltaX, y: deltaY });
  };

  const handleMouseLeave = () => {
    setPosition({ x: 0, y: 0 });
  };

  return (
    <motion.div
      className={className}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      animate={{
        x: position.x,
        y: position.y
      }}
      transition={{
        type: "spring",
        stiffness: 200,
        damping: 20
      }}
    >
      {children}
    </motion.div>
  );
}

interface StaggerContainerProps {
  children: React.ReactNode;
  className?: string;
  staggerDelay?: number;
  direction?: 'up' | 'down' | 'left' | 'right' | 'scale';
}

export function MotionStaggerContainer({ 
  children, 
  className = '', 
  staggerDelay = 0.1,
  direction = 'up'
}: StaggerContainerProps) {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: staggerDelay
      }
    }
  };

  const itemVariants = {
    hidden: direction === 'up' ? { y: 60, opacity: 0 } :
             direction === 'down' ? { y: -60, opacity: 0 } :
             direction === 'left' ? { x: 60, opacity: 0 } :
             direction === 'right' ? { x: -60, opacity: 0 } :
             { scale: 0.8, opacity: 0 },
    visible: direction === 'up' || direction === 'down' ? { y: 0, opacity: 1 } :
             direction === 'left' || direction === 'right' ? { x: 0, opacity: 1 } :
             { scale: 1, opacity: 1 }
  };

  return (
    <motion.div
      className={className}
      variants={containerVariants}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: "-50px" }}
    >
      {React.Children.map(children, (child, index) => (
        <motion.div key={index} variants={itemVariants}>
          {child}
        </motion.div>
      ))}
    </motion.div>
  );
}