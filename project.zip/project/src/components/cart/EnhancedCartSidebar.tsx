export function EnhancedCartSidebar({
  onCheckout, onContinueShopping
}: { onCheckout:()=>void; onContinueShopping:()=>void }) {
  return (
    <aside style={{position:'fixed', right:16, bottom:16, background:'#111827', padding:12, borderRadius:8}}>
      <button onClick={onCheckout} style={{marginRight:8}}>Zur Kasse</button>
      <button onClick={onContinueShopping}>Weiter einkaufen</button>
    </aside>
  );
}