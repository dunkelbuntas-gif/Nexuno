import React, { useState, useRef } from 'react';
import { MessageCircle, X, Headphones } from 'lucide-react';
import { AIChatBot } from './AIChatBot';

interface SimpleChatDockProps {
  position?: 'bottom-right' | 'bottom-left' | 'header-integrated';
  onEscalateToHuman?: () => void;
}

export function SimpleChatDock({ 
  position = 'bottom-right',
  onEscalateToHuman 
}: SimpleChatDockProps) {
  const [isOpen, setIsOpen] = useState(false);
  const panelRef = useRef<HTMLDivElement>(null);

  // Header-Integration Modus
  const isHeaderIntegrated = position === 'header-integrated';

  // Positionierungsklassen
  const positionClasses = {
    'bottom-right': 'bottom-6 right-6',
    'bottom-left': 'bottom-6 left-6',
    'header-integrated': 'top-16 right-6' // Unterhalb des Headers positioniert
  };

  const handleToggle = () => {
    setIsOpen(!isOpen);
  };

  const handleClose = () => {
    setIsOpen(false);
  };

  // Header-Integration: Nur Button returnen
  if (isHeaderIntegrated) {
    return (
      <div className="relative">
        {/* Chat Panel - Header Mode */}
        {isOpen && (
          <div 
            ref={panelRef}
            className="absolute top-12 right-0 w-80 h-96 bg-white/95 backdrop-blur-xl border border-white/30 
                       rounded-2xl shadow-2xl overflow-hidden transition-all duration-300 z-50"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-gradient-to-r from-cyan-500 to-blue-600">
              <div className="flex items-center gap-2">
                <MessageCircle className="w-5 h-5 text-white" />
                <h3 className="font-semibold text-white">Nexuno Chat</h3>
              </div>
              <div className="flex items-center gap-2">
                {onEscalateToHuman && (
                  <button
                    onClick={onEscalateToHuman}
                    className="p-1 hover:bg-white/20 rounded transition-colors"
                    title="Mit einem Menschen sprechen"
                  >
                    <Headphones className="w-4 h-4 text-white" />
                  </button>
                )}
                <button
                  onClick={handleClose}
                  className="p-1 hover:bg-white/20 rounded transition-colors"
                  title="Chat schließen"
                >
                  <X className="w-4 h-4 text-white" />
                </button>
              </div>
            </div>
  
            {/* Chat Content */}
            <div className="h-full">
              <AIChatBot 
                onEscalateToHuman={onEscalateToHuman}
                className="h-full"
              />
            </div>
          </div>
        )}

        {/* Header Button */}
        <button
          onClick={handleToggle}
          className="h-10 px-4 bg-gradient-to-r from-cyan-500 to-blue-600 text-white 
                     rounded-lg shadow-md hover:shadow-lg transition-all duration-200
                     flex items-center justify-center gap-2 hover:scale-105 text-sm font-medium"
          aria-label={isOpen ? 'Chat schließen' : 'Chat öffnen'}
          title={isOpen ? 'Chat schließen' : 'Nexuno Chat öffnen'}
        >
          {isOpen ? (
            <>
              <X className="w-4 h-4" />
              <span className="hidden sm:inline">Chat</span>
            </>
          ) : (
            <>
              <MessageCircle className="w-4 h-4" />
              <span className="hidden sm:inline">Chat</span>
            </>
          )}
        </button>
      </div>
    );
  }

  // Standard Fixed Position Modus
  return (
    <div className={`fixed ${positionClasses[position]} z-50`}>
      {/* Chat Panel */}
      {isOpen && (
        <div 
          ref={panelRef}
          className="mb-4 w-80 h-96 bg-white/95 backdrop-blur-xl border border-white/30 
                     rounded-2xl shadow-2xl overflow-hidden transition-all duration-300"
        >
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-gradient-to-r from-cyan-500 to-blue-600">
            <div className="flex items-center gap-2">
              <MessageCircle className="w-5 h-5 text-white" />
              <h3 className="font-semibold text-white">Nexuno Chat</h3>
            </div>
            <div className="flex items-center gap-2">
              {onEscalateToHuman && (
                <button
                  onClick={onEscalateToHuman}
                  className="p-1 hover:bg-white/20 rounded transition-colors"
                  title="Mit einem Menschen sprechen"
                >
                  <Headphones className="w-4 h-4 text-white" />
                </button>
              )}
              <button
                onClick={handleClose}
                className="p-1 hover:bg-white/20 rounded transition-colors"
                title="Chat schließen"
              >
                <X className="w-4 h-4 text-white" />
              </button>
            </div>
          </div>

          {/* Chat Content */}
          <div className="h-full">
            <AIChatBot 
              onEscalateToHuman={onEscalateToHuman}
              className="h-full"
            />
          </div>
        </div>
      )}

      {/* Trigger Button */}
      <button
        onClick={handleToggle}
        className="h-10 px-4 bg-gradient-to-r from-cyan-500 to-blue-600 text-white 
                   rounded-lg shadow-md hover:shadow-lg transition-all duration-200
                   flex items-center justify-center gap-2 hover:scale-105 text-sm font-medium"
        aria-label={isOpen ? 'Chat schließen' : 'Chat öffnen'}
        title={isOpen ? 'Chat schließen' : 'Nexuno Chat öffnen'}
      >
        {isOpen ? (
          <X className="w-6 h-6" />
        ) : (
          <MessageCircle className="w-6 h-6" />
        )}
      </button>
    </div>
  );
}

export default SimpleChatDock;