import { ArrowLeft } from 'lucide-react';

interface BackButtonProps {
  variant?: 'default' | 'legal';
  onBack?: () => void;
}

export function BackButton({ variant = 'default', onBack }: BackButtonProps) {
  const handleBack = () => {
    if (onBack) {
      onBack();
    } else {
      window.history.back();
    }
  };

  // Minimalistisches Design für alle Zurück-Buttons
  return (
    <button
      onClick={handleBack}
      className="glass-card border-white/30 hover:border-[var(--primary-blue)] hover:glow-subtle px-4 py-2 rounded-lg text-[var(--text-body)] hover:text-[var(--primary-blue)] transition-all duration-300 group flex items-center gap-2 font-['Inter'] text-sm font-medium"
    >
      <ArrowLeft className="w-4 h-4 transition-transform group-hover:translate-x-[-2px]" />
      <span>Zurück</span>
    </button>
  );
}