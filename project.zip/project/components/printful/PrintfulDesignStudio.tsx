/**
 * Printful Design Studio Component
 * Complete design creation and customization interface
 */

import React, { useState, useRef, useCallback } from 'react';
import { printfulApi, printfulHelpers, type PrintfulProduct, type PrintfulVariant } from '../../lib/printful-api';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Separator } from '../ui/separator';
import { 
  Upload, 
  Download, 
  Palette, 
  Type, 
  Image, 
  Layers,
  RotateCcw,
  RotateCw,
  ZoomIn,
  ZoomOut,
  Move,
  Save,
  Play,
  ShoppingCart,
  Eye
} from 'lucide-react';

interface PrintfulDesignStudioProps {
  product: PrintfulProduct;
  variant?: PrintfulVariant;
  onClose?: () => void;
  onAddToCart?: (designData: DesignData) => void;
}

interface DesignData {
  productId: number;
  variantId?: number;
  designUrl: string;
  placement: string;
  mockupUrl?: string;
  customizations: {
    text?: string;
    fontSize?: number;
    fontColor?: string;
    backgroundColor?: string;
  };
}

export function PrintfulDesignStudio({ 
  product, 
  variant, 
  onClose, 
  onAddToCart 
}: PrintfulDesignStudioProps) {
  const [variants, setVariants] = useState<PrintfulVariant[]>([]);
  const [selectedVariant, setSelectedVariant] = useState<PrintfulVariant | null>(variant || null);
  const [designFile, setDesignFile] = useState<File | null>(null);
  const [designUrl, setDesignUrl] = useState<string>('');
  const [mockupUrl, setMockupUrl] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [designText, setDesignText] = useState('');
  const [fontSize, setFontSize] = useState(48);
  const [fontColor, setFontColor] = useState('#000000');
  const [backgroundColor, setBackgroundColor] = useState('#FFFFFF');
  const [placement, setPlacement] = useState<'front' | 'back' | 'left' | 'right'>('front');
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Load product variants
  React.useEffect(() => {
    if (product.id) {
      loadProductVariants();
    }
  }, [product.id]);

  const loadProductVariants = async () => {
    try {
      setLoading(true);
      const response = await printfulApi.getProductVariants(product.id);
      setVariants(response.result);
      
      if (!selectedVariant && response.result.length > 0) {
        setSelectedVariant(response.result[0]);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load variants');
    } finally {
      setLoading(false);
    }
  };

  // Handle file upload
  const handleFileUpload = useCallback(async (file: File) => {
    if (!file) return;

    try {
      setLoading(true);
      setError(null);
      
      // Validate file
      if (!file.type.startsWith('image/')) {
        throw new Error('Please upload an image file');
      }
      
      if (file.size > 10 * 1024 * 1024) { // 10MB limit
        throw new Error('File size must be less than 10MB');
      }

      setDesignFile(file);
      
      // Upload to Printful via Workers
      const uploadResponse = await printfulApi.uploadDesign(file);
      setDesignUrl(uploadResponse.design_url);
      
      // Auto-generate mockup
      if (selectedVariant) {
        generateMockup(uploadResponse.design_url);
      }
      
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Upload failed');
    } finally {
      setLoading(false);
    }
  }, [selectedVariant]);

  // Generate text design on canvas
  const generateTextDesign = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || !designText.trim()) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    canvas.width = 1000;
    canvas.height = 1000;

    // Clear canvas
    ctx.fillStyle = backgroundColor;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw text
    ctx.fillStyle = fontColor;
    ctx.font = `${fontSize}px Arial`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    
    // Handle multi-line text
    const lines = designText.split('\n');
    const lineHeight = fontSize * 1.2;
    const startY = canvas.height / 2 - ((lines.length - 1) * lineHeight) / 2;
    
    lines.forEach((line, index) => {
      ctx.fillText(line, canvas.width / 2, startY + (index * lineHeight));
    });

    // Convert to blob and upload
    canvas.toBlob(async (blob) => {
      if (blob) {
        const file = new File([blob], 'text-design.png', { type: 'image/png' });
        await handleFileUpload(file);
      }
    });
  }, [designText, fontSize, fontColor, backgroundColor, handleFileUpload]);

  // Generate mockup
  const generateMockup = async (designUrl: string) => {
    if (!selectedVariant) return;

    try {
      setLoading(true);
      
      const mockupResponse = await printfulApi.createMockup({
        product_id: product.id,
        variant_id: selectedVariant.id,
        design_url: designUrl,
        placement: placement,
      });
      
      // Printful mockup generation is async, so we'd need to poll for results
      // For now, we'll use a placeholder
      setMockupUrl('/api/placeholder-mockup.jpg');
      
    } catch (err) {
      console.error('Mockup generation failed:', err);
      // Continue without mockup
    } finally {
      setLoading(false);
    }
  };

  // Add to cart
  const handleAddToCart = () => {
    if (!selectedVariant || !designUrl) return;

    const designData: DesignData = {
      productId: product.id,
      variantId: selectedVariant.id,
      designUrl,
      placement,
      mockupUrl,
      customizations: {
        text: designText || undefined,
        fontSize: designText ? fontSize : undefined,
        fontColor: designText ? fontColor : undefined,
        backgroundColor: designText ? backgroundColor : undefined,
      },
    };

    onAddToCart?.(designData);
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Design Studio</h1>
            <p className="text-gray-600">Customize {product.name}</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
            <Button 
              onClick={handleAddToCart}
              disabled={!selectedVariant || !designUrl}
              className="bg-gradient-to-r from-cyan-500 to-cyan-600 hover:from-cyan-600 hover:to-cyan-700"
            >
              <ShoppingCart className="w-4 h-4 mr-2" />
              Add to Cart
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Design Tools */}
          <div className="lg:col-span-1 space-y-6">
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Design Tools</h3>
              
              <Tabs defaultValue="upload" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="upload" className="text-xs">
                    <Upload className="w-4 h-4 mr-1" />
                    Upload
                  </TabsTrigger>
                  <TabsTrigger value="text" className="text-xs">
                    <Type className="w-4 h-4 mr-1" />
                    Text
                  </TabsTrigger>
                  <TabsTrigger value="graphics" className="text-xs">
                    <Image className="w-4 h-4 mr-1" />
                    Graphics
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="upload" className="space-y-4">
                  <div>
                    <Label>Upload Design</Label>
                    <div className="mt-2">
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/*"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) handleFileUpload(file);
                        }}
                        className="hidden"
                      />
                      <Button
                        variant="outline"
                        onClick={() => fileInputRef.current?.click()}
                        className="w-full"
                      >
                        <Upload className="w-4 h-4 mr-2" />
                        Choose File
                      </Button>
                    </div>
                    {designFile && (
                      <p className="text-sm text-gray-600 mt-2">
                        {designFile.name}
                      </p>
                    )}
                  </div>
                </TabsContent>

                <TabsContent value="text" className="space-y-4">
                  <div>
                    <Label htmlFor="design-text">Text</Label>
                    <textarea
                      id="design-text"
                      value={designText}
                      onChange={(e) => setDesignText(e.target.value)}
                      placeholder="Enter your text..."
                      className="w-full h-24 px-3 py-2 border border-gray-300 rounded-md resize-none"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="font-size">Size</Label>
                      <Input
                        id="font-size"
                        type="number"
                        value={fontSize}
                        onChange={(e) => setFontSize(Number(e.target.value))}
                        min="12"
                        max="200"
                      />
                    </div>
                    <div>
                      <Label htmlFor="font-color">Color</Label>
                      <div className="flex gap-2">
                        <Input
                          id="font-color"
                          type="color"
                          value={fontColor}
                          onChange={(e) => setFontColor(e.target.value)}
                          className="w-12 h-8 p-0 border-0"
                        />
                        <Input
                          value={fontColor}
                          onChange={(e) => setFontColor(e.target.value)}
                          className="flex-1 text-sm"
                        />
                      </div>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="bg-color">Background</Label>
                    <div className="flex gap-2">
                      <Input
                        id="bg-color"
                        type="color"
                        value={backgroundColor}
                        onChange={(e) => setBackgroundColor(e.target.value)}
                        className="w-12 h-8 p-0 border-0"
                      />
                      <Input
                        value={backgroundColor}
                        onChange={(e) => setBackgroundColor(e.target.value)}
                        className="flex-1 text-sm"
                      />
                    </div>
                  </div>

                  <Button
                    onClick={generateTextDesign}
                    disabled={!designText.trim()}
                    className="w-full"
                  >
                    <Play className="w-4 h-4 mr-2" />
                    Generate Design
                  </Button>
                </TabsContent>

                <TabsContent value="graphics" className="space-y-4">
                  <div className="text-center py-8 text-gray-500">
                    <Image className="w-12 h-12 mx-auto mb-2 opacity-50" />
                    <p>Graphics library coming soon!</p>
                    <p className="text-sm">Upload your own designs for now.</p>
                  </div>
                </TabsContent>
              </Tabs>
            </Card>

            {/* Placement Options */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Placement</h3>
              <div className="grid grid-cols-2 gap-2">
                {(['front', 'back', 'left', 'right'] as const).map((pos) => (
                  <Button
                    key={pos}
                    variant={placement === pos ? "default" : "outline"}
                    onClick={() => setPlacement(pos)}
                    className="capitalize"
                  >
                    {pos}
                  </Button>
                ))}
              </div>
            </Card>

            {/* Product Variants */}
            {variants.length > 0 && (
              <Card className="p-6">
                <h3 className="text-lg font-semibold mb-4">Product Options</h3>
                <div className="space-y-4">
                  {variants.map((variant) => (
                    <div
                      key={variant.id}
                      className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                        selectedVariant?.id === variant.id
                          ? 'border-cyan-500 bg-cyan-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                      onClick={() => setSelectedVariant(variant)}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium text-sm">{variant.name}</p>
                          <p className="text-sm text-gray-600">
                            {printfulHelpers.formatPrice(variant.retail_price)}
                          </p>
                        </div>
                        {variant.product.image && (
                          <img
                            src={variant.product.image}
                            alt={variant.name}
                            className="w-12 h-12 object-cover rounded"
                          />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            )}
          </div>

          {/* Preview Area */}
          <div className="lg:col-span-2">
            <Card className="p-6 h-full">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold">Preview</h3>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    <ZoomOut className="w-4 h-4" />
                  </Button>
                  <Button variant="outline" size="sm">
                    <ZoomIn className="w-4 h-4" />
                  </Button>
                  <Button variant="outline" size="sm">
                    <RotateCcw className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <div className="flex items-center justify-center min-h-96 bg-gray-100 rounded-lg relative">
                {loading && (
                  <div className="absolute inset-0 flex items-center justify-center bg-white/80 z-10">
                    <div className="text-center">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-500 mx-auto mb-2"></div>
                      <p className="text-sm text-gray-600">Processing...</p>
                    </div>
                  </div>
                )}

                {mockupUrl ? (
                  <img
                    src={mockupUrl}
                    alt="Product mockup"
                    className="max-w-full max-h-96 object-contain"
                  />
                ) : selectedVariant?.product.image ? (
                  <div className="text-center">
                    <img
                      src={selectedVariant.product.image}
                      alt={product.name}
                      className="max-w-full max-h-96 object-contain mb-4"
                    />
                    <p className="text-gray-500">
                      {designUrl ? 'Generating mockup...' : 'Upload a design to see preview'}
                    </p>
                  </div>
                ) : (
                  <div className="text-center text-gray-500">
                    <div className="w-24 h-24 mx-auto mb-4 bg-gray-300 rounded-lg flex items-center justify-center">
                      <Eye className="w-12 h-12" />
                    </div>
                    <p>Select a product variant to preview</p>
                  </div>
                )}
              </div>

              {error && (
                <div className="mt-4 p-3 bg-red-100 border border-red-300 rounded-lg">
                  <p className="text-red-700 text-sm">{error}</p>
                </div>
              )}
            </Card>
          </div>
        </div>

        {/* Hidden Canvas for Text Generation */}
        <canvas
          ref={canvasRef}
          className="hidden"
          width="1000"
          height="1000"
        />
      </div>
    </div>
  );
}

export default PrintfulDesignStudio;