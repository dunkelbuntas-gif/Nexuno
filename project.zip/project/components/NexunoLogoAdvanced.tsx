import React from 'react';
import nexunoLogo from 'figma:asset/dc274090c09a9c81d77ec4f6306cfa2f84599213.png';

interface NexunoLogoAdvancedProps {
  size?: number;
  onClick?: () => void;
  className?: string;
  variant?: 'clean' | 'glow' | 'hero';
}

export function NexunoLogoAdvanced({ 
  size = 48, 
  onClick,
  className = '',
  variant = 'clean'
}: NexunoLogoAdvancedProps) {
  
  const getVariantStyle = () => {
    const baseStyle: React.CSSProperties = {
      width: `${size}px`,
      height: 'auto',
      maxWidth: '100%',
      transition: 'all 0.4s cubic-bezier(0.4, 0, 0.2, 1)',
      display: 'block',
    };

    switch (variant) {
      case 'clean':
        return {
          ...baseStyle,
          // Verwende moderne CSS-Filter für saubere Hintergrundentfernung
          filter: 'brightness(1.1) contrast(1.2) saturate(1.05)',
          background: 'transparent',
          // Experimenteller Ansatz: Entferne Grau mit Color-Adjustments
          WebkitFilter: 'brightness(1.1) contrast(1.2) saturate(1.05) hue-rotate(0deg)',
        };
      
      case 'glow':
        return {
          ...baseStyle,
          filter: 'brightness(1.2) contrast(1.3) saturate(1.1) drop-shadow(0 0 20px rgba(30, 58, 138, 0.4)) drop-shadow(0 0 40px rgba(6, 182, 212, 0.2))',
          background: 'transparent',
        };
      
      case 'hero':
        return {
          ...baseStyle,
          filter: 'brightness(1.3) contrast(1.4) saturate(1.2) drop-shadow(0 0 30px rgba(30, 58, 138, 0.5)) drop-shadow(0 0 60px rgba(6, 182, 212, 0.3))',
          background: 'transparent',
        };
      
      default:
        return baseStyle;
    }
  };

  const containerClass = onClick 
    ? "relative group transition-all duration-500 hover:scale-105 cursor-pointer" 
    : "relative";

  return (
    <div className={`${containerClass} ${className}`} onClick={onClick}>
      {/* Logo mit Hintergrund-Bereinigung */}
      <div 
        className="relative overflow-hidden"
        style={{
          borderRadius: '12px',
          background: 'transparent',
        }}
      >
        {/* Hauptbild mit CSS-basierten Optimierungen */}
        <img
          src={nexunoLogo}
          alt="Nexuno - Fashion der Zukunft"
          style={getVariantStyle()}
          onLoad={(e) => {
            // Zusätzliche Bildoptimierung nach dem Laden
            const img = e.target as HTMLImageElement;
            img.style.imageRendering = 'crisp-edges';
          }}
        />
        
        {/* Overlay um graue Bereiche zu kaschieren */}
        <div 
          className="absolute inset-0 pointer-events-none"
          style={{
            // Subtiler Overlay der nur die Ränder betrifft
            background: `
              radial-gradient(circle at 50% 50%, transparent 40%, 
              ${variant === 'hero' ? 'rgba(248, 250, 252, 0.1)' : 'transparent'} 80%)
            `,
            mixBlendMode: 'soft-light',
            opacity: 0.3,
          }}
        />
      </div>
      
      {/* Hover-Glow-Effekt */}
      {onClick && (
        <div 
          className="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 transition-all duration-500 pointer-events-none"
          style={{
            background: 'radial-gradient(circle, rgba(30, 58, 138, 0.1) 0%, transparent 70%)',
            filter: 'blur(12px)',
            transform: 'scale(1.4)',
            zIndex: -1,
          }}
        />
      )}
      
      {/* Architektonische Akzente bei Hero-Variant */}
      {variant === 'hero' && (
        <>
          <div className="absolute top-1 left-1 w-2 h-2 border-l border-t border-blue-300/40 rounded-tl-sm" />
          <div className="absolute top-1 right-1 w-2 h-2 border-r border-t border-blue-300/40 rounded-tr-sm" />
          <div className="absolute bottom-1 left-1 w-2 h-2 border-l border-b border-cyan-300/40 rounded-bl-sm" />
          <div className="absolute bottom-1 right-1 w-2 h-2 border-r border-b border-cyan-300/40 rounded-br-sm" />
        </>
      )}
    </div>
  );
}

// Alternative mit CSS-Masking für präzise Hintergrundentfernung
export function NexunoLogoPrecise({ 
  size = 48, 
  onClick,
  className = ''
}: {
  size?: number;
  onClick?: () => void;
  className?: string;
}) {
  return (
    <div 
      className={`relative ${onClick ? 'cursor-pointer hover:scale-105' : ''} transition-transform duration-300 ${className}`}
      onClick={onClick}
    >
      <div
        style={{
          width: `${size}px`,
          height: `${size}px`,
          background: `url(${nexunoLogo}) center/contain no-repeat`,
          
          // Präzise Maske für das Nexuno Logo
          maskImage: `
            radial-gradient(ellipse 80% 60% at 50% 35%, black 50%, transparent 85%),
            linear-gradient(to bottom, black 0%, black 85%, transparent 100%)
          `,
          WebkitMaskImage: `
            radial-gradient(ellipse 80% 60% at 50% 35%, black 50%, transparent 85%),
            linear-gradient(to bottom, black 0%, black 85%, transparent 100%)
          `,
          maskComposite: 'intersect',
          WebkitMaskComposite: 'source-in',
          
          // Zusätzliche Optimierungen
          filter: 'brightness(1.1) contrast(1.2) saturate(1.05)',
          transition: 'all 0.3s ease',
        }}
      />
    </div>
  );
}

// Experimental: CSS-Only Background Removal
export function NexunoLogoCSSOnly({ 
  size = 48, 
  onClick,
  className = ''
}: {
  size?: number;
  onClick?: () => void;
  className?: string;
}) {
  return (
    <div 
      className={`relative ${onClick ? 'cursor-pointer' : ''} ${className}`}
      onClick={onClick}
    >
      <div
        className="relative overflow-hidden rounded-lg"
        style={{ width: `${size}px`, height: `${size}px` }}
      >
        <img
          src={nexunoLogo}
          alt="Nexuno"
          className="w-full h-full object-contain"
          style={{
            // Experimenteller Filter-Stack für Hintergrundentfernung
            filter: `
              brightness(1.1) 
              contrast(1.3) 
              saturate(1.1)
              hue-rotate(0deg)
              opacity(0.95)
            `,
            // Verwende Blending um grauen Hintergrund zu minimieren
            mixBlendMode: 'multiply',
            // Zusätzliche Masking
            maskImage: 'radial-gradient(circle, black 70%, transparent 95%)',
            WebkitMaskImage: 'radial-gradient(circle, black 70%, transparent 95%)',
          }}
        />
        
        {/* White overlay um Grau zu neutralisieren */}
        <div 
          className="absolute inset-0 pointer-events-none"
          style={{
            background: 'radial-gradient(circle, transparent 50%, rgba(248, 250, 252, 0.8) 90%)',
            mixBlendMode: 'screen',
            opacity: 0.6,
          }}
        />
      </div>
    </div>
  );
}