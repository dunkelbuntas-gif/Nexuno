import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowLeft, 
  ArrowRight, 
  Check, 
  CreditCard, 
  Truck, 
  Shield, 
  MapPin, 
  User, 
  Mail, 
  Phone,
  Lock,
  Package
} from 'lucide-react';
import { useCart } from './CartContext';
import { Button } from '../ui/button';
import { Card } from '../ui/card';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Separator } from '../ui/separator';
import { RadioGroup, RadioGroupItem } from '../ui/radio-group';
import { Checkbox } from '../ui/checkbox';
import { toast } from 'sonner@2.0.3';

interface CheckoutProcessProps {
  onBack?: () => void;
  onComplete?: (orderData: any) => void;
}

type CheckoutStep = 'shipping' | 'payment' | 'review' | 'complete';

interface OrderData {
  shipping: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    address: string;
    city: string;
    postalCode: string;
    country: string;
  };
  payment: {
    method: string;
    cardNumber?: string;
    expiryDate?: string;
    cvv?: string;
  };
  terms: boolean;
  newsletter: boolean;
}

export function CheckoutProcess({ onBack, onComplete }: CheckoutProcessProps) {
  const [currentStep, setCurrentStep] = useState<CheckoutStep>('shipping');
  const [isProcessing, setIsProcessing] = useState(false);
  const { state, clearCart } = useCart();

  const [orderData, setOrderData] = useState<OrderData>({
    shipping: {
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      address: '',
      city: '',
      postalCode: '',
      country: 'Deutschland'
    },
    payment: {
      method: 'card'
    },
    terms: false,
    newsletter: false
  });

  const steps = [
    { id: 'shipping', title: 'Versand', icon: Truck },
    { id: 'payment', title: 'Zahlung', icon: CreditCard },
    { id: 'review', title: 'Prüfen', icon: Check },
    { id: 'complete', title: 'Fertig', icon: Package }
  ];

  const formatPrice = (price: number | string) => {
    const numPrice = typeof price === 'string' ? parseFloat(price.replace('€', '')) : price;
    return `€${numPrice.toFixed(2)}`;
  };

  const getItemTotal = (price: number | string, quantity: number) => {
    const numPrice = typeof price === 'string' ? parseFloat(price.replace('€', '')) : price;
    return numPrice * quantity;
  };

  const subtotal = state.items.reduce((sum, item) => sum + getItemTotal(item.price, item.quantity), 0);
  const shipping = subtotal >= 69 ? 0 : 4.99;
  const tax = subtotal * 0.19;
  const total = subtotal + shipping + tax;

  const currentStepIndex = steps.findIndex(step => step.id === currentStep);

  const handleNext = () => {
    if (currentStep === 'shipping') {
      if (!validateShipping()) return;
      setCurrentStep('payment');
    } else if (currentStep === 'payment') {
      if (!validatePayment()) return;
      setCurrentStep('review');
    } else if (currentStep === 'review') {
      if (!orderData.terms) {
        toast.error('Bitte akzeptieren Sie die AGB');
        return;
      }
      handleSubmitOrder();
    }
  };

  const handleBack = () => {
    if (currentStep === 'shipping') {
      onBack?.();
    } else if (currentStep === 'payment') {
      setCurrentStep('shipping');
    } else if (currentStep === 'review') {
      setCurrentStep('payment');
    }
  };

  const validateShipping = () => {
    const { firstName, lastName, email, address, city, postalCode } = orderData.shipping;
    
    if (!firstName || !lastName || !email || !address || !city || !postalCode) {
      toast.error('Bitte füllen Sie alle Pflichtfelder aus');
      return false;
    }
    
    if (!/\S+@\S+\.\S+/.test(email)) {
      toast.error('Bitte geben Sie eine gültige E-Mail-Adresse ein');
      return false;
    }
    
    return true;
  };

  const validatePayment = () => {
    if (orderData.payment.method === 'card') {
      const { cardNumber, expiryDate, cvv } = orderData.payment;
      
      if (!cardNumber || !expiryDate || !cvv) {
        toast.error('Bitte füllen Sie alle Kartendetails aus');
        return false;
      }
      
      if (cardNumber.replace(/\s/g, '').length < 16) {
        toast.error('Kartennummer ist ungültig');
        return false;
      }
    }
    
    return true;
  };

  const handleSubmitOrder = async () => {
    setIsProcessing(true);
    
    try {
      // Simulate order processing
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      setCurrentStep('complete');
      clearCart();
      
      const completeOrderData = {
        ...orderData,
        items: state.items,
        total,
        orderNumber: `NX-${Date.now()}`,
        timestamp: new Date().toISOString()
      };
      
      onComplete?.(completeOrderData);
      toast.success('Bestellung erfolgreich aufgegeben!');
      
    } catch (error) {
      toast.error('Fehler beim Aufgeben der Bestellung');
    } finally {
      setIsProcessing(false);
    }
  };

  const updateShipping = (field: keyof OrderData['shipping'], value: string) => {
    setOrderData(prev => ({
      ...prev,
      shipping: { ...prev.shipping, [field]: value }
    }));
  };

  const updatePayment = (field: keyof OrderData['payment'], value: string) => {
    setOrderData(prev => ({
      ...prev,
      payment: { ...prev.payment, [field]: value }
    }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-gray-100">
      {/* Header with Progress */}
      <div className="bg-white/80 backdrop-blur-sm border-b border-gray-200/50 sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="py-6">
            {/* Back Button */}
            <Button
              variant="ghost"
              onClick={handleBack}
              className="mb-6 p-2 hover:bg-gray-100"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              Zurück
            </Button>

            {/* Progress Steps */}
            <div className="flex items-center justify-between mb-4">
              {steps.map((step, index) => {
                const Icon = step.icon;
                const isActive = step.id === currentStep;
                const isCompleted = index < currentStepIndex;
                
                return (
                  <div key={step.id} className="flex items-center">
                    <div className={`
                      relative flex items-center justify-center w-10 h-10 rounded-full border-2 transition-all duration-300
                      ${isActive ? 'border-cyan-500 bg-cyan-500 text-white' : 
                        isCompleted ? 'border-green-500 bg-green-500 text-white' : 
                        'border-gray-300 bg-white text-gray-400'}
                    `}>
                      <Icon className="w-5 h-5" />
                    </div>
                    
                    <span className={`
                      ml-3 text-sm font-medium
                      ${isActive ? 'text-cyan-600' : 
                        isCompleted ? 'text-green-600' : 
                        'text-gray-500'}
                    `}>
                      {step.title}
                    </span>
                    
                    {index < steps.length - 1 && (
                      <div className={`
                        flex-1 h-0.5 mx-4 transition-all duration-300
                        ${isCompleted ? 'bg-green-500' : 'bg-gray-300'}
                      `} />
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <AnimatePresence mode="wait">
              {/* Shipping Step */}
              {currentStep === 'shipping' && (
                <motion.div
                  key="shipping"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                >
                  <Card className="p-6 bg-white/80 backdrop-blur-sm">
                    <div className="flex items-center gap-3 mb-6">
                      <Truck className="w-6 h-6 text-cyan-600" />
                      <h2 className="text-xl font-semibold text-gray-900">Versandadresse</h2>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="firstName">Vorname *</Label>
                        <Input
                          id="firstName"
                          value={orderData.shipping.firstName}
                          onChange={(e) => updateShipping('firstName', e.target.value)}
                          className="mt-1"
                        />
                      </div>
                      
                      <div>
                        <Label htmlFor="lastName">Nachname *</Label>
                        <Input
                          id="lastName"
                          value={orderData.shipping.lastName}
                          onChange={(e) => updateShipping('lastName', e.target.value)}
                          className="mt-1"
                        />
                      </div>
                      
                      <div className="md:col-span-2">
                        <Label htmlFor="email">E-Mail-Adresse *</Label>
                        <Input
                          id="email"
                          type="email"
                          value={orderData.shipping.email}
                          onChange={(e) => updateShipping('email', e.target.value)}
                          className="mt-1"
                        />
                      </div>
                      
                      <div className="md:col-span-2">
                        <Label htmlFor="phone">Telefonnummer</Label>
                        <Input
                          id="phone"
                          type="tel"
                          value={orderData.shipping.phone}
                          onChange={(e) => updateShipping('phone', e.target.value)}
                          className="mt-1"
                        />
                      </div>
                      
                      <div className="md:col-span-2">
                        <Label htmlFor="address">Straße und Hausnummer *</Label>
                        <Input
                          id="address"
                          value={orderData.shipping.address}
                          onChange={(e) => updateShipping('address', e.target.value)}
                          className="mt-1"
                        />
                      </div>
                      
                      <div>
                        <Label htmlFor="postalCode">PLZ *</Label>
                        <Input
                          id="postalCode"
                          value={orderData.shipping.postalCode}
                          onChange={(e) => updateShipping('postalCode', e.target.value)}
                          className="mt-1"
                        />
                      </div>
                      
                      <div>
                        <Label htmlFor="city">Stadt *</Label>
                        <Input
                          id="city"
                          value={orderData.shipping.city}
                          onChange={(e) => updateShipping('city', e.target.value)}
                          className="mt-1"
                        />
                      </div>
                    </div>
                  </Card>
                </motion.div>
              )}

              {/* Payment Step */}
              {currentStep === 'payment' && (
                <motion.div
                  key="payment"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                >
                  <Card className="p-6 bg-white/80 backdrop-blur-sm">
                    <div className="flex items-center gap-3 mb-6">
                      <CreditCard className="w-6 h-6 text-cyan-600" />
                      <h2 className="text-xl font-semibold text-gray-900">Zahlungsmethode</h2>
                    </div>

                    <RadioGroup 
                      value={orderData.payment.method} 
                      onValueChange={(value) => updatePayment('method', value)}
                      className="space-y-4 mb-6"
                    >
                      <div className="flex items-center space-x-2 p-4 border rounded-lg">
                        <RadioGroupItem value="card" id="card" />
                        <Label htmlFor="card" className="flex items-center gap-3 cursor-pointer">
                          <CreditCard className="w-5 h-5" />
                          <span>Kreditkarte</span>
                        </Label>
                      </div>
                      
                      <div className="flex items-center space-x-2 p-4 border rounded-lg">
                        <RadioGroupItem value="paypal" id="paypal" />
                        <Label htmlFor="paypal" className="flex items-center gap-3 cursor-pointer">
                          <div className="w-5 h-5 bg-blue-600 rounded text-white text-xs flex items-center justify-center">P</div>
                          <span>PayPal</span>
                        </Label>
                      </div>
                      
                      <div className="flex items-center space-x-2 p-4 border rounded-lg">
                        <RadioGroupItem value="klarna" id="klarna" />
                        <Label htmlFor="klarna" className="flex items-center gap-3 cursor-pointer">
                          <div className="w-5 h-5 bg-pink-500 rounded text-white text-xs flex items-center justify-center">K</div>
                          <span>Klarna</span>
                        </Label>
                      </div>
                    </RadioGroup>

                    {/* Credit Card Form */}
                    {orderData.payment.method === 'card' && (
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="cardNumber">Kartennummer *</Label>
                          <Input
                            id="cardNumber"
                            placeholder="1234 5678 9012 3456"
                            value={orderData.payment.cardNumber || ''}
                            onChange={(e) => {
                              const value = e.target.value.replace(/\D/g, '').replace(/(.{4})/g, '$1 ').trim();
                              updatePayment('cardNumber', value);
                            }}
                            maxLength={19}
                            className="mt-1"
                          />
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="expiryDate">Ablaufdatum *</Label>
                            <Input
                              id="expiryDate"
                              placeholder="MM/YY"
                              value={orderData.payment.expiryDate || ''}
                              onChange={(e) => {
                                const value = e.target.value.replace(/\D/g, '').replace(/(.{2})/, '$1/');
                                updatePayment('expiryDate', value);
                              }}
                              maxLength={5}
                              className="mt-1"
                            />
                          </div>
                          
                          <div>
                            <Label htmlFor="cvv">CVV *</Label>
                            <Input
                              id="cvv"
                              placeholder="123"
                              value={orderData.payment.cvv || ''}
                              onChange={(e) => {
                                const value = e.target.value.replace(/\D/g, '');
                                updatePayment('cvv', value);
                              }}
                              maxLength={4}
                              className="mt-1"
                            />
                          </div>
                        </div>
                      </div>
                    )}
                  </Card>
                </motion.div>
              )}

              {/* Review Step */}
              {currentStep === 'review' && (
                <motion.div
                  key="review"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
                  {/* Order Review */}
                  <Card className="p-6 bg-white/80 backdrop-blur-sm">
                    <h2 className="text-xl font-semibold text-gray-900 mb-4">Bestellung prüfen</h2>
                    
                    {/* Items */}
                    <div className="space-y-3 mb-6">
                      {state.items.map((item) => (
                        <div key={`${item.id}-${item.size}-${item.color}`} className="flex items-center gap-4 p-3 border rounded-lg">
                          <img src={item.image} alt={item.name} className="w-16 h-16 object-cover rounded" />
                          <div className="flex-1">
                            <h4 className="font-medium text-gray-900">{item.name}</h4>
                            <p className="text-sm text-gray-600">
                              {item.size && `Größe: ${item.size}`} {item.color && `• Farbe: ${item.color}`}
                            </p>
                            <p className="text-sm text-gray-600">Menge: {item.quantity}</p>
                          </div>
                          <div className="text-right">
                            <p className="font-semibold">{formatPrice(getItemTotal(item.price, item.quantity))}</p>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Addresses */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                      <div>
                        <h3 className="font-semibold text-gray-900 mb-2">Versandadresse</h3>
                        <div className="text-sm text-gray-600">
                          <p>{orderData.shipping.firstName} {orderData.shipping.lastName}</p>
                          <p>{orderData.shipping.address}</p>
                          <p>{orderData.shipping.postalCode} {orderData.shipping.city}</p>
                          <p>{orderData.shipping.email}</p>
                        </div>
                      </div>
                      
                      <div>
                        <h3 className="font-semibold text-gray-900 mb-2">Zahlungsmethode</h3>
                        <div className="text-sm text-gray-600">
                          {orderData.payment.method === 'card' && (
                            <p>Kreditkarte **** {orderData.payment.cardNumber?.slice(-4)}</p>
                          )}
                          {orderData.payment.method === 'paypal' && <p>PayPal</p>}
                          {orderData.payment.method === 'klarna' && <p>Klarna</p>}
                        </div>
                      </div>
                    </div>

                    {/* Terms and Newsletter */}
                    <div className="space-y-4 pt-4 border-t">
                      <div className="flex items-center space-x-2">
                        <Checkbox 
                          id="terms" 
                          checked={orderData.terms}
                          onCheckedChange={(checked) => setOrderData(prev => ({ ...prev, terms: !!checked }))}
                        />
                        <Label htmlFor="terms" className="text-sm">
                          Ich akzeptiere die <button className="text-cyan-600 underline">AGB</button> und <button className="text-cyan-600 underline">Datenschutzerklärung</button> *
                        </Label>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <Checkbox 
                          id="newsletter" 
                          checked={orderData.newsletter}
                          onCheckedChange={(checked) => setOrderData(prev => ({ ...prev, newsletter: !!checked }))}
                        />
                        <Label htmlFor="newsletter" className="text-sm">
                          Ich möchte den Newsletter erhalten und über neue Produkte informiert werden
                        </Label>
                      </div>
                    </div>
                  </Card>
                </motion.div>
              )}

              {/* Complete Step */}
              {currentStep === 'complete' && (
                <motion.div
                  key="complete"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                >
                  <Card className="p-8 bg-white/80 backdrop-blur-sm text-center">
                    <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                      <Check className="w-8 h-8 text-green-600" />
                    </div>
                    
                    <h2 className="text-2xl font-bold text-gray-900 mb-4">
                      Bestellung erfolgreich!
                    </h2>
                    
                    <p className="text-gray-600 mb-6">
                      Ihre Bestellung wurde erfolgreich aufgegeben. Sie erhalten in Kürze eine Bestätigungs-E-Mail.
                    </p>
                    
                    <div className="bg-gray-50 rounded-lg p-4 mb-6">
                      <p className="text-sm text-gray-600">Bestellnummer</p>
                      <p className="font-mono font-semibold text-lg">NX-{Date.now()}</p>
                    </div>
                    
                    <Button
                      onClick={onBack}
                      className="bg-gradient-to-r from-cyan-500 to-cyan-600 hover:from-cyan-600 hover:to-cyan-700 text-white"
                    >
                      Zurück zum Shop
                    </Button>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Navigation Buttons */}
            {currentStep !== 'complete' && (
              <div className="flex justify-between mt-8">
                <Button
                  variant="outline"
                  onClick={handleBack}
                  className="flex items-center gap-2"
                >
                  <ArrowLeft className="w-4 h-4" />
                  Zurück
                </Button>
                
                <Button
                  onClick={handleNext}
                  disabled={isProcessing}
                  className="flex items-center gap-2 bg-gradient-to-r from-cyan-500 to-cyan-600 hover:from-cyan-600 hover:to-cyan-700 text-white"
                >
                  {isProcessing ? (
                    'Wird verarbeitet...'
                  ) : currentStep === 'review' ? (
                    <>
                      <Lock className="w-4 h-4" />
                      Jetzt kaufen
                    </>
                  ) : (
                    <>
                      Weiter
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </Button>
              </div>
            )}
          </div>

          {/* Order Summary Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-24">
              <Card className="p-6 bg-white/80 backdrop-blur-sm">
                <h3 className="font-semibold text-gray-900 mb-4">Bestellübersicht</h3>
                
                <div className="space-y-3 mb-4">
                  <div className="flex justify-between text-sm">
                    <span>Zwischensumme</span>
                    <span>{formatPrice(subtotal)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Versand</span>
                    <span>{shipping === 0 ? 'Kostenlos' : formatPrice(shipping)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>MwSt. (19%)</span>
                    <span>{formatPrice(tax)}</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between font-semibold">
                    <span>Gesamt</span>
                    <span>{formatPrice(total)}</span>
                  </div>
                </div>

                {/* Trust Badges */}
                <div className="pt-4 border-t border-gray-200">
                  <div className="space-y-2 text-xs text-gray-600">
                    <div className="flex items-center gap-2">
                      <Shield className="w-4 h-4 text-green-600" />
                      <span>SSL-verschlüsselt</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Truck className="w-4 h-4 text-blue-600" />
                      <span>Kostenloser Versand ab €69</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Package className="w-4 h-4 text-purple-600" />
                      <span>14 Tage Rückgaberecht</span>
                    </div>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}