import React from 'react';
import { Toaster } from './components/ui/sonner';
import { FashionStorePage } from './components/FashionStorePage';

// Richtiges CSS importieren (liegt direkt im src-Ordner)
import './styles.css';

export default function App() {
  return (
    <div className="min-h-screen bg-slate-950">
      <FashionStorePage 
        // Wenn deine Komponente Props erwartet, hier ergänzen:
        onNavigate={() => {}} 
      />
      
      {/* Toaster Notifications */}
      <Toaster position="top-right" closeButton richColors theme="dark" />
    </div>
  );
}