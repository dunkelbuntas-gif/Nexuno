import React from 'react';
import { motion } from 'motion/react';
import { MotionButton, MotionCard, FloatingElement, PulseGlow, MagneticElement, MotionStaggerContainer } from './MotionInteractions';
import { MotionSpinner, MotionDots, MotionSkeleton, MotionTypewriter, MotionSuccessCheckmark } from './AdvancedLoading';
import { DraggableElement, SwipeableCard, TapToExpand, HoverMagnify, LongPressButton } from './GestureInteractions';
import { MotionParallax, MotionScrollReveal } from './MotionParallax';

export function MotionDemo() {
  const [showSuccess, setShowSuccess] = React.useState(false);
  const [isLoading, setIsLoading] = React.useState(false);

  const handleLongPress = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 3000);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 py-20">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Header */}
        <MotionScrollReveal direction="up" className="text-center mb-16">
          <h1 className="text-4xl md:text-6xl font-bold text-slate-900 mb-6">
            <MotionTypewriter 
              text="STUFE 3 Motion Demo" 
              speed={80}
            />
          </h1>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Erlebe alle erweiterten Motion-Animationen in Aktion - von Parallax-Effekten bis zu Gesture-Interaktionen
          </p>
        </MotionScrollReveal>

        {/* Interactive Buttons Section */}
        <MotionScrollReveal direction="up" delay={0.2} className="mb-20">
          <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-200">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Interactive Buttons</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <MotionButton variant="primary" size="lg">
                Primary Button
              </MotionButton>
              <MotionButton variant="secondary" size="lg">
                Secondary Button
              </MotionButton>
              <MotionButton variant="outline" size="lg">
                Outline Button
              </MotionButton>
              <MotionButton variant="tech" size="lg">
                Tech Button
              </MotionButton>
            </div>
          </div>
        </MotionScrollReveal>

        {/* Cards with Hover Effects */}
        <MotionScrollReveal direction="up" delay={0.3} className="mb-20">
          <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-200">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Interactive Cards</h2>
            <MotionStaggerContainer staggerDelay={0.1} className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <MotionCard hoverEffect="lift" className="bg-gradient-to-br from-cyan-500 to-blue-600 p-6 rounded-xl text-white">
                <h3 className="text-xl font-semibold mb-2">Lift Effect</h3>
                <p>Hover mich für einen Lift-Effekt</p>
              </MotionCard>
              
              <MotionCard hoverEffect="glow" className="bg-gradient-to-br from-green-500 to-teal-600 p-6 rounded-xl text-white">
                <h3 className="text-xl font-semibold mb-2">Glow Effect</h3>
                <p>Hover mich für einen Glow-Effekt</p>
              </MotionCard>
              
              <MotionCard hoverEffect="tilt" className="bg-gradient-to-br from-purple-500 to-pink-600 p-6 rounded-xl text-white">
                <h3 className="text-xl font-semibold mb-2">Tilt Effect</h3>
                <p>Hover mich für einen 3D-Tilt</p>
              </MotionCard>
            </MotionStaggerContainer>
          </div>
        </MotionScrollReveal>

        {/* Gesture Interactions */}
        <MotionScrollReveal direction="up" delay={0.4} className="mb-20">
          <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-200">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Gesture Interactions</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              
              {/* Draggable Element */}
              <div className="text-center">
                <h3 className="text-lg font-semibold mb-4 text-slate-700">Draggable</h3>
                <DraggableElement className="mx-auto">
                  <div className="w-24 h-24 bg-gradient-to-br from-orange-400 to-red-500 rounded-xl flex items-center justify-center text-white font-bold shadow-lg">
                    Drag me!
                  </div>
                </DraggableElement>
              </div>

              {/* Swipeable Card */}
              <div className="text-center">
                <h3 className="text-lg font-semibold mb-4 text-slate-700">Swipeable</h3>
                <SwipeableCard
                  onSwipeLeft={() => console.log('Swiped left!')}
                  onSwipeRight={() => console.log('Swiped right!')}
                  className="mx-auto"
                >
                  <div className="w-24 h-24 bg-gradient-to-br from-blue-400 to-indigo-500 rounded-xl flex items-center justify-center text-white font-bold shadow-lg">
                    Swipe me!
                  </div>
                </SwipeableCard>
              </div>

              {/* Long Press */}
              <div className="text-center">
                <h3 className="text-lg font-semibold mb-4 text-slate-700">Long Press</h3>
                <LongPressButton
                  onLongPress={handleLongPress}
                  duration={2000}
                  className="mx-auto"
                >
                  <div className="w-24 h-24 bg-gradient-to-br from-green-400 to-emerald-500 rounded-xl flex items-center justify-center text-white font-bold shadow-lg">
                    Hold me!
                  </div>
                </LongPressButton>
              </div>
            </div>
          </div>
        </MotionScrollReveal>

        {/* Loading States */}
        <MotionScrollReveal direction="up" delay={0.5} className="mb-20">
          <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-200">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Loading States</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <h3 className="text-lg font-semibold mb-4 text-slate-700">Spinner</h3>
                <MotionSpinner size="lg" color="cyan" className="mx-auto" />
              </div>
              
              <div className="text-center">
                <h3 className="text-lg font-semibold mb-4 text-slate-700">Dots</h3>
                <MotionDots size="lg" color="green" className="mx-auto" />
              </div>
              
              <div className="text-center">
                <h3 className="text-lg font-semibold mb-4 text-slate-700">Success</h3>
                <MotionSuccessCheckmark 
                  isVisible={showSuccess} 
                  size="lg" 
                  className="mx-auto"
                />
              </div>
            </div>
          </div>
        </MotionScrollReveal>

        {/* Floating Elements */}
        <MotionScrollReveal direction="up" delay={0.6} className="mb-20">
          <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-200 relative overflow-hidden min-h-[300px]">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Floating Elements</h2>
            
            {/* Floating Elements */}
            <FloatingElement intensity="subtle" delay={0} className="absolute top-16 left-16">
              <PulseGlow color="cyan" intensity={0.4}>
                <div className="w-8 h-8 bg-cyan-400 rounded-full"></div>
              </PulseGlow>
            </FloatingElement>
            
            <FloatingElement intensity="medium" delay={1} className="absolute top-20 right-20">
              <PulseGlow color="green" intensity={0.5}>
                <div className="w-12 h-12 bg-green-400 rounded-full"></div>
              </PulseGlow>
            </FloatingElement>
            
            <FloatingElement intensity="strong" delay={2} className="absolute bottom-16 left-1/2 transform -translate-x-1/2">
              <PulseGlow color="orange" intensity={0.6}>
                <div className="w-10 h-10 bg-orange-400 rounded-full"></div>
              </PulseGlow>
            </FloatingElement>

            <div className="text-center pt-12">
              <p className="text-slate-600">Schau dir die schwebenden Elemente an!</p>
            </div>
          </div>
        </MotionScrollReveal>

        {/* Magnetic Elements */}
        <MotionScrollReveal direction="up" delay={0.7} className="mb-20">
          <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-200">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Magnetic Interaction</h2>
            <div className="text-center">
              <p className="text-slate-600 mb-8">Bewege deine Maus über die Elemente um sie zu "magnetisieren"</p>
              <div className="flex justify-center space-x-8">
                <MagneticElement strength={0.3}>
                  <div className="w-20 h-20 bg-gradient-to-br from-purple-400 to-pink-500 rounded-xl flex items-center justify-center text-white font-bold shadow-lg">
                    Magnet
                  </div>
                </MagneticElement>
                
                <MagneticElement strength={0.5}>
                  <div className="w-20 h-20 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-xl flex items-center justify-center text-white font-bold shadow-lg">
                    Strong
                  </div>
                </MagneticElement>
              </div>
            </div>
          </div>
        </MotionScrollReveal>

        {/* Hover Magnify */}
        <MotionScrollReveal direction="up" delay={0.8} className="mb-20">
          <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-200">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Hover Magnify</h2>
            <div className="text-center">
              <p className="text-slate-600 mb-8">Hover über das Bild um es zu vergrößern</p>
              <HoverMagnify magnification={1.5} className="mx-auto max-w-xs">
                <div className="w-64 h-64 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center text-white text-lg font-bold shadow-lg">
                  Hover to Magnify
                </div>
              </HoverMagnify>
            </div>
          </div>
        </MotionScrollReveal>

        {/* Expand on Tap */}
        <MotionScrollReveal direction="up" delay={0.9} className="mb-20">
          <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-200">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Tap to Expand</h2>
            <div className="max-w-md mx-auto">
              <TapToExpand
                expandedContent={
                  <div className="mt-4 p-4 bg-slate-50 rounded-lg">
                    <p className="text-slate-600">
                      Das ist der erweiterte Inhalt! Du kannst hier beliebige Inhalte anzeigen lassen.
                    </p>
                  </div>
                }
              >
                <div className="bg-gradient-to-r from-cyan-500 to-blue-600 p-6 rounded-xl text-white text-center cursor-pointer">
                  <h3 className="text-xl font-semibold">Klick mich um zu erweitern!</h3>
                </div>
              </TapToExpand>
            </div>
          </div>
        </MotionScrollReveal>

        {/* Performance Note */}
        <MotionScrollReveal direction="up" delay={1.0}>
          <div className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-2xl p-8 text-center">
            <h2 className="text-2xl font-bold text-green-800 mb-4">🚀 STUFE 3 Erfolgreich Implementiert!</h2>
            <p className="text-green-700 text-lg mb-4">
              Alle Motion-Animationen sind performance-optimiert und verwenden Hardware-Beschleunigung
            </p>
            <div className="flex justify-center items-center space-x-4">
              <MotionSuccessCheckmark isVisible={true} size="md" />
              <span className="text-green-600 font-semibold">Erweiterte Animationen Aktiv</span>
            </div>
          </div>
        </MotionScrollReveal>

      </div>
    </div>
  );
}