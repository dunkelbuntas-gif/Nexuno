import React from 'react';
import { motion } from 'motion/react';
import { MotionProductDetail } from '../product/MotionProductDetail';
import { RelatedProducts } from '../product/RelatedProducts';
import { CartProvider } from '../cart/CartContext';
import type { Page } from '../../App';

interface MotionProductDetailPageProps {
  productId: string | null;
  onNavigate: (page: Page) => void;
  onBack?: () => void;
}

export function MotionProductDetailPage({ 
  productId, 
  onNavigate, 
  onBack 
}: MotionProductDetailPageProps) {
  
  const handleRelatedProductClick = (relatedProductId: string) => {
    // Navigate to the related product
    onNavigate('product');
    // You could also update the productId here if needed
  };

  return (
    <motion.div
      className="min-h-screen bg-white"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
    >
      {/* Main Product Detail */}
      <MotionProductDetail
        productId={productId}
        onNavigate={onNavigate}
        onBack={onBack}
      />

      {/* Related Products */}
      <RelatedProducts
        currentProductId={productId || undefined}
        onProductClick={handleRelatedProductClick}
      />

      {/* Additional Features Section */}
      <motion.section 
        className="py-16 bg-white border-t border-gray-100"
        initial={{ opacity: 0, y: 50 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6, delay: 0.2 }}
      >
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Warum Tech Fashion?
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Unsere Produkte vereinen modernste Technologie mit nachhaltigem Design 
              für die Zukunft der Mode.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div 
              className="text-center"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <div className="w-16 h-16 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">🔮</span>
              </div>
              <h3 className="text-xl font-semibold mb-3">Future Tech</h3>
              <p className="text-gray-600">
                Integrierte Technologie, die sich nahtlos in deinen Alltag einfügt 
                und dein Leben vereinfacht.
              </p>
            </motion.div>

            <motion.div 
              className="text-center"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">🌱</span>
              </div>
              <h3 className="text-xl font-semibold mb-3">Sustainable</h3>
              <p className="text-gray-600">
                Nachhaltige Materialien und Produktion für eine bessere Zukunft 
                unseres Planeten.
              </p>
            </motion.div>

            <motion.div 
              className="text-center"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">✨</span>
              </div>
              <h3 className="text-xl font-semibold mb-3">Premium Quality</h3>
              <p className="text-gray-600">
                Höchste Qualitätsstandards in Material und Verarbeitung für 
                langanhaltende Zufriedenheit.
              </p>
            </motion.div>
          </div>
        </div>
      </motion.section>
    </motion.div>
  );
}