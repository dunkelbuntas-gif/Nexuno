import React, { useState, useEffect } from 'react';
import { motion, useMotionValue, useSpring } from 'motion/react';

interface InteractiveCursorProps {
  className?: string;
  size?: number;
  color?: string;
  mixBlendMode?: string;
}

export function InteractiveCursor({ 
  className = '',
  size = 20,
  color = 'rgba(34, 197, 94, 0.3)',
  mixBlendMode = 'difference'
}: InteractiveCursorProps) {
  const [mounted, setMounted] = useState(false);
  const [isHovering, setIsHovering] = useState(false);
  const [cursorVariant, setCursorVariant] = useState('default');

  const cursorX = useMotionValue(-100);
  const cursorY = useMotionValue(-100);

  const springConfig = { damping: 25, stiffness: 700 };
  const cursorXSpring = useSpring(cursorX, springConfig);
  const cursorYSpring = useSpring(cursorY, springConfig);

  useEffect(() => {
    setMounted(true);
    
    const moveCursor = (e: MouseEvent) => {
      cursorX.set(e.clientX - size / 2);
      cursorY.set(e.clientY - size / 2);
    };

    const handleMouseEnter = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target.matches('button, a, [data-cursor="pointer"]')) {
        setIsHovering(true);
        setCursorVariant('button');
      } else if (target.matches('input, textarea')) {
        setCursorVariant('input');
      } else if (target.matches('img, video')) {
        setCursorVariant('media');
      }
    };

    const handleMouseLeave = () => {
      setIsHovering(false);
      setCursorVariant('default');
    };

    if (mounted) {
      document.addEventListener('mousemove', moveCursor);
      document.addEventListener('mouseenter', handleMouseEnter, true);
      document.addEventListener('mouseleave', handleMouseLeave, true);
    }

    return () => {
      document.removeEventListener('mousemove', moveCursor);
      document.removeEventListener('mouseenter', handleMouseEnter, true);
      document.removeEventListener('mouseleave', handleMouseLeave, true);
    };
  }, [mounted, cursorX, cursorY, size]);

  const cursorVariants = {
    default: {
      scale: 1,
      backgroundColor: color,
      borderWidth: '2px',
      borderColor: 'rgba(34, 197, 94, 0.8)',
    },
    button: {
      scale: 2,
      backgroundColor: 'rgba(59, 130, 246, 0.3)',
      borderWidth: '2px',
      borderColor: 'rgba(59, 130, 246, 0.8)',
    },
    input: {
      scale: 0.5,
      backgroundColor: 'rgba(251, 146, 60, 0.3)',
      borderWidth: '1px',
      borderColor: 'rgba(251, 146, 60, 0.8)',
    },
    media: {
      scale: 3,
      backgroundColor: 'rgba(139, 92, 246, 0.2)',
      borderWidth: '3px',
      borderColor: 'rgba(139, 92, 246, 0.6)',
    },
  };

  if (!mounted) return null;

  return (
    <>
      {/* Main Cursor */}
      <motion.div
        className={`fixed top-0 left-0 pointer-events-none z-50 rounded-full border ${className}`}
        style={{
          x: cursorXSpring,
          y: cursorYSpring,
          width: size,
          height: size,
          mixBlendMode: mixBlendMode as any,
        }}
        variants={cursorVariants}
        animate={cursorVariant}
        transition={{
          type: 'spring',
          stiffness: 500,
          damping: 30,
        }}
      />

      {/* Cursor Trail */}
      <motion.div
        className="fixed top-0 left-0 pointer-events-none z-40 rounded-full"
        style={{
          x: cursorX,
          y: cursorY,
          width: size * 0.5,
          height: size * 0.5,
          backgroundColor: 'rgba(34, 197, 94, 0.1)',
          transform: 'translate(25%, 25%)',
        }}
        animate={{
          scale: isHovering ? 1.5 : 1,
          opacity: isHovering ? 0.8 : 0.3,
        }}
        transition={{
          type: 'spring',
          stiffness: 300,
          damping: 20,
        }}
      />

      {/* Additional Trail Particles */}
      {[...Array(3)].map((_, i) => (
        <motion.div
          key={i}
          className="fixed top-0 left-0 pointer-events-none z-30 rounded-full"
          style={{
            x: cursorX,
            y: cursorY,
            width: size * (0.3 - i * 0.1),
            height: size * (0.3 - i * 0.1),
            backgroundColor: `rgba(34, 197, 94, ${0.2 - i * 0.05})`,
            transform: `translate(${50 + i * 10}%, ${50 + i * 10}%)`,
          }}
          animate={{
            scale: isHovering ? 1.2 : 0.8,
            opacity: isHovering ? 0.6 : 0.2,
          }}
          transition={{
            type: 'spring',
            stiffness: 200 - i * 50,
            damping: 25 + i * 5,
          }}
        />
      ))}
    </>
  );
}

// Hook for cursor interactions
export function useCursorInteraction() {
  const [isHovering, setIsHovering] = useState(false);

  const mouseEnter = () => setIsHovering(true);
  const mouseLeave = () => setIsHovering(false);

  return {
    isHovering,
    mouseEnter,
    mouseLeave,
    cursorProps: {
      onMouseEnter: mouseEnter,
      onMouseLeave: mouseLeave,
      'data-cursor': 'pointer',
    },
  };
}