import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { CategorizedProduct } from '../../src/lib/api';
import { toast } from 'sonner@2.0.3';
import { Heart } from 'lucide-react';

interface WishlistContextType {
  wishlist: CategorizedProduct[];
  addToWishlist: (product: CategorizedProduct) => void;
  removeFromWishlist: (productId: number) => void;
  isInWishlist: (productId: number) => boolean;
  clearWishlist: () => void;
  wishlistCount: number;
}

const WishlistContext = createContext<WishlistContextType | undefined>(undefined);

export function useWishlist() {
  const context = useContext(WishlistContext);
  if (!context) {
    throw new Error('useWishlist must be used within WishlistProvider');
  }
  return context;
}

interface WishlistProviderProps {
  children: ReactNode;
}

export function WishlistProvider({ children }: WishlistProviderProps) {
  const [wishlist, setWishlist] = useState<CategorizedProduct[]>([]);

  // Load wishlist from localStorage on mount
  useEffect(() => {
    try {
      const savedWishlist = localStorage.getItem('nexuno-wishlist');
      if (savedWishlist) {
        const parsed = JSON.parse(savedWishlist);
        setWishlist(Array.isArray(parsed) ? parsed : []);
      }
    } catch (error) {
      console.warn('Failed to load wishlist from localStorage:', error);
    }
  }, []);

  // Save wishlist to localStorage whenever it changes
  useEffect(() => {
    try {
      localStorage.setItem('nexuno-wishlist', JSON.stringify(wishlist));
    } catch (error) {
      console.warn('Failed to save wishlist to localStorage:', error);
    }
  }, [wishlist]);

  const addToWishlist = (product: CategorizedProduct) => {
    setWishlist(prev => {
      // Don't add if already in wishlist
      if (prev.some(item => item.id === product.id)) {
        toast.info(`${product.name} ist bereits in der Wunschliste`);
        return prev;
      }

      toast.success(
        <div className="flex items-center gap-2">
          <Heart className="w-4 h-4 fill-current text-red-500" />
          <span>{product.name} zur Wunschliste hinzugefügt</span>
        </div>
      );

      return [...prev, product];
    });
  };

  const removeFromWishlist = (productId: number) => {
    setWishlist(prev => {
      const product = prev.find(item => item.id === productId);
      if (product) {
        toast.info(`${product.name} aus Wunschliste entfernt`);
      }
      return prev.filter(item => item.id !== productId);
    });
  };

  const isInWishlist = (productId: number) => {
    return wishlist.some(item => item.id === productId);
  };

  const clearWishlist = () => {
    setWishlist([]);
    toast.info('Wunschliste geleert');
  };

  const wishlistCount = wishlist.length;

  const value: WishlistContextType = {
    wishlist,
    addToWishlist,
    removeFromWishlist,
    isInWishlist,
    clearWishlist,
    wishlistCount,
  };

  return (
    <WishlistContext.Provider value={value}>
      {children}
    </WishlistContext.Provider>
  );
}