import React, { useRef, useCallback, useEffect, useState } from 'react';
import { motion, useScroll, useTransform, useInView } from 'motion/react';

interface SafeVideoAnimationProps {
  src: string;
  poster?: string;
  className?: string;
  autoplay?: boolean;
  loop?: boolean;
  muted?: boolean;
  controls?: boolean;
  overlay?: React.ReactNode;
  onLoadStart?: () => void;
  onCanPlay?: () => void;
  onError?: (error: Event) => void;
}

export function SafeVideoAnimation({
  src,
  poster,
  className = "",
  autoplay = true,
  loop = true,
  muted = true,
  controls = false,
  overlay,
  onLoadStart,
  onCanPlay,
  onError
}: SafeVideoAnimationProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);

  // Scroll-based animations
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });

  const isInView = useInView(containerRef, { 
    once: false, 
    amount: 0.3,
    margin: "0px 0px -100px 0px"
  });

  // Transform values for parallax effect
  const y = useTransform(scrollYProgress, [0, 1], ['0%', '20%']);
  const scale = useTransform(scrollYProgress, [0, 0.5, 1], [1.1, 1, 0.95]);
  const opacity = useTransform(scrollYProgress, [0, 0.2, 0.8, 1], [0.7, 1, 1, 0.3]);

  // Safe callback refs to avoid React callback ref errors
  const handleVideoRef = useCallback((element: HTMLVideoElement | null) => {
    if (element) {
      videoRef.current = element;
    }
  }, []);

  // Video event handlers with proper error handling
  const handleLoadStart = useCallback(() => {
    setIsLoading(true);
    setHasError(false);
    onLoadStart?.();
  }, [onLoadStart]);

  const handleCanPlay = useCallback(() => {
    setIsLoading(false);
    onCanPlay?.();
  }, [onCanPlay]);

  const handleError = useCallback((event: Event) => {
    setIsLoading(false);
    setHasError(true);
    setIsPlaying(false);
    onError?.(event);
    console.warn('Video failed to load:', src);
  }, [onError, src]);

  const handlePlay = useCallback(() => {
    setIsPlaying(true);
  }, []);

  const handlePause = useCallback(() => {
    setIsPlaying(false);
  }, []);

  // Intersection Observer based play/pause for performance
  useEffect(() => {
    const video = videoRef.current;
    if (!video || hasError) return;

    const playVideo = async () => {
      try {
        if (isInView && autoplay) {
          await video.play();
        } else {
          video.pause();
        }
      } catch (error) {
        console.warn('Video play failed:', error);
        setHasError(true);
      }
    };

    playVideo();
  }, [isInView, autoplay, hasError]);

  // Cleanup function
  useEffect(() => {
    const video = videoRef.current;
    
    return () => {
      if (video) {
        video.pause();
        video.currentTime = 0;
      }
    };
  }, []);

  // Prefers-reduced-motion support
  useEffect(() => {
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    
    if (prefersReducedMotion && videoRef.current) {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  }, []);

  return (
    <motion.div
      ref={containerRef}
      className={`relative overflow-hidden ${className}`}
      style={{ 
        y: isInView ? y : 0,
        scale: isInView ? scale : 1,
        opacity: isInView ? opacity : 0.7
      }}
      initial={{ opacity: 0 }}
      animate={{ opacity: isInView ? 1 : 0.7 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
    >
      {/* Video Element with safe ref handling */}
      {!hasError ? (
        <motion.video
          ref={handleVideoRef}
          src={src}
          poster={poster}
          autoPlay={autoplay}
          loop={loop}
          muted={muted}
          controls={controls}
          playsInline
          preload="metadata"
          className="w-full h-full object-cover"
          onLoadStart={handleLoadStart}
          onCanPlay={handleCanPlay}
          onError={handleError}
          onPlay={handlePlay}
          onPause={handlePause}
          style={{ 
            willChange: 'transform, opacity',
            backfaceVisibility: 'hidden',
            transform: 'translate3d(0, 0, 0)' // Force GPU acceleration
          }}
          initial={{ scale: 1.05, opacity: 0 }}
          animate={{ 
            scale: isLoading ? 1.05 : 1, 
            opacity: isLoading ? 0 : 1 
          }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        />
      ) : (
        // Fallback for video errors
        <div className="w-full h-full bg-gradient-to-br from-slate-800 to-slate-900 flex items-center justify-center">
          <div className="text-white/70 text-center p-8">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-white/10 flex items-center justify-center">
              <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm3 2h6v4l-2-2-2 2V5z" clipRule="evenodd" />
              </svg>
            </div>
            <p className="text-sm">Video nicht verfügbar</p>
          </div>
        </div>
      )}

      {/* Loading State */}
      {isLoading && !hasError && (
        <motion.div
          className="absolute inset-0 bg-slate-900/80 flex items-center justify-center backdrop-blur-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <motion.div
            className="w-8 h-8 border-2 border-cyan-400/30 border-t-cyan-400 rounded-full"
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          />
        </motion.div>
      )}

      {/* Play/Pause Indicator */}
      {!controls && !hasError && (
        <motion.div
          className="absolute top-4 right-4 bg-black/40 backdrop-blur-sm rounded-full p-2"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ 
            opacity: isInView ? 1 : 0,
            scale: isInView ? 1 : 0.8
          }}
          transition={{ duration: 0.3 }}
        >
          {isPlaying ? (
            <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zM7 8a1 1 0 012 0v4a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v4a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
            </svg>
          ) : (
            <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" />
            </svg>
          )}
        </motion.div>
      )}

      {/* Custom Overlay */}
      {overlay && (
        <motion.div
          className="absolute inset-0"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.3 }}
        >
          {overlay}
        </motion.div>
      )}

      {/* Enhanced Glow Effect */}
      <motion.div
        className="absolute inset-0 pointer-events-none"
        animate={{
          boxShadow: isPlaying && isInView ? [
            "inset 0 0 0 1px rgba(34, 211, 238, 0.2)",
            "inset 0 0 0 1px rgba(34, 211, 238, 0.4)",
            "inset 0 0 0 1px rgba(34, 211, 238, 0.2)"
          ] : "inset 0 0 0 1px rgba(34, 211, 238, 0.1)"
        }}
        transition={{ duration: 2, repeat: Infinity }}
      />
    </motion.div>
  );
}

// Enhanced Hero Video Background Component
export function HeroVideoBackground({
  src,
  fallbackImage,
  children,
  className = ""
}: {
  src: string;
  fallbackImage?: string;
  children?: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={`relative overflow-hidden ${className}`}>
      <SafeVideoAnimation
        src={src}
        poster={fallbackImage}
        autoplay={true}
        loop={true}
        muted={true}
        controls={false}
        className="absolute inset-0 w-full h-full"
        overlay={
          <div className="absolute inset-0 bg-gradient-to-r from-slate-900/70 via-transparent to-slate-900/70" />
        }
      />
      
      {/* Content overlay */}
      <div className="relative z-10">
        {children}
      </div>
    </div>
  );
}

// Video Mosaic Component for Fashion Showcase
export function VideoMosaic({
  videos,
  className = ""
}: {
  videos: Array<{
    src: string;
    poster?: string;
    title?: string;
    delay?: number;
  }>;
  className?: string;
}) {
  return (
    <div className={`grid grid-cols-2 md:grid-cols-3 gap-4 ${className}`}>
      {videos.map((video, index) => (
        <motion.div
          key={video.src}
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ 
            duration: 0.6, 
            delay: video.delay || index * 0.1,
            ease: "easeOut" 
          }}
          className="relative aspect-square rounded-xl overflow-hidden"
        >
          <SafeVideoAnimation
            src={video.src}
            poster={video.poster}
            autoplay={true}
            loop={true}
            muted={true}
            className="w-full h-full"
          />
          
          {video.title && (
            <motion.div
              className="absolute bottom-4 left-4 bg-black/60 backdrop-blur-sm text-white px-3 py-1 rounded-lg text-sm font-medium"
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: 0.2 }}
            >
              {video.title}
            </motion.div>
          )}
        </motion.div>
      ))}
    </div>
  );
}