import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, Minus, Trash2, Heart, Star, ArrowRight } from 'lucide-react';
import { useCart, CartItem } from './CartContext';
import { useWishlist } from '../wishlist/WishlistContext';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Card } from '../ui/card';
import { toast } from 'sonner@2.0.3';

interface CartItemCardProps {
  item: CartItem;
  variant?: 'default' | 'compact' | 'detailed';
  showActions?: boolean;
  onItemClick?: (item: CartItem) => void;
}

export function CartItemCard({ 
  item, 
  variant = 'default', 
  showActions = true,
  onItemClick 
}: CartItemCardProps) {
  const [isRemoving, setIsRemoving] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(false);
  
  const { updateQuantity, removeItem } = useCart();
  const { addToWishlist, isInWishlist } = useWishlist();

  const formatPrice = (price: number | string) => {
    const numPrice = typeof price === 'string' ? parseFloat(price.replace('€', '')) : price;
    return `€${numPrice.toFixed(2)}`;
  };

  const getItemTotal = (price: number | string, quantity: number) => {
    const numPrice = typeof price === 'string' ? parseFloat(price.replace('€', '')) : price;
    return numPrice * quantity;
  };

  const handleQuantityChange = (newQuantity: number) => {
    updateQuantity(item.id, newQuantity, item.size, item.color);
    
    if (newQuantity > item.quantity) {
      toast.success('Menge erhöht');
    } else if (newQuantity < item.quantity) {
      toast.success('Menge reduziert');
    }
  };

  const handleRemove = async () => {
    setIsRemoving(true);
    
    // Add smooth removal animation
    setTimeout(() => {
      removeItem(item.id, item.size, item.color);
      toast.success(`${item.name} wurde entfernt`);
    }, 300);
  };

  const handleAddToWishlist = () => {
    if (!isInWishlist(item.id)) {
      addToWishlist({
        id: item.id,
        name: item.name,
        price: typeof item.price === 'string' ? item.price : `€${item.price}`,
        image: item.image,
        category: item.category
      });
      toast.success('Zur Wunschliste hinzugefügt');
    }
  };

  const cardVariants = {
    default: 'p-4',
    compact: 'p-3',
    detailed: 'p-6'
  };

  const imageVariants = {
    default: 'w-20 h-20',
    compact: 'w-16 h-16',
    detailed: 'w-24 h-24'
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ 
        opacity: isRemoving ? 0 : 1, 
        y: isRemoving ? -20 : 0,
        scale: isRemoving ? 0.95 : 1
      }}
      exit={{ opacity: 0, x: -100, height: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Card className={`${cardVariants[variant]} bg-white/80 backdrop-blur-sm border border-gray-200/50 hover:shadow-lg transition-all duration-300 group ${isRemoving ? 'pointer-events-none' : ''}`}>
        <div className="flex gap-4">
          {/* Product Image */}
          <div 
            className={`relative ${imageVariants[variant]} rounded-lg overflow-hidden bg-gray-100 cursor-pointer`}
            onClick={() => onItemClick?.(item)}
          >
            <motion.img
              src={item.image}
              alt={item.name}
              className={`w-full h-full object-cover transition-all duration-300 ${imageLoaded ? 'opacity-100' : 'opacity-0'}`}
              onLoad={() => setImageLoaded(true)}
              whileHover={{ scale: 1.05 }}
            />
            
            {/* Loading skeleton */}
            {!imageLoaded && (
              <div className="absolute inset-0 bg-gray-200 animate-pulse" />
            )}
            
            {/* Hover overlay */}
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-300 flex items-center justify-center">
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                whileHover={{ opacity: 1, scale: 1 }}
                className="opacity-0 group-hover:opacity-100 transition-opacity duration-300"
              >
                <ArrowRight className="w-5 h-5 text-white drop-shadow-lg" />
              </motion.div>
            </div>
          </div>

          {/* Product Details */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between mb-2">
              <div className="flex-1 min-w-0">
                <h4 
                  className="font-semibold text-gray-900 truncate cursor-pointer hover:text-cyan-600 transition-colors"
                  onClick={() => onItemClick?.(item)}
                >
                  {item.name}
                </h4>
                
                {/* Variant Info */}
                <div className="flex items-center gap-2 mt-1">
                  {item.size && (
                    <Badge variant="outline" className="text-xs">
                      Größe: {item.size}
                    </Badge>
                  )}
                  {item.color && (
                    <Badge variant="outline" className="text-xs">
                      Farbe: {item.color}
                    </Badge>
                  )}
                </div>

                {/* Category */}
                {variant === 'detailed' && (
                  <p className="text-xs text-gray-500 mt-1">{item.category}</p>
                )}
              </div>

              {/* Wishlist Button */}
              {showActions && (
                <button
                  onClick={handleAddToWishlist}
                  className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all duration-300"
                  aria-label="Zur Wunschliste hinzufügen"
                >
                  <Heart className={`w-4 h-4 ${isInWishlist(item.id) ? 'fill-red-500 text-red-500' : ''}`} />
                </button>
              )}
            </div>

            {/* Price and Quantity Controls */}
            <div className="flex items-center justify-between mt-3">
              {/* Quantity Controls */}
              {showActions && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleQuantityChange(item.quantity - 1)}
                    className="w-8 h-8 rounded-lg border border-gray-300 flex items-center justify-center hover:bg-gray-50 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                    disabled={item.quantity <= 1 || isRemoving}
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  
                  <motion.span 
                    key={item.quantity}
                    initial={{ scale: 1.2 }}
                    animate={{ scale: 1 }}
                    className="w-10 text-center font-medium text-gray-900"
                  >
                    {item.quantity}
                  </motion.span>
                  
                  <button
                    onClick={() => handleQuantityChange(item.quantity + 1)}
                    className="w-8 h-8 rounded-lg border border-gray-300 flex items-center justify-center hover:bg-gray-50 transition-all duration-200 disabled:opacity-50"
                    disabled={isRemoving}
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              )}

              {/* Price */}
              <div className="text-right">
                <motion.p 
                  key={getItemTotal(item.price, item.quantity)}
                  initial={{ scale: 1.1 }}
                  animate={{ scale: 1 }}
                  className="font-semibold text-gray-900"
                >
                  {formatPrice(getItemTotal(item.price, item.quantity))}
                </motion.p>
                
                {item.quantity > 1 && variant !== 'compact' && (
                  <p className="text-xs text-gray-500">
                    {formatPrice(item.price)} / Stück
                  </p>
                )}
              </div>
            </div>

            {/* Actions Row */}
            {showActions && variant === 'detailed' && (
              <div className="flex items-center justify-between mt-4 pt-3 border-t border-gray-200">
                <div className="flex items-center gap-2">
                  <Star className="w-4 h-4 text-yellow-400 fill-current" />
                  <span className="text-sm text-gray-600">4.8 (42 Bewertungen)</span>
                </div>
                
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleRemove}
                  className="text-red-600 hover:text-red-700 hover:bg-red-50 transition-all duration-200"
                  disabled={isRemoving}
                >
                  <Trash2 className="w-4 h-4 mr-1" />
                  Entfernen
                </Button>
              </div>
            )}

            {/* Remove Button for non-detailed variants */}
            {showActions && variant !== 'detailed' && (
              <div className="flex justify-end mt-2">
                <button
                  onClick={handleRemove}
                  className="p-1 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded transition-all duration-200"
                  aria-label="Artikel entfernen"
                  disabled={isRemoving}
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Loading overlay */}
        <AnimatePresence>
          {isRemoving && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-white/80 flex items-center justify-center rounded-lg"
            >
              <div className="flex items-center gap-2 text-gray-600">
                <div className="w-4 h-4 border-2 border-gray-300 border-t-gray-600 rounded-full animate-spin" />
                <span className="text-sm">Wird entfernt...</span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </Card>
    </motion.div>
  );
}