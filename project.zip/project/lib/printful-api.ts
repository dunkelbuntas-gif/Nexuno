/**
 * Nexuno Printful API Client
 * Frontend API client for Cloudflare Workers backend
 */

const API_BASE_URL = 
  process.env.NODE_ENV === 'production' 
    ? 'https://api.nexuno.eu/printful' 
    : 'http://localhost:8787/printful';

export interface PrintfulProduct {
  id: number;
  external_id: string;
  name: string;
  variants: number;
  synced: number;
  thumbnail_url: string;
  is_ignored: boolean;
}

export interface PrintfulVariant {
  id: number;
  external_id: string;
  sync_product_id: number;
  name: string;
  synced: boolean;
  variant_id: number;
  main_category_id: number;
  warehouse_product_variant_id: number;
  retail_price: string;
  sku: string;
  currency: string;
  product: {
    variant_id: number;
    product_id: number;
    image: string;
    name: string;
  };
  files: Array<{
    id: number;
    type: string;
    hash: string;
    url: string;
    filename: string;
    mime_type: string;
    size: number;
    width: number;
    height: number;
    dpi: number;
    status: string;
    created: number;
    thumbnail_url: string;
    preview_url: string;
    visible: boolean;
  }>;
  options: Array<{
    id: string;
    value: string;
  }>;
  is_ignored: boolean;
}

export interface PrintfulMockupRequest {
  product_id: number;
  variant_id: number;
  design_url: string;
  placement?: string;
}

export interface PrintfulOrderItem {
  sync_variant_id: number;
  quantity: number;
  retail_price: string;
  name: string;
  product: {
    variant_id: number;
    product_id: number;
    image: string;
    name: string;
  };
  files: Array<{
    url: string;
    type: string;
    placement: string;
  }>;
  options: Array<{
    id: string;
    value: string;
  }>;
}

export interface PrintfulOrderRecipient {
  name: string;
  company?: string;
  address1: string;
  address2?: string;
  city: string;
  state_code: string;
  country_code: string;
  zip: string;
  phone?: string;
  email: string;
}

export interface PrintfulOrderRequest {
  external_id: string;
  shipping: string;
  recipient: PrintfulOrderRecipient;
  items: PrintfulOrderItem[];
  retail_costs?: {
    shipping?: string;
    tax?: string;
  };
  gift?: {
    subject: string;
    message: string;
  };
}

class PrintfulApiClient {
  private baseUrl: string;

  constructor() {
    this.baseUrl = API_BASE_URL;
  }

  // Generic API request handler
  private async request<T>(
    endpoint: string, 
    options: RequestInit = {}
  ): Promise<T> {
    const url = `${this.baseUrl}${endpoint}`;
    
    const response = await fetch(url, {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Printful API Error (${response.status}): ${errorText}`);
    }

    return response.json();
  }

  // Get all products
  async getProducts(category?: string): Promise<{ code: number; result: PrintfulProduct[] }> {
    const params = category ? `?category=${encodeURIComponent(category)}` : '';
    return this.request(`/products${params}`);
  }

  // Get product variants
  async getProductVariants(productId: number): Promise<{ code: number; result: PrintfulVariant[] }> {
    return this.request(`/variants/${productId}`);
  }

  // Create mockup
  async createMockup(mockupRequest: PrintfulMockupRequest): Promise<any> {
    return this.request('/mockups', {
      method: 'POST',
      body: JSON.stringify(mockupRequest),
    });
  }

  // Upload design file
  async uploadDesign(file: File): Promise<{ success: boolean; design_url: string; printful_file: any }> {
    const formData = new FormData();
    formData.append('design', file);

    const response = await fetch(`${this.baseUrl}/upload`, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Upload Error (${response.status}): ${errorText}`);
    }

    return response.json();
  }

  // Create order
  async createOrder(orderRequest: PrintfulOrderRequest): Promise<any> {
    return this.request('/orders', {
      method: 'POST',
      body: JSON.stringify(orderRequest),
    });
  }

  // Get order status
  async getOrderStatus(orderId: string): Promise<any> {
    return this.request(`/orders?id=${encodeURIComponent(orderId)}`);
  }

  // Get API status
  async getStatus(): Promise<{ status: string; timestamp: string; version: string }> {
    return this.request('/status');
  }
}

// Export singleton instance
export const printfulApi = new PrintfulApiClient();

// Helper functions for common operations
export const printfulHelpers = {
  // Format price for display
  formatPrice: (price: string, currency: string = 'EUR'): string => {
    const numPrice = parseFloat(price);
    return new Intl.NumberFormat('de-DE', {
      style: 'currency',
      currency: currency,
    }).format(numPrice);
  },

  // Get product image URL
  getProductImage: (variant: PrintfulVariant): string => {
    return variant.files.find(file => file.type === 'preview')?.preview_url 
      || variant.files[0]?.preview_url 
      || variant.product.image;
  },

  // Generate external order ID
  generateOrderId: (): string => {
    return `nexuno-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  },

  // Validate email
  isValidEmail: (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  },

  // Get available sizes from variant options
  getAvailableSizes: (variant: PrintfulVariant): string[] => {
    const sizeOption = variant.options.find(option => option.id === 'size');
    return sizeOption ? [sizeOption.value] : [];
  },

  // Get available colors from variant options  
  getAvailableColors: (variant: PrintfulVariant): string[] => {
    const colorOption = variant.options.find(option => option.id === 'color');
    return colorOption ? [colorOption.value] : [];
  },

  // Check if variant is in stock
  isInStock: (variant: PrintfulVariant): boolean => {
    return variant.synced && !variant.is_ignored;
  },

  // Calculate markup price
  calculateRetailPrice: (basePrice: string, markupPercent: number = 100): string => {
    const base = parseFloat(basePrice);
    const retail = base * (1 + markupPercent / 100);
    return retail.toFixed(2);
  },

  // Get shipping methods (placeholder - would need actual Printful shipping API)
  getShippingMethods: () => [
    {
      id: 'STANDARD',
      name: 'Standard Versand',
      rate: '4.99',
      currency: 'EUR',
      min_delivery_days: 3,
      max_delivery_days: 7,
    },
    {
      id: 'EXPRESS',
      name: 'Express Versand',
      rate: '9.99',
      currency: 'EUR',
      min_delivery_days: 1,
      max_delivery_days: 3,
    },
  ],
};

// Error classes
export class PrintfulApiError extends Error {
  constructor(message: string, public statusCode?: number) {
    super(message);
    this.name = 'PrintfulApiError';
  }
}

export class PrintfulUploadError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'PrintfulUploadError';
  }
}

// Types for React components
export type PrintfulApiStatus = 'idle' | 'loading' | 'success' | 'error';

export interface UsePrintfulApiResult<T> {
  data: T | null;
  status: PrintfulApiStatus;
  error: string | null;
  refetch: () => Promise<void>;
}

// React Hook for Printful API
export function usePrintfulApi<T>(
  apiCall: () => Promise<T>,
  dependencies: any[] = []
): UsePrintfulApiResult<T> {
  // Note: This hook should only be used in React components
  // Import React properly at component level, not here
  return {
    data: null,
    status: 'idle',
    error: 'Hook must be used in React component context',
    refetch: async () => {}
  };
}