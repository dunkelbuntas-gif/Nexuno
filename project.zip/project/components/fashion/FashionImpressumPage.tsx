import React from 'react';
import { ArrowLeft } from 'lucide-react';

interface FashionImpressumPageProps {
  onBack?: () => void;
}

export function FashionImpressumPage({ onBack }: FashionImpressumPageProps) {
  return (
    <div className="min-h-screen bg-slate-950 text-white">
      {/* Header */}
      <header className="bg-slate-900 border-b border-slate-700">
        <div className="max-w-4xl mx-auto px-6 py-8">
          {/* Back Button */}
          <button
            onClick={onBack}
            className="mb-6 flex items-center space-x-2 text-slate-300 hover:text-cyan-400 transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
            <span className="font-medium">Zurück zum Shop</span>
          </button>

          {/* Title */}
          <div className="text-center">
            <h1 className="text-4xl font-bold text-white mb-4">
              Impressum
            </h1>
            <p className="text-xl text-slate-300">
              Angaben gemäß § 5 TMG
            </p>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="py-16 bg-slate-950 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 pointer-events-none">
          <div className="tech-grid-minimal"></div>
        </div>
        <div className="max-w-4xl mx-auto px-6 relative z-10">
          <div className="bg-slate-900 rounded-3xl shadow-lg border border-slate-700 p-8 md:p-12">
            
            <div className="space-y-12">
              {/* Unternehmensdaten */}
              <div>
                <h2 className="text-2xl font-bold text-white mb-6 pb-3 border-b-2 border-cyan-500">
                  Unternehmensdaten
                </h2>
                
                <div className="grid md:grid-cols-2 gap-8">
                  <div>
                    <h3 className="text-xl font-semibold text-slate-200 mb-3 underline">
                      Unternehmen
                    </h3>
                    <p className="text-slate-300 leading-relaxed">
                      André Schumann<br />
                      Online-Shop für Print und Demand und Dropshipping Produkte.<br />
                      Fließstraße 6<br />
                      12439 Berlin<br />
                      Deutschland
                    </p>
                  </div>

                  <div>
                    <h3 className="text-xl font-semibold text-slate-200 mb-3 underline">
                      Kontakt
                    </h3>
                    <p className="text-slate-300 leading-relaxed">
                      Telefon: 015678569698<br />
                      E-Mail: info@nexuno.eu
                    </p>
                  </div>
                </div>
              </div>

              {/* Verbraucherschlichtungsstelle */}
              <div className="bg-slate-800 rounded-2xl p-6">
                <h3 className="text-xl font-semibold text-slate-200 mb-3 underline">
                  Verbraucherschlichtungsstelle
                </h3>
                <p className="text-slate-300 leading-relaxed">
                  Wir sind nicht bereit oder verpflichtet, an Streitbeilegungsverfahren vor einer Verbraucherschlichtungsstelle teilzunehmen.
                </p>
              </div>

              {/* Quelle */}
              <div className="text-sm text-slate-400 text-center">
                <p>
                  Quelle: <a 
                    href="https://www.e-recht24.de" 
                    className="text-cyan-400 hover:text-cyan-300 transition-colors underline"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    e-recht24.de
                  </a>
                </p>
              </div>

              {/* Haftungsausschluss */}
              <div>
                <h2 className="text-2xl font-bold text-white mb-6 pb-3 border-b-2 border-blue-500">
                  Haftungsausschluss
                </h2>
                
                <div className="space-y-6">
                  <div>
                    <h3 className="text-xl font-semibold text-slate-200 mb-3">
                      Haftung für Inhalte
                    </h3>
                    <p className="text-slate-300 leading-relaxed">
                      Als Diensteanbieter sind wir gemäß § 7 Abs.1 TMG für eigene Inhalte auf diesen Seiten nach den 
                      allgemeinen Gesetzen verantwortlich. Nach §§ 8 bis 10 TMG sind wir als Diensteanbieter jedoch nicht 
                      unter der Verpflichtung, übermittelte oder gespeicherte fremde Informationen zu überwachen oder nach 
                      Umständen zu forschen, die auf eine rechtswidrige Tätigkeit hinweisen.
                    </p>
                  </div>

                  <div>
                    <h3 className="text-xl font-semibold text-slate-200 mb-3">
                      Haftung für Links
                    </h3>
                    <p className="text-slate-300 leading-relaxed">
                      Unser Angebot enthält Links zu externen Websites Dritter, auf deren Inhalte wir keinen Einfluss haben. 
                      Deshalb können wir für diese fremden Inhalte auch keine Gewähr übernehmen. Für die Inhalte der verlinkten 
                      Seiten ist stets der jeweilige Anbieter oder Betreiber der Seiten verantwortlich.
                    </p>
                  </div>

                  <div>
                    <h3 className="text-xl font-semibold text-slate-200 mb-3">
                      Urheberrecht
                    </h3>
                    <p className="text-slate-300 leading-relaxed">
                      Die durch die Seitenbetreiber erstellten Inhalte und Werke auf diesen Seiten unterliegen dem deutschen 
                      Urheberrecht. Die Vervielfältigung, Bearbeitung, Verbreitung und jede Art der Verwertung außerhalb der 
                      Grenzen des Urheberrechtes bedürfen der schriftlichen Zustimmung des jeweiligen Autors bzw. Erstellers.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default FashionImpressumPage;