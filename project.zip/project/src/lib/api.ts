/**
 * Nexuno Fashion Store API Configuration
 * Product Categories and API Constants
 */

// Product Categories für die Navigation
export const PRODUCT_CATEGORIES = {
  tshirts: {
    id: 'tshirts',
    name: 'T-Shirts',
    slug: 'tshirts',
    description: 'Futuristische T-Shirts für jeden Tag'
  },
  hoodies: {
    id: 'hoodies',
    name: 'Hoodies',
    slug: 'hoodies',
    description: 'Premium Hoodies mit Tech-Design'
  },
  accessories: {
    id: 'accessories',
    name: 'Accessories',
    slug: 'accessories',
    description: 'Futuristische Accessoires & Gadgets'
  },
  activewear: {
    id: 'activewear',
    name: 'Activewear',
    slug: 'activewear',
    description: 'Sport & Fitness für die Zukunft'
  }
};

// API Endpoints
export const API_ENDPOINTS = {
  products: '/api/products',
  categories: '/api/categories',
  search: '/api/search',
  printful: '/api/printful'
};

// Default exports
export default {
  PRODUCT_CATEGORIES,
  API_ENDPOINTS
};