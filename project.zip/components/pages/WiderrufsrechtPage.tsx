import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { BackButton } from '../BackButton';
import { Separator } from '../ui/separator';
import { widerrufsTexts } from '../constants/legalTexts';

interface WiderrufsrechtPageProps {
  onBack?: () => void;
}

export function WiderrufsrechtPage({ onBack }: WiderrufsrechtPageProps) {
  return (
    <div className="min-h-screen" style={{ backgroundColor: '#F8FAFC' }}>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Back Button */}
        <div className="mb-8">
          <BackButton variant="legal" onBack={onBack} />
        </div>
        
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="mb-4" style={{ 
            fontSize: '3rem',
            lineHeight: '3.5rem',
            fontWeight: '700',
            background: 'linear-gradient(135deg, var(--accent-pink) 0%, var(--accent-cyan) 100%)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
            fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
          }}>
            Widerrufsrecht
          </h1>
          <p style={{ 
            fontSize: '1.125rem',
            color: '#0F172A',
            fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
          }}>
            Informationen zu Ihrem Widerrufsrecht
          </p>
        </div>

        <div className="space-y-8">
          {/* Widerrufsbelehrung */}
          <div className="content-box">
            <h2 style={{ 
              fontSize: '2rem',
              lineHeight: '2.5rem',
              fontWeight: '700',
              color: '#0F172A',
              fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
              marginBottom: '1.5rem'
            }}>
              {widerrufsTexts.belehrung.title}
            </h2>
            <div className="space-y-6">
              {widerrufsTexts.belehrung.sections.map((section, index) => (
                <div key={index}>
                  <h3 style={{ 
                    fontSize: '1.25rem',
                    lineHeight: '1.75rem',
                    fontWeight: '600',
                    color: '#0F172A',
                    fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
                    marginBottom: '0.5rem'
                  }}>
                    {section.title}
                  </h3>
                  <p style={{ 
                    color: '#0F172A',
                    fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
                    lineHeight: '1.6'
                  }}>
                    {section.content}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Muster-Widerrufsformular */}
          <div className="content-box">
            <h2 style={{ 
              fontSize: '2rem',
              lineHeight: '2.5rem',
              fontWeight: '700',
              color: '#0F172A',
              fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
              marginBottom: '1.5rem'
            }}>
              {widerrufsTexts.muster.title}
            </h2>
            <p style={{ 
              color: '#0F172A',
              fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
              lineHeight: '1.6',
              marginBottom: '1.5rem'
            }}>
              {widerrufsTexts.muster.content}
            </p>
            
            <div className="content-box" style={{ backgroundColor: '#F8FAFC', border: '2px dashed #E2E8F0' }}>
              {widerrufsTexts.muster.fields.map((field, index) => (
                <div key={index} style={{ marginBottom: '1rem' }}>
                  <p style={{ 
                    color: '#0F172A',
                    fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
                    lineHeight: '1.6'
                  }}>
                    {field}
                  </p>
                  {index < widerrufsTexts.muster.fields.length - 1 && (
                    <div style={{ borderBottom: '1px solid #E2E8F0', marginTop: '0.5rem', marginBottom: '1rem' }}></div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Besondere Hinweise */}
          <div className="content-box">
            <h2 style={{ 
              fontSize: '2rem',
              lineHeight: '2.5rem',
              fontWeight: '700',
              color: '#0F172A',
              fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
              marginBottom: '1.5rem'
            }}>
              {widerrufsTexts.hinweise.title}
            </h2>
            <div className="space-y-4">
              {widerrufsTexts.hinweise.content.map((hint, index) => (
                <p key={index} style={{ 
                  color: '#0F172A',
                  fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
                  lineHeight: '1.6'
                }}>
                  {hint}
                </p>
              ))}
            </div>
          </div>

          {/* Kontakt für Widerruf */}
          <div className="content-box">
            <h2 style={{ 
              fontSize: '2rem',
              lineHeight: '2.5rem',
              fontWeight: '700',
              color: '#0F172A',
              fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
              marginBottom: '1.5rem'
            }}>
              Widerruf mitteilen
            </h2>
            <div style={{ 
              background: 'linear-gradient(135deg, rgba(0,255,255,0.1) 0%, rgba(255,102,255,0.1) 100%)',
              padding: '1.5rem',
              borderRadius: '12px'
            }}>
              <h4 style={{ 
                fontSize: '1.125rem',
                fontWeight: '600',
                color: '#0F172A',
                fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
                marginBottom: '1rem'
              }}>
                So können Sie Ihren Widerruf mitteilen:
              </h4>
              <div className="space-y-2">
                <p style={{ 
                  color: '#0F172A',
                  fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
                }}>
                  <strong>E-Mail:</strong> info@nexuno.eu
                </p>
                <p style={{ 
                  color: '#0F172A',
                  fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
                }}>
                  <strong>Post:</strong> André Schuman - Nexuno, Fließstraße 6, 12439 Berlin
                </p>
                <p style={{ 
                  color: '#0F172A',
                  fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
                }}>
                  <strong>Telefon:</strong> +49 30 12345678
                </p>
              </div>
              <Separator style={{ margin: '1rem 0', backgroundColor: '#E2E8F0' }} />
              <p style={{ 
                fontSize: '0.875rem',
                color: '#0F172A',
                fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
                opacity: '0.8'
              }}>
                Sie können das oben stehende Muster-Widerrufsformular verwenden, das jedoch nicht vorgeschrieben ist.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}