import React from 'react';
import { motion, useScroll, useTransform } from 'motion/react';

interface MotionParallaxProps {
  children: React.ReactNode;
  speed?: number;
  className?: string;
  direction?: 'up' | 'down' | 'left' | 'right';
}

export function MotionParallax({ 
  children, 
  speed = 0.5, 
  className = '', 
  direction = 'up' 
}: MotionParallaxProps) {
  const { scrollYProgress } = useScroll();
  
  const y = useTransform(scrollYProgress, [0, 1], 
    direction === 'up' ? [0, -200 * speed] : 
    direction === 'down' ? [0, 200 * speed] : [0, 0]
  );
  
  const x = useTransform(scrollYProgress, [0, 1], 
    direction === 'left' ? [0, -200 * speed] : 
    direction === 'right' ? [0, 200 * speed] : [0, 0]
  );

  return (
    <motion.div
      className={className}
      style={{ 
        y: direction === 'up' || direction === 'down' ? y : 0,
        x: direction === 'left' || direction === 'right' ? x : 0,
        willChange: 'transform'
      }}
    >
      {children}
    </motion.div>
  );
}

interface ParallaxSectionProps {
  children: React.ReactNode;
  className?: string;
  backgroundElements?: React.ReactNode;
}

export function ParallaxSection({ children, className = '', backgroundElements }: ParallaxSectionProps) {
  const { scrollYProgress } = useScroll();
  
  const backgroundY = useTransform(scrollYProgress, [0, 1], [0, -300]);
  const contentY = useTransform(scrollYProgress, [0, 1], [0, -100]);

  return (
    <div className={`relative overflow-hidden ${className}`}>
      {/* Background Elements with Parallax */}
      {backgroundElements && (
        <motion.div
          className="absolute inset-0 z-0"
          style={{ 
            y: backgroundY,
            willChange: 'transform'
          }}
        >
          {backgroundElements}
        </motion.div>
      )}
      
      {/* Content with Parallax */}
      <motion.div
        className="relative z-10"
        style={{ 
          y: contentY,
          willChange: 'transform'
        }}
      >
        {children}
      </motion.div>
    </div>
  );
}

interface ScrollRevealProps {
  children: React.ReactNode;
  className?: string;
  delay?: number;
  duration?: number;
  direction?: 'up' | 'down' | 'left' | 'right' | 'scale';
}

export function MotionScrollReveal({ 
  children, 
  className = '', 
  delay = 0,
  duration = 0.8,
  direction = 'up'
}: ScrollRevealProps) {
  const getInitialTransform = () => {
    switch (direction) {
      case 'up': return { y: 60, opacity: 0 };
      case 'down': return { y: -60, opacity: 0 };
      case 'left': return { x: 60, opacity: 0 };
      case 'right': return { x: -60, opacity: 0 };
      case 'scale': return { scale: 0.8, opacity: 0 };
      default: return { y: 60, opacity: 0 };
    }
  };

  const getFinalTransform = () => {
    switch (direction) {
      case 'up': 
      case 'down': return { y: 0, opacity: 1 };
      case 'left': 
      case 'right': return { x: 0, opacity: 1 };
      case 'scale': return { scale: 1, opacity: 1 };
      default: return { y: 0, opacity: 1 };
    }
  };

  return (
    <motion.div
      className={className}
      initial={getInitialTransform()}
      whileInView={getFinalTransform()}
      viewport={{ once: true, margin: "-100px" }}
      transition={{
        duration,
        delay,
        ease: [0.25, 0.25, 0, 1]
      }}
    >
      {children}
    </motion.div>
  );
}