export function Toaster(props: { position?: string; closeButton?: boolean; richColors?: boolean; theme?: string }) {
  return null; // Platzhalter – später echte Toasts
}