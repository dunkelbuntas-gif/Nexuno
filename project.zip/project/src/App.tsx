import { useState, useEffect } from 'react';
import { Toaster } from './components/ui/sonner';

// TypeScript declarations for requestIdleCallback
declare global {
  interface Window {
    requestIdleCallback?: (callback: IdleRequestCallback, options?: IdleRequestOptions) => number;
    cancelIdleCallback?: (id: number) => void;
  }
}

// Browser compatibility polyfill for requestIdleCallback
if (typeof window !== 'undefined' && !window.requestIdleCallback) {
  window.requestIdleCallback = function(callback: IdleRequestCallback, options?: IdleRequestOptions) {
    const start = Date.now();
    return setTimeout(function() {
      callback({
        didTimeout: false,
        timeRemaining() {
          return Math.max(0, 50 - (Date.now() - start));
        }
      });
    }, options?.timeout || 1) as any;
  };

  window.cancelIdleCallback = function(id: number) {
    clearTimeout(id);
  };
}

// Direct imports - NO lazy loading for now
import { FashionStorePage } from './components/FashionStorePage';
import { FashionImpressumPage } from './components/fashion/FashionImpressumPage';
import { FashionDatenschutzPage } from './components/fashion/FashionDatenschutzPage';
import { FashionAGBPage } from './components/fashion/FashionAGBPage';
import { FashionWiderrufsrechtPage } from './components/fashion/FashionWiderrufsrechtPage';
import { FashionContactPage } from './components/fashion/FashionContactPage';

// Cart System Components
import { CartPage } from './components/cart/CartPage';
import { CheckoutProcess } from './components/cart/CheckoutProcess';
import { EnhancedCartSidebar } from './components/cart/EnhancedCartSidebar';

// Context Providers - Direct imports
import { CartProvider } from './components/cart/CartContext';
import { WishlistProvider } from './components/wishlist/WishlistContext';
import { RecentlyViewedProvider } from './components/shopping/RecentlyViewedContext';

// Simple loading fallback
const LoadingFallback = ({ text = "Lädt..." }: { text?: string }) => (
  <div className="min-h-screen bg-slate-950 flex items-center justify-center">
    <div className="text-center max-w-md p-6">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-400 mx-auto mb-4"></div>
      <p className="text-white/70 mb-4">{text}</p>
    </div>
  </div>
);

// Error fallback component  
const ErrorFallback = ({ error, retry }: { error: string; retry: () => void }) => (
  <div className="min-h-screen bg-slate-950 flex items-center justify-center">
    <div className="text-center max-w-md p-6">
      <div className="text-red-400 mb-4 text-4xl">⚠️</div>
      <h2 className="text-white mb-4">Fehler beim Laden</h2>
      <p className="text-white/70 mb-4">{error}</p>
      <div className="space-y-3">
        <button 
          onClick={retry}
          className="block w-full bg-cyan-500 hover:bg-cyan-600 text-white px-4 py-2 rounded-lg transition"
        >
          Erneut versuchen
        </button>
        <button 
          onClick={() => window.location.reload()}
          className="block w-full bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg transition"
        >
          Seite neu laden
        </button>
      </div>
    </div>
  </div>
);

export type Page = 'home' | 'shop' | 'tshirts' | 'hoodies' | 'accessories' | 'about' | 'contact' | 
                   'product' | 'impressum' | 'datenschutz' | 'agb' | 'widerruf' | 'fashion' | 'cart' | 'checkout';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('fashion');
  const [componentError, setComponentError] = useState<string | null>(null);
  const [isInitialized, setIsInitialized] = useState(false);
  const [checkoutData, setCheckoutData] = useState<any>(null);

  // Fast initialization
  useEffect(() => {
    const initializeApp = () => {
      try {
        // Basic accessibility setup
        if (window.matchMedia?.('(prefers-color-scheme: dark)').matches) {
          document.documentElement.classList.add('dark');
        }
        if (window.matchMedia?.('(prefers-reduced-motion: reduce)').matches) {
          document.documentElement.classList.add('reduce-motion');
        }

        setIsInitialized(true);

        // Load accessibility settings asynchronously
        setTimeout(() => {
          try {
            const savedSettings = localStorage.getItem('nexuno-accessibility-settings');
            if (savedSettings) {
              const settings = JSON.parse(savedSettings);
              const html = document.documentElement;
              
              if (settings.reduceMotion) html.classList.add('reduce-motion');
              if (settings.highContrast) html.classList.add('high-contrast');
              if (settings.largeText) html.classList.add('large-text');
            }
          } catch (error) {
            console.warn('Accessibility settings error:', error);
          }
        }, 100);

      } catch (error) {
        console.warn('Initialization error:', error);
        setIsInitialized(true);
      }
    };

    initializeApp();
  }, []);
  
  const navigateTo = (page: Page) => {
    setComponentError(null);
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const goBack = () => {
    setComponentError(null);
    setCurrentPage('fashion');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const retryComponent = () => {
    setComponentError(null);
  };

  // Render page content with error handling
  const renderPageContent = () => {
    try {
      const commonProps = { onBack: goBack };

      switch (currentPage) {
        case 'cart':
          return (
            <CartPage
              onBack={goBack}
              onCheckout={() => navigateTo('checkout')}
              onContinueShopping={goBack}
              onProductClick={(productId) => {
                // Handle product detail navigation
                console.log('Navigate to product:', productId);
                goBack();
              }}
            />
          );
          
        case 'checkout':
          return (
            <CheckoutProcess
              onBack={() => navigateTo('cart')}
              onComplete={(orderData) => {
                setCheckoutData(orderData);
                goBack(); // Return to shop after successful order
              }}
            />
          );
          
        case 'impressum':
          return <FashionImpressumPage {...commonProps} />;
        case 'datenschutz':
          return <FashionDatenschutzPage {...commonProps} />;
        case 'agb':
          return <FashionAGBPage {...commonProps} />;
        case 'widerruf':
          return <FashionWiderrufsrechtPage {...commonProps} />;
        case 'contact':
          return <FashionContactPage {...commonProps} />;
        case 'fashion':
        default:
          return (
            <>
              <FashionStorePage onNavigate={navigateTo} />
              
              {/* Enhanced Cart Sidebar - Always rendered for global access */}
              <EnhancedCartSidebar
                onCheckout={() => navigateTo('checkout')}
                onContinueShopping={goBack}
              />
            </>
          );
      }
    } catch (error) {
      console.error('Page render error:', error);
      setComponentError(error instanceof Error ? error.message : 'Unbekannter Fehler');
      return null;
    }
  };

  if (!isInitialized) {
    return <LoadingFallback text="App wird initialisiert..." />;
  }

  if (componentError) {
    return <ErrorFallback error={componentError} retry={retryComponent} />;
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-950">
      {/* Skip links for accessibility */}
      <div className="skip-links">
        <a href="#main-content" className="skip-link">
          Zum Hauptinhalt springen
        </a>
      </div>
      
      {/* Context Providers at the ROOT - no Suspense around them */}
      <CartProvider>
        <WishlistProvider>
          <RecentlyViewedProvider>
            <main className="flex-1" id="main-content">
              {renderPageContent()}
              
              {/* Toast notifications */}
              <Toaster 
                position="top-right"
                closeButton
                richColors
                theme="dark"
              />
            </main>
          </RecentlyViewedProvider>
        </WishlistProvider>
      </CartProvider>
    </div>
  );
}