// scripts/doctor.mjs
import fs from 'fs';
import path from 'path';
import url from 'url';

const cwd = process.cwd();
const p = (...x) => path.join(cwd, ...x);
const fail = (msg) => { console.error('❌ ' + msg); process.exitCode = 1; };
const ok = (msg) => console.log('✅ ' + msg);

console.log('--- NEXUNO BUILD DOCTOR ---');
console.log('CWD:', cwd);

// 1) Muss-Dateien im Root
const rootMust = ['package.json', 'index.html', 'vite.config.ts', 'tsconfig.json', 'src'];
for (const f of rootMust) {
  if (!fs.existsSync(p(f))) fail(`Fehlt im Projekt-Root: ${f}`);
  else ok(`Gefunden: ${f}`);
}

// 2) Keine zweite package.json in Unterordnern
function findPackageJsons(dir, acc = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, e.name);
    if (e.isDirectory()) {
      if (e.name === 'node_modules' || e.name === '.git' || e.name === 'dist') continue;
      findPackageJsons(full, acc);
    } else if (e.isFile() && e.name === 'package.json' && full !== p('package.json')) {
      acc.push(full);
    }
  }
  return acc;
}
const extraPkgs = findPackageJsons(cwd);
if (extraPkgs.length) {
  fail(`Zusätzliche package.json gefunden:\n- ${extraPkgs.join('\n- ')}`);
} else {
  ok('Nur eine package.json vorhanden (Root) – gut.');
}

// 3) index.html lädt main.tsx korrekt?
try {
  const idx = fs.readFileSync(p('index.html'), 'utf8');
  if (!idx.includes('/src/main.tsx')) fail('index.html lädt nicht "/src/main.tsx".');
  else ok('index.html → /src/main.tsx passt.');
} catch (e) {
  fail('index.html konnte nicht gelesen werden.');
}

// 4) vite.config.ts: outDir = dist?
try {
  const vite = fs.readFileSync(p('vite.config.ts'), 'utf8');
  if (!/outDir:\s*['"]dist['"]/.test(vite)) fail('vite.config.ts: build.outDir ist nicht "dist".');
  else ok('vite.config.ts → outDir "dist" bestätigt.');
} catch {
  fail('vite.config.ts konnte nicht gelesen werden.');
}

// 5) imports aus App.tsx resolven (Case-sensitiv!)
const appPath = p('src', 'App.tsx');
if (!fs.existsSync(appPath)) {
  fail('src/App.tsx fehlt.');
} else {
  ok('src/App.tsx gefunden.');
  const app = fs.readFileSync(appPath, 'utf8');
  const importRe = /from\s+['"](\.\/[^'"]+)['"]/g;
  const rels = new Set();
  let m;
  while ((m = importRe.exec(app))) rels.add(m[1]);

  // erwartete Endungen
  const exts = ['.tsx', '.ts', '.jsx', '.js'];

  for (const rel of rels) {
    // mappe auf reale Datei
    const full = p('src', rel.replace(/^.\//, ''));
    const candidates = fs.existsSync(full) && fs.statSync(full).isFile()
      ? [full]
      : exts.map(ext => full + ext);

    const hit = candidates.find(f => fs.existsSync(f));
    if (!hit) fail(`Import nicht gefunden (Case/Pfad prüfen): src/${rel}{.tsx,.ts,.jsx,.js}`);
    else ok(`Import ok: ${rel} -> ${path.relative(cwd, hit)}`);
  }
}

// 6) Spezialpfad: RecentlyViewedContext (häufiger Stolperstein)
const rvc = p('src/components/shopping/RecentlyViewedContext.tsx');
if (!fs.existsSync(rvc)) {
  fail('Fehlt: src/components/shopping/RecentlyViewedContext.tsx');
} else {
  ok('RecentlyViewedContext vorhanden.');
}

// 7) Styles optional
const styles = p('src/styles.css');
if (!fs.existsSync(styles)) {
  console.warn('⚠️ Hinweis: src/styles.css fehlt (nur Warnung).');
} else {
  ok('styles.css gefunden.');
}

// Abschluss
if (process.exitCode) {
  console.error('\n--- DOCTOR: PROBLEME GEFUNDEN ---');
  console.error('Bitte oben gelistete Punkte fixen. Build wird abgebrochen.');
  process.exit(1);
} else {
  console.log('\n--- DOCTOR: ALLES GRÜN ---');
}