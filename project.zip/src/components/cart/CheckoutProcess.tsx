export function CheckoutProcess({
  onBack, onComplete
}: { onBack:()=>void; onComplete:(order:any)=>void }) {
  return (
    <section style={{padding:24}}>
      <h2>Checkout</h2>
      <p>Platzhalter – hier kommt der echte Checkout.</p>
      <button onClick={()=>onComplete({ ok:true, id: Date.now() })}>Bestellung abschließen</button>{' '}
      <button onClick={onBack}>Zurück</button>
    </section>
  );
}