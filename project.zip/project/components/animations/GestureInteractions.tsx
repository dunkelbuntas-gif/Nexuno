import React from 'react';
import { motion, PanInfo, useDragControls } from 'motion/react';

interface DraggableElementProps {
  children: React.ReactNode;
  className?: string;
  constrainToParent?: boolean;
  onDragStart?: () => void;
  onDragEnd?: () => void;
  snapToGrid?: boolean;
  gridSize?: number;
}

export function DraggableElement({
  children,
  className = '',
  constrainToParent = false,
  onDragStart,
  onDragEnd,
  snapToGrid = false,
  gridSize = 20
}: DraggableElementProps) {
  const dragControls = useDragControls();

  const snapToGridFn = (point: { x: number; y: number }) => {
    if (!snapToGrid) return point;
    
    return {
      x: Math.round(point.x / gridSize) * gridSize,
      y: Math.round(point.y / gridSize) * gridSize
    };
  };

  return (
    <motion.div
      className={`cursor-grab active:cursor-grabbing select-none ${className}`}
      drag
      dragControls={dragControls}
      dragConstraints={constrainToParent ? { top: 0, left: 0, right: 0, bottom: 0 } : false}
      dragElastic={0.1}
      dragMomentum={false}
      onDragStart={onDragStart}
      onDragEnd={(_, info) => {
        onDragEnd?.();
      }}
      whileDrag={{ 
        scale: 1.05,
        rotate: 2,
        zIndex: 1000,
        boxShadow: '0 10px 30px rgba(0, 0, 0, 0.2)'
      }}
      transition={{
        type: "spring",
        stiffness: 300,
        damping: 20
      }}
    >
      {children}
    </motion.div>
  );
}

interface SwipeableCardProps {
  children: React.ReactNode;
  className?: string;
  onSwipeLeft?: () => void;
  onSwipeRight?: () => void;
  onSwipeUp?: () => void;
  onSwipeDown?: () => void;
  threshold?: number;
}

export function SwipeableCard({
  children,
  className = '',
  onSwipeLeft,
  onSwipeRight,
  onSwipeUp,
  onSwipeDown,
  threshold = 100
}: SwipeableCardProps) {
  const [isDragging, setIsDragging] = React.useState(false);

  const handleDragEnd = (event: any, info: PanInfo) => {
    setIsDragging(false);
    
    const { offset, velocity } = info;
    
    // Check for swipe gestures
    if (Math.abs(offset.x) > threshold || Math.abs(velocity.x) > 500) {
      if (offset.x > 0 && onSwipeRight) {
        onSwipeRight();
      } else if (offset.x < 0 && onSwipeLeft) {
        onSwipeLeft();
      }
    }
    
    if (Math.abs(offset.y) > threshold || Math.abs(velocity.y) > 500) {
      if (offset.y > 0 && onSwipeDown) {
        onSwipeDown();
      } else if (offset.y < 0 && onSwipeUp) {
        onSwipeUp();
      }
    }
  };

  return (
    <motion.div
      className={`touch-pan-y ${className}`}
      drag
      dragConstraints={{ left: 0, right: 0, top: 0, bottom: 0 }}
      dragElastic={0.2}
      onDragStart={() => setIsDragging(true)}
      onDragEnd={handleDragEnd}
      animate={isDragging ? {} : { x: 0, y: 0 }}
      transition={{
        type: "spring",
        stiffness: 300,
        damping: 30
      }}
      whileDrag={{
        scale: 0.95,
        rotate: 0
      }}
    >
      {children}
    </motion.div>
  );
}

interface TapToExpandProps {
  children: React.ReactNode;
  expandedContent?: React.ReactNode;
  className?: string;
  expandScale?: number;
}

export function TapToExpand({
  children,
  expandedContent,
  className = '',
  expandScale = 1.2
}: TapToExpandProps) {
  const [isExpanded, setIsExpanded] = React.useState(false);

  return (
    <motion.div
      className={`cursor-pointer ${className}`}
      whileTap={{ scale: 0.95 }}
      animate={{
        scale: isExpanded ? expandScale : 1
      }}
      transition={{
        type: "spring",
        stiffness: 300,
        damping: 20
      }}
      onTap={() => setIsExpanded(!isExpanded)}
      layout
    >
      <motion.div layout>
        {children}
      </motion.div>
      
      {expandedContent && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{
            opacity: isExpanded ? 1 : 0,
            height: isExpanded ? 'auto' : 0
          }}
          transition={{
            duration: 0.3,
            ease: [0.25, 0.25, 0, 1]
          }}
          style={{ overflow: 'hidden' }}
        >
          {expandedContent}
        </motion.div>
      )}
    </motion.div>
  );
}

interface PinchToZoomProps {
  children: React.ReactNode;
  className?: string;
  minScale?: number;
  maxScale?: number;
}

export function PinchToZoom({
  children,
  className = '',
  minScale = 0.5,
  maxScale = 3
}: PinchToZoomProps) {
  const [scale, setScale] = React.useState(1);

  const handleWheel = (event: React.WheelEvent) => {
    event.preventDefault();
    
    const delta = event.deltaY * -0.01;
    const newScale = Math.min(maxScale, Math.max(minScale, scale + delta));
    setScale(newScale);
  };

  return (
    <div 
      className={`overflow-hidden touch-none ${className}`}
      onWheel={handleWheel}
    >
      <motion.div
        scale={scale}
        transition={{
          type: "spring",
          stiffness: 300,
          damping: 30
        }}
        style={{
          transformOrigin: 'center'
        }}
      >
        {children}
      </motion.div>
    </div>
  );
}

interface LongPressButtonProps {
  children: React.ReactNode;
  onLongPress: () => void;
  duration?: number;
  className?: string;
  showProgress?: boolean;
}

export function LongPressButton({
  children,
  onLongPress,
  duration = 1000,
  className = '',
  showProgress = true
}: LongPressButtonProps) {
  const [isPressed, setIsPressed] = React.useState(false);
  const [progress, setProgress] = React.useState(0);
  const timerRef = React.useRef<NodeJS.Timeout>();
  const progressRef = React.useRef<NodeJS.Timeout>();

  const startPress = () => {
    setIsPressed(true);
    setProgress(0);

    // Progress animation
    const startTime = Date.now();
    const updateProgress = () => {
      const elapsed = Date.now() - startTime;
      const newProgress = Math.min(100, (elapsed / duration) * 100);
      setProgress(newProgress);

      if (newProgress < 100) {
        progressRef.current = setTimeout(updateProgress, 16);
      }
    };
    updateProgress();

    // Long press timer
    timerRef.current = setTimeout(() => {
      onLongPress();
      setIsPressed(false);
      setProgress(0);
    }, duration);
  };

  const endPress = () => {
    setIsPressed(false);
    setProgress(0);
    if (timerRef.current) {
      clearTimeout(timerRef.current);
    }
    if (progressRef.current) {
      clearTimeout(progressRef.current);
    }
  };

  React.useEffect(() => {
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
      if (progressRef.current) clearTimeout(progressRef.current);
    };
  }, []);

  return (
    <motion.div
      className={`relative select-none cursor-pointer ${className}`}
      onMouseDown={startPress}
      onMouseUp={endPress}
      onMouseLeave={endPress}
      onTouchStart={startPress}
      onTouchEnd={endPress}
      whilePressed={{ scale: 0.95 }}
      transition={{
        type: "spring",
        stiffness: 400,
        damping: 17
      }}
    >
      {children}
      
      {showProgress && isPressed && (
        <motion.div
          className="absolute inset-0 border-2 border-store-green rounded-inherit"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          style={{
            background: `conic-gradient(from 0deg, transparent ${progress * 3.6}deg, rgba(34, 197, 94, 0.2) ${progress * 3.6}deg)`
          }}
        />
      )}
    </motion.div>
  );
}

interface HoverMagnifyProps {
  children: React.ReactNode;
  className?: string;
  magnification?: number;
  focusArea?: { x: number; y: number; width: number; height: number };
}

export function HoverMagnify({
  children,
  className = '',
  magnification = 2,
  focusArea
}: HoverMagnifyProps) {
  const [isHovered, setIsHovered] = React.useState(false);
  const [mousePosition, setMousePosition] = React.useState({ x: 0, y: 0 });

  const handleMouseMove = (event: React.MouseEvent<HTMLDivElement>) => {
    const rect = event.currentTarget.getBoundingClientRect();
    setMousePosition({
      x: event.clientX - rect.left,
      y: event.clientY - rect.top
    });
  };

  return (
    <div
      className={`relative overflow-hidden ${className}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onMouseMove={handleMouseMove}
    >
      <motion.div
        animate={{
          scale: isHovered ? magnification : 1,
          x: isHovered ? (mousePosition.x * (1 - magnification)) / magnification : 0,
          y: isHovered ? (mousePosition.y * (1 - magnification)) / magnification : 0
        }}
        transition={{
          type: "spring",
          stiffness: 300,
          damping: 30
        }}
        style={{
          transformOrigin: 'top left'
        }}
      >
        {children}
      </motion.div>
    </div>
  );
}