import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { CategorizedProduct } from '../../src/lib/api';

interface RecentlyViewedContextType {
  recentlyViewed: CategorizedProduct[];
  addToRecentlyViewed: (product: CategorizedProduct) => void;
  clearRecentlyViewed: () => void;
  recentlyViewedCount: number;
}

const RecentlyViewedContext = createContext<RecentlyViewedContextType | undefined>(undefined);

export function useRecentlyViewed() {
  const context = useContext(RecentlyViewedContext);
  if (!context) {
    throw new Error('useRecentlyViewed must be used within RecentlyViewedProvider');
  }
  return context;
}

interface RecentlyViewedProviderProps {
  children: ReactNode;
}

export function RecentlyViewedProvider({ children }: RecentlyViewedProviderProps) {
  const [recentlyViewed, setRecentlyViewed] = useState<CategorizedProduct[]>([]);
  const MAX_RECENT_ITEMS = 10; // Keep last 10 viewed items

  // Load recently viewed from localStorage on mount
  useEffect(() => {
    try {
      const savedRecentlyViewed = localStorage.getItem('nexuno-recently-viewed');
      if (savedRecentlyViewed) {
        const parsed = JSON.parse(savedRecentlyViewed);
        setRecentlyViewed(Array.isArray(parsed) ? parsed : []);
      }
    } catch (error) {
      console.warn('Failed to load recently viewed from localStorage:', error);
    }
  }, []);

  // Save recently viewed to localStorage whenever it changes
  useEffect(() => {
    try {
      localStorage.setItem('nexuno-recently-viewed', JSON.stringify(recentlyViewed));
    } catch (error) {
      console.warn('Failed to save recently viewed to localStorage:', error);
    }
  }, [recentlyViewed]);

  const addToRecentlyViewed = (product: CategorizedProduct) => {
    setRecentlyViewed(prev => {
      // Remove if already exists to avoid duplicates
      const filtered = prev.filter(item => item.id !== product.id);
      
      // Add to beginning
      const updated = [product, ...filtered];
      
      // Limit to max items
      return updated.slice(0, MAX_RECENT_ITEMS);
    });
  };

  const clearRecentlyViewed = () => {
    setRecentlyViewed([]);
  };

  const recentlyViewedCount = recentlyViewed.length;

  const value: RecentlyViewedContextType = {
    recentlyViewed,
    addToRecentlyViewed,
    clearRecentlyViewed,
    recentlyViewedCount,
  };

  return (
    <RecentlyViewedContext.Provider value={value}>
      {children}
    </RecentlyViewedContext.Provider>
  );
}