import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface MorphingCardProps {
  frontContent: React.ReactNode;
  backContent: React.ReactNode;
  className?: string;
  triggerOnHover?: boolean;
  morphingEffect?: 'flip' | 'scale' | 'slide' | 'morph';
}

export function MorphingCard({ 
  frontContent, 
  backContent, 
  className = '',
  triggerOnHover = true,
  morphingEffect = 'morph'
}: MorphingCardProps) {
  const [isFlipped, setIsFlipped] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  const shouldShowBack = triggerOnHover ? isHovered : isFlipped;

  const cardVariants = {
    front: {
      rotateY: 0,
      scale: 1,
      x: 0,
      opacity: 1,
    },
    back: {
      rotateY: morphingEffect === 'flip' ? 180 : 0,
      scale: morphingEffect === 'scale' ? 1.05 : 1,
      x: morphingEffect === 'slide' ? 300 : 0,
      opacity: morphingEffect === 'morph' ? 1 : 1,
    },
  };

  const morphVariants = {
    front: {
      clipPath: 'polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%)',
      borderRadius: '16px',
      background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.9), rgba(248, 250, 252, 0.8))',
    },
    back: {
      clipPath: 'polygon(10% 10%, 90% 10%, 90% 90%, 10% 90%)',
      borderRadius: '24px',
      background: 'linear-gradient(135deg, rgba(34, 197, 94, 0.1), rgba(59, 130, 246, 0.1))',
    },
  };

  return (
    <motion.div
      className={`relative preserve-3d cursor-pointer ${className}`}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      onClick={() => !triggerOnHover && setIsFlipped(!isFlipped)}
      whileHover={{ 
        scale: 1.02,
        boxShadow: '0 20px 40px rgba(0, 0, 0, 0.1)',
      }}
      transition={{ duration: 0.6, ease: [0.25, 0.25, 0, 1] }}
    >
      <AnimatePresence mode="wait">
        {!shouldShowBack ? (
          <motion.div
            key="front"
            variants={morphingEffect === 'morph' ? morphVariants : cardVariants}
            initial="front"
            animate="front"
            exit="back"
            transition={{ duration: 0.6, ease: [0.25, 0.25, 0, 1] }}
            className="w-full h-full backface-hidden"
            style={{
              transformStyle: 'preserve-3d',
            }}
          >
            {/* Shimmer Effect */}
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
              initial={{ x: '-100%', skewX: -12 }}
              animate={{ x: isHovered ? '200%' : '-100%' }}
              transition={{ duration: 1, ease: 'easeInOut' }}
              style={{ 
                borderRadius: 'inherit',
                zIndex: 1,
              }}
            />
            
            {/* Content */}
            <div className="relative z-10">
              {frontContent}
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="back"
            variants={morphingEffect === 'morph' ? morphVariants : cardVariants}
            initial="front"
            animate="back"
            exit="front"
            transition={{ duration: 0.6, ease: [0.25, 0.25, 0, 1] }}
            className="w-full h-full backface-hidden"
            style={{
              transformStyle: 'preserve-3d',
              rotateY: morphingEffect === 'flip' ? 180 : 0,
            }}
          >
            {/* Glow Effect */}
            <motion.div
              className="absolute inset-0 rounded-inherit opacity-0"
              style={{
                background: 'linear-gradient(135deg, rgba(34, 197, 94, 0.3), rgba(59, 130, 246, 0.3))',
                filter: 'blur(20px)',
                zIndex: 0,
              }}
              animate={{
                opacity: shouldShowBack ? 0.6 : 0,
                scale: shouldShowBack ? 1.1 : 1,
              }}
              transition={{ duration: 0.4 }}
            />
            
            {/* Content */}
            <div className="relative z-10">
              {backContent}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Floating Particles */}
      {shouldShowBack && (
        <div className="absolute inset-0 pointer-events-none">
          {[...Array(6)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-2 h-2 bg-gradient-to-r from-green-400 to-blue-500 rounded-full"
              style={{
                left: `${20 + (i * 12)}%`,
                top: `${30 + (i % 3) * 20}%`,
              }}
              animate={{
                y: [0, -20, 0],
                opacity: [0, 1, 0],
                scale: [0.5, 1, 0.5],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                delay: i * 0.2,
                ease: 'easeInOut',
              }}
            />
          ))}
        </div>
      )}
    </motion.div>
  );
}