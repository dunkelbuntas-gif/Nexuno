import { createContext, useContext, useState, ReactNode } from 'react';
const C = createContext<{ ids:string[]; toggle:(id:string)=>void } | null>(null);
export function WishlistProvider({ children }: { children: ReactNode }) {
  const [ids, set] = useState<string[]>([]);
  return <C.Provider value={{ ids, toggle:(id)=>set(x=>x.includes(id)?x.filter(i=>i!==id):[...x,id]) }}>{children}</C.Provider>;
}
export const useWishlist = () => {
  const v = useContext(C);
  if (!v) throw new Error('WishlistContext missing');
  return v;
};