import React from 'react';

// Enhanced category icons
export function CategoryIcon({ category, className = "w-5 h-5" }: { category: string, className?: string }) {
  const iconProps = className;
  
  switch (category) {
    case 'tshirts':
      return (
        <svg className={iconProps} fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7h2a1 1 0 011 1v2M8 7H6a1 1 0 00-1 1v2" />
        </svg>
      );
    case 'hoodies':
      return (
        <svg className={iconProps} fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7-7m0 0l-7 7m7-7v18" />
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l1.5-1.5M19 10l-1.5-1.5" />
        </svg>
      );
    case 'accessories':
      return (
        <svg className={iconProps} fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
        </svg>
      );
    case 'prints':
      return (
        <svg className={iconProps} fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
        </svg>
      );
    case 'tech':
      return (
        <svg className={iconProps} fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a1 1 0 001-1v-1H7v1a1 1 0 001 1zM7 10V9a5 5 0 0110 0v1h2a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6a1 1 0 011-1h2z" />
        </svg>
      );
    case 'activewear':
      return (
        <svg className={iconProps} fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
        </svg>
      );
    default:
      return (
        <svg className={iconProps} fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
        </svg>
      );
  }
}

interface CategoryQuickNavProps {
  categories: string[];
  selectedCategory: string;
  onCategoryChange: (category: string) => void;
  productCounts: Record<string, number>;
  className?: string;
}

const CATEGORY_INFO: Record<string, { name: string; description: string }> = {
  all: { name: 'Alle Produkte', description: 'Gesamtes Sortiment' },
  tshirts: { name: 'T-Shirts', description: 'Premium T-Shirts für jeden Anlass' },
  hoodies: { name: 'Hoodies', description: 'Warme und stylische Hoodies' },
  accessories: { name: 'Accessoires', description: 'Das perfekte Zubehör für deinen Look' },
  activewear: { name: 'Activewear', description: 'Sportkleidung für höchste Performance' },
  tech: { name: 'Tech', description: 'Innovative Tech-Produkte' },
  prints: { name: 'Prints', description: 'Kunstvolle Poster und Drucke' }
};

export function CategoryQuickNav({ 
  categories, 
  selectedCategory, 
  onCategoryChange, 
  productCounts,
  className = ""
}: CategoryQuickNavProps) {
  return (
    <nav 
      className={`category-quick-nav ${className}`}
      role="navigation"
      aria-label="Produktkategorien"
    >
      <h3 className="sr-only">Produktkategorien</h3>
      
      <div className="flex flex-wrap gap-3 justify-center lg:justify-start">
        {/* All products button */}
        <button
          onClick={() => onCategoryChange('all')}
          className={`
            group flex items-center gap-2 px-4 py-2.5 rounded-full text-sm font-medium 
            transition-all duration-300 transform hover:scale-105 focus:scale-105
            ${selectedCategory === 'all' 
              ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/25 border border-cyan-400/30' 
              : 'bg-white/10 text-white/90 hover:bg-white/20 border border-white/20 hover:border-cyan-400/30 hover:text-white'
            }
          `}
          aria-pressed={selectedCategory === 'all'}
          aria-describedby="all-count"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14-2V9a2 2 0 00-2-2M5 7V5a2 2 0 012-2h10a2 2 0 012 2v2m0 4v10a2 2 0 01-2 2H7a2 2 0 01-2-2V11" />
          </svg>
          <span>Alle Produkte</span>
          <span 
            id="all-count"
            className={`
              inline-flex items-center justify-center min-w-[20px] h-5 px-1.5 rounded-full text-xs
              ${selectedCategory === 'all' 
                ? 'bg-white/20 text-white' 
                : 'bg-cyan-500/20 text-cyan-300 group-hover:bg-cyan-500/30'
              }
            `}
            aria-label={`${productCounts.all || 0} Produkte insgesamt`}
          >
            {productCounts.all || 0}
          </span>
        </button>
        
        {/* Category buttons */}
        {categories.filter(cat => cat !== 'all').map(category => {
          const categoryInfo = CATEGORY_INFO[category] || { name: category, description: category };
          const count = productCounts[category] || 0;
          
          return (
            <button
              key={category}
              onClick={() => onCategoryChange(category)}
              className={`
                group flex items-center gap-2 px-4 py-2.5 rounded-full text-sm font-medium 
                transition-all duration-300 transform hover:scale-105 focus:scale-105
                ${selectedCategory === category 
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/25 border border-cyan-400/30' 
                  : 'bg-white/10 text-white/90 hover:bg-white/20 border border-white/20 hover:border-cyan-400/30 hover:text-white'
                }
              `}
              aria-pressed={selectedCategory === category}
              aria-describedby={`${category}-count`}
              title={categoryInfo.description}
            >
              <CategoryIcon category={category} className="w-4 h-4" />
              <span>{categoryInfo.name}</span>
              <span 
                id={`${category}-count`}
                className={`
                  inline-flex items-center justify-center min-w-[20px] h-5 px-1.5 rounded-full text-xs
                  ${selectedCategory === category 
                    ? 'bg-white/20 text-white' 
                    : 'bg-cyan-500/20 text-cyan-300 group-hover:bg-cyan-500/30'
                  }
                `}
                aria-label={`${count} Produkte in ${categoryInfo.name}`}
              >
                {count}
              </span>
            </button>
          );
        })}
      </div>
      
      {/* Category description */}
      {selectedCategory !== 'all' && CATEGORY_INFO[selectedCategory] && (
        <div className="mt-4 p-3 rounded-lg bg-white/5 border border-white/10">
          <p className="text-sm text-slate-300 text-center">
            <CategoryIcon category={selectedCategory} className="w-4 h-4 inline mr-2" />
            {CATEGORY_INFO[selectedCategory].description}
          </p>
        </div>
      )}
    </nav>
  );
}