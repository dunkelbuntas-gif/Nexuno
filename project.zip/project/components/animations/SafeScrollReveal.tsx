import React, { useEffect, useRef, useState } from 'react';

interface SafeScrollRevealProps {
  children: React.ReactNode;
  direction?: 'up' | 'down' | 'left' | 'right' | 'scale';
  delay?: number;
  className?: string;
  threshold?: number;
  once?: boolean;
}

export function SafeScrollReveal({ 
  children, 
  direction = 'up', 
  delay = 0,
  className = '',
  threshold = 0.1,
  once = true
}: SafeScrollRevealProps) {
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          // Add delay if specified
          if (delay > 0) {
            setTimeout(() => setIsVisible(true), delay * 1000);
          } else {
            setIsVisible(true);
          }
          
          // Disconnect if "once" is true (default)
          if (once) {
            observer.unobserve(entry.target);
          }
        } else if (!once) {
          // Re-trigger animation if "once" is false
          setIsVisible(false);
        }
      },
      { 
        threshold,
        rootMargin: '0px 0px -50px 0px' // Trigger slightly before element is visible
      }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, [threshold, delay, once]);

  // Map direction to CSS animation classes
  const getAnimationClass = () => {
    const baseClass = 'safe-scroll-reveal';
    const directionClass = `safe-scroll-reveal-${direction}`;
    const visibleClass = isVisible ? 'safe-scroll-reveal-visible' : '';
    
    return `${baseClass} ${directionClass} ${visibleClass}`.trim();
  };

  return (
    <div
      ref={ref}
      className={`${getAnimationClass()} ${className}`}
    >
      {children}
    </div>
  );
}