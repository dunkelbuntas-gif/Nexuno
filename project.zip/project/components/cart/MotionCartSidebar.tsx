import React from 'react';
import { X, Plus, Minus, Trash2, ShoppingBag, CreditCard, ArrowLeft } from 'lucide-react';
import { useCart } from './CartContext';
import { motion, AnimatePresence, PanInfo } from 'motion/react';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { Button } from '../ui/button';
import { SwipeableCard } from '../animations/GestureInteractions';
import { MotionButton } from '../animations/MotionInteractions';
import { MotionQuantityControls } from './MotionAddToCart';

export function MotionCartSidebar() {
  const { state, removeItem, updateQuantity, closeCart, clearCart } = useCart();
  const [swipeThreshold] = React.useState(100);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('de-DE', {
      style: 'currency',
      currency: 'EUR'
    }).format(price);
  };

  const getItemKey = (item: any) => {
    return `${item.id}-${item.size || 'no-size'}-${item.color || 'no-color'}`;
  };

  const handleSwipeToRemove = (itemId: string, itemSize?: string, itemColor?: string) => {
    removeItem(itemId, itemSize, itemColor);
  };

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      closeCart();
    }
  };

  return (
    <AnimatePresence>
      {state.isOpen && (
        <>
          {/* Enhanced Backdrop with Blur */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={handleBackdropClick}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40"
            transition={{ duration: 0.3 }}
          />

          {/* Enhanced Sidebar with Swipe Support */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ 
              type: 'spring', 
              damping: 30, 
              stiffness: 300,
              mass: 0.8
            }}
            drag="x"
            dragConstraints={{ left: 0, right: 300 }}
            dragElastic={0.2}
            onDragEnd={(_, info: PanInfo) => {
              if (info.offset.x > swipeThreshold || info.velocity.x > 500) {
                closeCart();
              }
            }}
            className="fixed right-0 top-0 h-full w-full max-w-md z-50 flex flex-col bg-white shadow-2xl"
            style={{
              background: 'linear-gradient(135deg, rgba(15, 23, 42, 0.98) 0%, rgba(30, 41, 59, 0.98) 100%)',
              borderLeft: '1px solid rgba(6, 182, 212, 0.2)',
              boxShadow: '0 0 50px rgba(6, 182, 212, 0.1)'
            }}
          >
            {/* Enhanced Header with Glassmorphism */}
            <motion.div 
              className="relative flex items-center justify-between p-6 border-b backdrop-blur-sm"
              style={{ 
                borderColor: 'rgba(6, 182, 212, 0.2)',
                background: 'rgba(255, 255, 255, 0.05)'
              }}
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              <div className="flex items-center gap-3">
                <motion.div
                  className="w-10 h-10 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-lg flex items-center justify-center"
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  transition={{ type: "spring", stiffness: 400 }}
                >
                  <ShoppingBag className="h-5 w-5 text-white" />
                </motion.div>
                <div>
                  <h2 className="text-lg font-bold text-white">
                    Warenkorb
                  </h2>
                  <p className="text-xs text-cyan-300">
                    {state.itemCount} {state.itemCount === 1 ? 'Artikel' : 'Artikel'}
                  </p>
                </div>
              </div>

              <MotionButton
                variant="outline"
                size="sm"
                onClick={closeCart}
                className="w-10 h-10 border-cyan-400/30 text-cyan-300 hover:text-white hover:bg-cyan-500/20"
              >
                <X className="h-4 w-4" />
              </MotionButton>
            </motion.div>

            {/* Content */}
            {state.items.length === 0 ? (
              <motion.div 
                className="flex-1 flex flex-col items-center justify-center p-8 text-center"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.2 }}
              >
                <motion.div
                  className="w-24 h-24 bg-gradient-to-br from-cyan-500/20 to-blue-600/20 rounded-full flex items-center justify-center mb-6"
                  animate={{ 
                    scale: [1, 1.1, 1],
                    rotate: [0, 5, -5, 0]
                  }}
                  transition={{
                    duration: 4,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                >
                  <ShoppingBag className="h-12 w-12 text-cyan-400" />
                </motion.div>
                
                <h3 className="text-xl font-bold text-white mb-2">
                  Dein Warenkorb ist leer
                </h3>
                <p className="text-cyan-300 mb-8 max-w-xs">
                  Entdecke unsere futuristische Tech Fashion-Kollektion und finde deinen Style
                </p>

                <MotionButton
                  variant="tech"
                  size="lg"
                  onClick={closeCart}
                  className="w-full"
                >
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Weitershoppen
                </MotionButton>
              </motion.div>
            ) : (
              <>
                {/* Items with Swipe-to-Remove */}
                <div className="flex-1 overflow-y-auto p-4 space-y-3">
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.2 }}
                    className="space-y-3"
                  >
                    {state.items.map((item, index) => (
                      <motion.div
                        key={getItemKey(item)}
                        initial={{ opacity: 0, x: 50 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -50 }}
                        transition={{ delay: index * 0.05 }}
                        layout
                      >
                        <SwipeableCard
                          onSwipeRight={() => handleSwipeToRemove(item.id, item.size, item.color)}
                          threshold={80}
                          className="relative"
                        >
                          <motion.div
                            className="flex gap-4 p-4 rounded-xl border"
                            style={{
                              background: 'rgba(255, 255, 255, 0.05)',
                              border: '1px solid rgba(6, 182, 212, 0.1)',
                              backdropFilter: 'blur(10px)'
                            }}
                            whileHover={{
                              scale: 1.02,
                              borderColor: 'rgba(6, 182, 212, 0.3)'
                            }}
                          >
                            {/* Product Image */}
                            <motion.div 
                              className="w-16 h-16 rounded-lg overflow-hidden flex-shrink-0 bg-gradient-to-br from-slate-200 to-slate-300"
                              whileHover={{ scale: 1.1 }}
                              transition={{ type: "spring", stiffness: 400 }}
                            >
                              <ImageWithFallback
                                src={item.image}
                                alt={item.name}
                                className="w-full h-full object-cover"
                              />
                            </motion.div>

                            {/* Product Info */}
                            <div className="flex-1 min-w-0">
                              <h4 className="text-sm font-semibold text-white mb-1 truncate">
                                {item.name}
                              </h4>
                              
                              <p className="text-xs text-cyan-300 mb-2">
                                {item.category}
                              </p>
                              
                              {(item.size || item.color) && (
                                <div className="flex gap-1 mb-3">
                                  {item.size && (
                                    <span className="text-xs px-2 py-1 bg-cyan-500/20 text-cyan-300 rounded">
                                      {item.size}
                                    </span>
                                  )}
                                  {item.color && (
                                    <span className="text-xs px-2 py-1 bg-blue-500/20 text-blue-300 rounded">
                                      {item.color}
                                    </span>
                                  )}
                                </div>
                              )}

                              <div className="flex items-center justify-between">
                                {/* Quantity Controls */}
                                <MotionQuantityControls
                                  quantity={item.quantity}
                                  onQuantityChange={(newQuantity) => 
                                    updateQuantity(item.id, newQuantity, item.size, item.color)
                                  }
                                  size="sm"
                                />

                                {/* Price & Remove */}
                                <div className="flex items-center gap-3">
                                  <span className="text-sm font-bold text-cyan-400">
                                    {formatPrice(item.price * item.quantity)}
                                  </span>
                                  
                                  <MotionButton
                                    variant="outline"
                                    size="sm"
                                    onClick={() => removeItem(item.id, item.size, item.color)}
                                    className="w-8 h-8 border-red-500/30 text-red-400 hover:bg-red-500/20 hover:border-red-500"
                                  >
                                    <Trash2 className="h-3 w-3" />
                                  </MotionButton>
                                </div>
                              </div>
                            </div>
                          </motion.div>
                        </SwipeableCard>
                      </motion.div>
                    ))}
                  </motion.div>

                  {/* Swipe Instruction */}
                  <motion.div
                    className="text-center p-3"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.5 }}
                  >
                    <p className="text-xs text-cyan-400/60">
                      💡 Wische nach rechts um Artikel zu entfernen
                    </p>
                  </motion.div>

                  {/* Clear Cart Button */}
                  {state.items.length > 1 && (
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.6 }}
                    >
                      <MotionButton
                        variant="outline"
                        onClick={clearCart}
                        className="w-full border-red-500/30 text-red-400 hover:bg-red-500/20 hover:border-red-500"
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Warenkorb leeren
                      </MotionButton>
                    </motion.div>
                  )}
                </div>

                {/* Enhanced Footer */}
                <motion.div 
                  className="p-6 border-t backdrop-blur-sm"
                  style={{ 
                    borderColor: 'rgba(6, 182, 212, 0.2)',
                    background: 'rgba(255, 255, 255, 0.05)'
                  }}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                >
                  {/* Total */}
                  <motion.div 
                    className="flex justify-between items-center mb-6 p-4 rounded-lg"
                    style={{
                      background: 'rgba(6, 182, 212, 0.1)',
                      border: '1px solid rgba(6, 182, 212, 0.2)'
                    }}
                    whileHover={{ scale: 1.02 }}
                  >
                    <span className="text-lg font-semibold text-white">
                      Gesamt:
                    </span>
                    <motion.span 
                      className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent"
                      key={state.total}
                      initial={{ scale: 1.2 }}
                      animate={{ scale: 1 }}
                      transition={{ type: "spring", stiffness: 400 }}
                    >
                      {formatPrice(state.total)}
                    </motion.span>
                  </motion.div>

                  {/* Action Buttons */}
                  <div className="space-y-3">
                    <MotionButton
                      variant="tech"
                      size="lg"
                      className="w-full"
                    >
                      <CreditCard className="h-4 w-4 mr-2" />
                      Zur Kasse ({formatPrice(state.total)})
                    </MotionButton>
                    
                    <MotionButton
                      variant="outline"
                      onClick={closeCart}
                      className="w-full border-cyan-400/30 text-cyan-300 hover:bg-cyan-500/20"
                    >
                      <ArrowLeft className="h-4 w-4 mr-2" />
                      Weitershoppen
                    </MotionButton>
                  </div>

                  {/* Security Badge */}
                  <motion.div
                    className="flex items-center justify-center gap-2 mt-4 p-2 rounded-lg bg-green-500/10 border border-green-500/20"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.7 }}
                  >
                    <div className="w-4 h-4 bg-green-500 rounded-full flex items-center justify-center">
                      <span className="text-white text-xs">✓</span>
                    </div>
                    <span className="text-xs text-green-400 font-medium">
                      SSL Sicher verschlüsselt
                    </span>
                  </motion.div>
                </motion.div>
              </>
            )}

            {/* Swipe Indicator */}
            <motion.div
              className="absolute top-1/2 left-2 w-1 h-12 bg-gradient-to-b from-transparent via-cyan-400 to-transparent rounded-full opacity-30"
              animate={{ 
                opacity: [0.3, 0.7, 0.3],
                scaleY: [1, 1.2, 1]
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            />
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}