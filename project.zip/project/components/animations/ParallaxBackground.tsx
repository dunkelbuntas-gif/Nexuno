import React, { useEffect, useState } from 'react';
import { motion, useScroll, useTransform } from 'motion/react';

interface ParallaxBackgroundProps {
  children: React.ReactNode;
  backgroundImage?: string;
  parallaxSpeed?: number;
  className?: string;
  overlay?: boolean;
}

export function ParallaxBackground({ 
  children, 
  backgroundImage,
  parallaxSpeed = 0.5,
  className = '',
  overlay = true
}: ParallaxBackgroundProps) {
  const [elementTop, setElementTop] = useState(0);
  const [clientHeight, setClientHeight] = useState(0);
  
  const { scrollY } = useScroll();
  
  const y = useTransform(
    scrollY, 
    [elementTop - clientHeight, elementTop + clientHeight], 
    [-clientHeight * parallaxSpeed, clientHeight * parallaxSpeed]
  );

  useEffect(() => {
    const updateDimensions = () => {
      setClientHeight(window.innerHeight);
    };
    
    updateDimensions();
    window.addEventListener('resize', updateDimensions);
    
    return () => window.removeEventListener('resize', updateDimensions);
  }, []);

  return (
    <div className={`relative overflow-hidden ${className}`}>
      {/* Parallax Background */}
      {backgroundImage && (
        <motion.div
          className="absolute inset-0 w-full h-[120%]"
          style={{
            y,
            backgroundImage: `url(${backgroundImage})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundAttachment: 'fixed',
          }}
        />
      )}
      
      {/* Floating Geometric Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <motion.div
          className="floating-spheres"
          animate={{
            rotate: [0, 360],
            scale: [1, 1.05, 1],
          }}
          transition={{
            duration: 35,
            repeat: Infinity,
            ease: "linear"
          }}
        >
          <div className="sphere sphere-1 sphere-cyan" />
          <div className="sphere sphere-2 sphere-blue" />
          <div className="sphere sphere-3 sphere-lavender" />
          <div className="sphere sphere-4 sphere-white" />
          <div className="sphere sphere-5 sphere-purple" />
        </motion.div>
        
        <motion.div
          className="floating-cubes"
          animate={{
            rotate: [0, -360],
            y: [0, -10, 0],
          }}
          transition={{
            duration: 45,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          <div className="cube cube-1 cube-blue" />
          <div className="cube cube-2 cube-purple" />
          <div className="cube cube-3 cube-cyan" />
          <div className="cube cube-4 cube-white" />
        </motion.div>
        
        <motion.div
          className="floating-arches"
          animate={{
            x: [0, 15, 0],
            rotate: [0, 2, 0],
          }}
          transition={{
            duration: 30,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          <div className="arch arch-1 arch-lavender" />
          <div className="arch arch-2 arch-blue" />
          <div className="arch arch-3 arch-white" />
        </motion.div>
      </div>
      
      {/* Ambient Light Effects */}
      <div className="ambient-lights">
        <motion.div
          className="ambient-light ambient-light-1"
          animate={{
            scale: [1, 1.1, 1],
            opacity: [0.2, 0.4, 0.2],
          }}
          transition={{
            duration: 12,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
        <motion.div
          className="ambient-light ambient-light-2"
          animate={{
            scale: [1.1, 1, 1.1],
            opacity: [0.15, 0.35, 0.15],
          }}
          transition={{
            duration: 15,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 4
          }}
        />
        <motion.div
          className="ambient-light ambient-light-3"
          animate={{
            scale: [1, 1.15, 1],
            opacity: [0.25, 0.45, 0.25],
          }}
          transition={{
            duration: 18,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 8
          }}
        />
      </div>
      
      {/* Overlay */}
      {overlay && (
        <div className="absolute inset-0 bg-gradient-to-br from-white/40 via-white/20 to-white/40 backdrop-blur-sm" />
      )}
      
      {/* Content */}
      <div className="relative z-10">
        {children}
      </div>
    </div>
  );
}