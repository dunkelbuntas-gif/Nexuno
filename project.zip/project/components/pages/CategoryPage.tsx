import { ArrowRight } from 'lucide-react';
import { Button } from '../ui/button';
import { ProductGrid } from '../ProductGrid';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { BackButton } from '../BackButton';
import type { Page } from '../../App';

interface CategoryPageProps {
  category: 'tshirts' | 'hoodies' | 'accessories';
  onNavigate: (page: Page, productId?: string) => void;
  onBack?: () => void;
}

const categoryData = {
  tshirts: {
    title: 'T-Shirts',
    subtitle: 'Futuristische Designs für den Alltag',
    description: 'Unsere T-Shirt Kollektion verbindet minimalistisches Design mit innovativen Materialien. Jedes Stück ist ein Statement für die Zukunft der Mode.',
    heroImage: '/api/placeholder/1200/600',
    gradient: 'from-[var(--neon-cyan)] to-[var(--neon-blue)]'
  },
  hoodies: {
    title: 'Hoodies',
    subtitle: 'Comfort meets Future Fashion',
    description: 'Erlebe ultimativen Komfort mit unseren futuristischen Hoodies. Perfekt für alle, die Style und Gemütlichkeit nicht trennen wollen.',
    heroImage: '/api/placeholder/1200/600',
    gradient: 'from-[var(--neon-magenta)] to-[var(--neon-pink)]'
  },
  accessories: {
    title: 'Accessories',
    subtitle: 'Tech-inspirierte Details',
    description: 'Vervollständige deinen futuristischen Look mit unseren sorgfältig kuratierten Accessories. Kleine Details, große Wirkung.',
    heroImage: '/api/placeholder/1200/600',
    gradient: 'from-[var(--neon-violet)] to-[var(--neon-magenta)]'
  }
};

export function CategoryPage({ category, onNavigate, onBack }: CategoryPageProps) {
  const data = categoryData[category];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-96 overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0">
          <ImageWithFallback
            src={data.heroImage}
            alt={data.title}
            className="w-full h-full object-cover"
          />
          <div className={`absolute inset-0 bg-gradient-to-r ${data.gradient} opacity-80`}></div>
          <div className="absolute inset-0 bg-black/30"></div>
        </div>

        {/* Content */}
        <div className="relative z-10 h-full flex items-center">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
            {/* Back Button */}
            <div className="mb-6">
              <BackButton onBack={onBack} />
            </div>
            <div className="max-w-2xl">
              <h1 className="text-5xl font-bold text-white mb-4">
                {data.title}
              </h1>
              <p className="text-xl text-white/90 mb-6">
                {data.subtitle}
              </p>
              <p className="text-white/80 mb-8 leading-relaxed">
                {data.description}
              </p>
              <Button
                size="lg"
                onClick={() => onNavigate('shop')}
                className="bg-white/10 backdrop-blur-sm border-white/30 text-white hover:bg-white/20"
                variant="outline"
              >
                Alle {data.title} anzeigen
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section className="py-16 gradient-section">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4 font-['Poppins']" style={{ color: 'var(--text-headline)' }}>
              Unsere{' '}
              <span className="bg-gradient-to-r from-[var(--primary-blue)] to-[var(--accent-cyan)] bg-clip-text text-transparent">
                {data.title}
              </span>
            </h2>
            <p className="text-lg max-w-2xl mx-auto font-['Inter']" style={{ color: 'var(--text-body)' }}>
              Entdecke die neuesten Designs aus unserer {data.title.toLowerCase()}-Kategorie
            </p>
          </div>

          <ProductGrid 
            category={category}
            onProductClick={(id) => onNavigate('product', id)} 
          />
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16" style={{ background: 'var(--bg-primary)' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className={`w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-r ${data.gradient} flex items-center justify-center`}>
                <div className="w-8 h-8 bg-white rounded-full"></div>
              </div>
              <h3 className="font-semibold mb-2 font-['Poppins']" style={{ color: 'var(--text-headline)' }}>Premium Qualität</h3>
              <p className="font-['Inter']" style={{ color: 'var(--text-body)' }}>
                Hochwertige Materialien für langanhaltende Freude
              </p>
            </div>
            
            <div className="text-center">
              <div className={`w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-r ${data.gradient} flex items-center justify-center`}>
                <div className="w-8 h-8 bg-white rounded-full"></div>
              </div>
              <h3 className="font-semibold mb-2 font-['Poppins']" style={{ color: 'var(--text-headline)' }}>Nachhaltig</h3>
              <p className="font-['Inter']" style={{ color: 'var(--text-body)' }}>
                Umweltbewusst produziert für eine bessere Zukunft
              </p>
            </div>
            
            <div className="text-center">
              <div className={`w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-r ${data.gradient} flex items-center justify-center`}>
                <div className="w-8 h-8 bg-white rounded-full"></div>
              </div>
              <h3 className="font-semibold mb-2 font-['Poppins']" style={{ color: 'var(--text-headline)' }}>Limitiert</h3>
              <p className="font-['Inter']" style={{ color: 'var(--text-body)' }}>
                Exklusive Designs in limitierter Auflage
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}