import React from 'react';
import { motion } from 'motion/react';

interface SkeletonLoaderProps {
  type?: 'card' | 'text' | 'image' | 'button' | 'product';
  width?: string;
  height?: string;
  className?: string;
  count?: number;
  animated?: boolean;
}

export function SkeletonLoader({ 
  type = 'card', 
  width = 'w-full', 
  height = 'h-48',
  className = '',
  count = 1,
  animated = true
}: SkeletonLoaderProps) {
  const shimmerVariants = {
    loading: {
      x: ['-100%', '100%'],
      transition: {
        repeat: Infinity,
        duration: 1.5,
        ease: 'easeInOut',
      },
    },
  };

  const pulseVariants = {
    loading: {
      opacity: [0.5, 1, 0.5],
      transition: {
        repeat: Infinity,
        duration: 2,
        ease: 'easeInOut',
      },
    },
  };

  const SkeletonElement = ({ index = 0 }: { index?: number }) => {
    const baseClasses = "bg-gray-200 rounded-lg relative overflow-hidden";
    
    const getTypeClasses = () => {
      switch (type) {
        case 'text':
          return 'h-4 w-3/4';
        case 'image':
          return 'aspect-square';
        case 'button':
          return 'h-10 w-32';
        case 'product':
          return 'h-80 w-full';
        default:
          return `${width} ${height}`;
      }
    };

    return (
      <motion.div
        className={`${baseClasses} ${getTypeClasses()} ${className}`}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: index * 0.1, duration: 0.5 }}
      >
        {/* Shimmer Effect */}
        {animated && (
          <motion.div
            className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent"
            variants={shimmerVariants}
            animate="loading"
            style={{
              width: '100%',
              height: '100%',
            }}
          />
        )}
        
        {/* Pulse Effect */}
        {animated && (
          <motion.div
            className="absolute inset-0 bg-gray-300 rounded-lg"
            variants={pulseVariants}
            animate="loading"
          />
        )}
        
        {/* Product Skeleton Details */}
        {type === 'product' && (
          <div className="absolute bottom-4 left-4 right-4 space-y-2">
            <motion.div 
              className="h-3 bg-gray-300 rounded w-3/4"
              variants={pulseVariants}
              animate="loading"
            />
            <motion.div 
              className="h-3 bg-gray-300 rounded w-1/2"
              variants={pulseVariants}
              animate="loading"
              transition={{ delay: 0.2 }}
            />
            <motion.div 
              className="h-4 bg-gray-300 rounded w-1/3"
              variants={pulseVariants}
              animate="loading"
              transition={{ delay: 0.4 }}
            />
          </div>
        )}
      </motion.div>
    );
  };

  if (count === 1) {
    return <SkeletonElement />;
  }

  return (
    <div className="space-y-4">
      {Array.from({ length: count }, (_, index) => (
        <SkeletonElement key={index} index={index} />
      ))}
    </div>
  );
}

// Specialized Product Grid Skeleton
export function ProductGridSkeleton({ count = 8 }: { count?: number }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {Array.from({ length: count }, (_, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: index * 0.1, duration: 0.5 }}
          className="bg-white rounded-2xl p-4 shadow-lg border border-gray-100"
        >
          {/* Image Skeleton */}
          <div className="aspect-square bg-gray-200 rounded-xl mb-4 relative overflow-hidden">
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent"
              animate={{
                x: ['-100%', '100%'],
              }}
              transition={{
                repeat: Infinity,
                duration: 1.5,
                ease: 'easeInOut',
                delay: index * 0.1,
              }}
            />
          </div>
          
          {/* Title Skeleton */}
          <div className="space-y-2">
            <motion.div 
              className="h-4 bg-gray-200 rounded w-3/4"
              animate={{ opacity: [0.5, 1, 0.5] }}
              transition={{ repeat: Infinity, duration: 2, delay: index * 0.1 }}
            />
            <motion.div 
              className="h-3 bg-gray-200 rounded w-1/2"
              animate={{ opacity: [0.5, 1, 0.5] }}
              transition={{ repeat: Infinity, duration: 2, delay: index * 0.1 + 0.2 }}
            />
          </div>
          
          {/* Price Skeleton */}
          <motion.div 
            className="h-5 bg-gray-200 rounded w-1/3 mt-3"
            animate={{ opacity: [0.5, 1, 0.5] }}
            transition={{ repeat: Infinity, duration: 2, delay: index * 0.1 + 0.4 }}
          />
          
          {/* Button Skeleton */}
          <motion.div 
            className="h-10 bg-gray-200 rounded-lg mt-4 w-full"
            animate={{ opacity: [0.5, 1, 0.5] }}
            transition={{ repeat: Infinity, duration: 2, delay: index * 0.1 + 0.6 }}
          />
        </motion.div>
      ))}
    </div>
  );
}