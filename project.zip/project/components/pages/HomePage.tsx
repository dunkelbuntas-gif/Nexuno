import { ArrowRight, Sparkles } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';
import { Input } from '../ui/input';
import { ProductGrid } from '../ProductGrid';
import { HeroSection } from '../HeroSection';
import { PrintOnDemandAnimation } from '../PrintOnDemandAnimation';
import type { Page } from '../../App';
import heroImage from 'figma:asset/57b9a3671729d05d31e4544f2743178209cfda41.png';

interface HomePageProps {
  currentPage: Page;
  onNavigate: (page: Page, productId?: string) => void;
}

export function HomePage({ currentPage, onNavigate }: HomePageProps) {
  const categories = [
    {
      name: 'T-Shirts',
      page: 'tshirts' as Page,
      description: 'Moderne Designs für jeden Tag',
      gradient: 'from-[var(--primary-blue)] to-[var(--accent-cyan)]'
    },
    {
      name: 'Hoodies',
      page: 'hoodies' as Page,
      description: 'Komfort trifft Style',
      gradient: 'from-[var(--accent-cyan)] to-[var(--accent-magenta)]'
    },
    {
      name: 'Accessories',
      page: 'accessories' as Page,
      description: 'Details, die den Unterschied machen',
      gradient: 'from-[var(--accent-magenta)] to-[var(--primary-blue)]'
    }
  ];

  return (
    <div className="min-h-screen" style={{ background: 'var(--bg-primary)' }}>
      {/* Hero Section - Neues futuristisches Design */}
      <HeroSection currentPage={currentPage} onNavigate={onNavigate} />

      {/* Categories Section - Minimalist Clean Design */}
      <section className="py-32 px-4 sm:px-6 lg:px-8" style={{ background: 'var(--bg-secondary)' }}>
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20">
            <h2 className="text-4xl lg:text-5xl font-bold mb-6 text-[var(--text-headline)] font-['Poppins']">
              Entdecke unsere{' '}
              <span className="bg-gradient-to-r from-[var(--primary-blue)] to-[var(--accent-cyan)] bg-clip-text text-transparent">
                Kollektionen
              </span>
            </h2>
            <p className="text-xl text-[var(--text-body)] max-w-2xl mx-auto leading-relaxed font-['Inter']">
              Minimalistisches Design trifft auf futuristische Innovation
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {categories.map((category, index) => (
              <Card 
                key={category.name}
                className="glass-card group overflow-hidden cursor-pointer transition-all duration-500 hover:glow-subtle hover:-translate-y-2"
                onClick={() => onNavigate(category.page)}
              >
                <CardContent className="p-0">
                  <div className={`h-80 bg-gradient-to-br ${category.gradient} relative overflow-hidden`}>
                    <div className="absolute inset-0 bg-white/10 group-hover:bg-white/5 transition-colors"></div>
                    
                    {/* Geometric Frame */}
                    <div className="absolute inset-4 border-2 border-white/30 group-hover:border-white/50 transition-colors"></div>
                    <div className="absolute inset-8 border border-white/20 group-hover:border-white/40 transition-colors"></div>
                    
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="text-center text-white z-10">
                        <h3 className="text-3xl font-bold mb-4 font-['Poppins'] tracking-wider">{category.name}</h3>
                        <p className="text-white/90 font-['Inter'] text-sm tracking-wide">{category.description}</p>
                      </div>
                    </div>
                    
                    <div className="absolute bottom-8 right-8 z-10">
                      <div className="w-12 h-12 border-2 border-white/50 rounded-lg flex items-center justify-center group-hover:border-white group-hover:bg-white/20 transition-all">
                        <ArrowRight className="h-5 w-5 text-white group-hover:translate-x-0.5 transition-transform" />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-32" style={{ background: 'var(--bg-primary)' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-20">
            <h2 className="text-4xl lg:text-5xl font-bold mb-6 text-[var(--text-headline)] font-['Poppins']">
              Featured{' '}
              <span className="bg-gradient-to-r from-[var(--primary-blue)] to-[var(--accent-cyan)] bg-clip-text text-transparent">
                Collection
              </span>
            </h2>
            <p className="text-xl text-[var(--text-body)] max-w-2xl mx-auto leading-relaxed font-['Inter']">
              Präzise gestaltete Stücke für eine minimalistische Zukunft
            </p>
          </div>

          <ProductGrid onProductClick={(id) => onNavigate('product', id)} featured />
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-32 relative overflow-hidden" style={{ background: 'var(--bg-tertiary)' }}>
        {/* Print-on-Demand Animation Background */}
        <PrintOnDemandAnimation />
        
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <div className="glass-surface rounded-3xl p-16 frame-border relative">
            {/* Additional animation overlay inside the glass surface */}
            <div className="absolute inset-0 rounded-3xl overflow-hidden pointer-events-none">
              <div className="absolute top-4 right-4 w-8 h-8 bg-gradient-to-br from-blue-400/30 to-cyan-300/20 rounded-full animate-pulse"></div>
              <div className="absolute bottom-6 left-6 w-6 h-6 bg-gradient-to-br from-purple-400/20 to-blue-300/30 rounded-full animate-pulse" style={{ animationDelay: '1s' }}></div>
              <div className="absolute top-1/2 left-1/3 w-4 h-4 bg-gradient-to-br from-cyan-400/25 to-blue-400/20 rounded-full animate-pulse" style={{ animationDelay: '2s' }}></div>
            </div>
            
            <div className="relative mb-12">
              <h2 className="text-4xl lg:text-6xl font-bold text-[var(--text-headline)] mb-6 font-['Poppins'] tracking-tight">
                Deine Vision –
              </h2>
              <h3 className="text-3xl lg:text-5xl font-bold bg-gradient-to-r from-[var(--primary-blue)] to-[var(--accent-cyan)] bg-clip-text text-transparent font-['Poppins'] tracking-tight">
                unsere Kreation.
              </h3>
            </div>
            <p className="text-xl text-[var(--text-body)] leading-relaxed max-w-3xl mx-auto font-['Inter']">
              Nexuno revolutioniert Fashion durch personalisierte Print-on-Demand Kreationen.
              Jedes Piece entsteht erst auf Bestellung – nachhaltig, individuell, limitless.
              <span className="block mt-4 text-[var(--primary-blue)] font-medium">
                Die Zukunft trägt deinen Namen.
              </span>
            </p>
            
            {/* Creative process visualization */}
            <div className="mt-12 flex justify-center items-center space-x-8 opacity-60">
              <div className="flex flex-col items-center space-y-2">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-400/30 to-blue-500/20 rounded-lg flex items-center justify-center border border-blue-300/30">
                  <span className="text-blue-600 font-bold">1</span>
                </div>
                <span className="text-sm text-[var(--text-muted)] font-medium">Design</span>
              </div>
              
              <div className="w-8 h-px bg-gradient-to-r from-blue-300/50 to-cyan-300/50"></div>
              
              <div className="flex flex-col items-center space-y-2">
                <div className="w-12 h-12 bg-gradient-to-br from-cyan-400/30 to-cyan-500/20 rounded-lg flex items-center justify-center border border-cyan-300/30">
                  <span className="text-cyan-600 font-bold">2</span>
                </div>
                <span className="text-sm text-[var(--text-muted)] font-medium">Print</span>
              </div>
              
              <div className="w-8 h-px bg-gradient-to-r from-cyan-300/50 to-purple-300/50"></div>
              
              <div className="flex flex-col items-center space-y-2">
                <div className="w-12 h-12 bg-gradient-to-br from-purple-400/30 to-purple-500/20 rounded-lg flex items-center justify-center border border-purple-300/30">
                  <span className="text-purple-600 font-bold">3</span>
                </div>
                <span className="text-sm text-[var(--text-muted)] font-medium">Deliver</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-32" style={{ background: 'var(--bg-secondary)' }}>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl lg:text-5xl font-bold mb-6 font-['Poppins'] text-[var(--text-headline)] tracking-tight">
            Stay{' '}
            <span className="bg-gradient-to-r from-[var(--primary-blue)] to-[var(--accent-cyan)] bg-clip-text text-transparent">
              Connected
            </span>
          </h2>
          <p className="text-xl text-[var(--text-body)] mb-12 max-w-2xl mx-auto leading-relaxed font-['Inter']">
            Erfahre als Erste*r von neuen Kollektionen und limitierten Editionen
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto">
            <Input 
              type="email"
              placeholder="Deine E-Mail-Adresse"
              className="glass-card border-white/30 flex-1 text-base py-4 focus:border-[var(--primary-blue)] focus:glow-subtle"
              style={{ 
                background: 'var(--bg-glass)',
                backdropFilter: 'blur(16px)'
              }}
            />
            <Button 
              className="btn-primary text-base px-8 py-4"
            >
              Anmelden
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}