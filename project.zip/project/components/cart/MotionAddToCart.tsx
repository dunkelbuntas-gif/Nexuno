import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShoppingCart, Plus, Check, Heart } from 'lucide-react';
import { useCart } from './CartContext';
import { toast } from 'sonner@2.0.3';

interface MotionAddToCartProps {
  product: {
    id: string;
    name: string;
    price: string;
    image: string;
    category: string;
  };
  size?: 'sm' | 'md' | 'lg';
  variant?: 'default' | 'minimal' | 'floating' | 'tech';
  showSuccess?: boolean;
  className?: string;
}

export function MotionAddToCart({ 
  product, 
  size = 'md',
  variant = 'default',
  showSuccess = true,
  className = '' 
}: MotionAddToCartProps) {
  const { addItem, openCart } = useCart();
  const [isAdding, setIsAdding] = React.useState(false);
  const [showSuccessState, setShowSuccessState] = React.useState(false);
  const [isWishlisted, setIsWishlisted] = React.useState(false);

  const sizeClasses = {
    sm: 'w-8 h-8 text-xs',
    md: 'w-10 h-10 text-sm',
    lg: 'w-12 h-12 text-base'
  };

  const iconSizes = {
    sm: 'h-3 w-3',
    md: 'h-4 w-4', 
    lg: 'h-5 w-5'
  };

  const handleAddToCart = async () => {
    if (isAdding) return;
    
    setIsAdding(true);
    
    // Convert price string to number
    const priceValue = parseFloat(product.price.replace(/[€,]/g, ''));
    
    addItem({
      id: product.id,
      name: product.name,
      price: priceValue,
      image: product.image,
      category: product.category
    });

    // Success Animation
    setTimeout(() => {
      setIsAdding(false);
      if (showSuccess) {
        setShowSuccessState(true);
        toast.success(`${product.name} wurde zum Warenkorb hinzugefügt!`, {
          description: 'Klicke auf den Warenkorb um zur Kasse zu gehen',
          action: {
            label: 'Warenkorb öffnen',
            onClick: () => openCart()
          }
        });
        
        setTimeout(() => setShowSuccessState(false), 2000);
      }
    }, 800);
  };

  const handleWishlist = () => {
    setIsWishlisted(!isWishlisted);
    toast.success(
      isWishlisted ? 'Von Wunschliste entfernt' : 'Zur Wunschliste hinzugefügt',
      { duration: 2000 }
    );
  };

  // Variant Styles
  const variantStyles = {
    default: 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white border border-cyan-400/30',
    minimal: 'bg-white text-cyan-600 border-2 border-cyan-500 hover:bg-cyan-50',
    floating: 'bg-gradient-to-r from-green-500 to-emerald-600 text-white shadow-lg border-0',
    tech: 'bg-gradient-to-r from-slate-800 to-slate-900 text-cyan-400 border border-cyan-400/20'
  };

  if (variant === 'floating') {
    return (
      <motion.button
        className={`${sizeClasses[size]} ${variantStyles[variant]} rounded-full flex items-center justify-center ${className}`}
        onClick={handleAddToCart}
        disabled={isAdding || showSuccessState}
        whileHover={{ 
          scale: 1.1,
          boxShadow: '0 8px 25px rgba(34, 197, 94, 0.4)'
        }}
        whileTap={{ scale: 0.95 }}
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{
          type: "spring",
          stiffness: 300,
          damping: 20
        }}
      >
        <AnimatePresence mode="wait">
          {showSuccessState ? (
            <motion.div
              key="success"
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              exit={{ scale: 0, rotate: 180 }}
              transition={{ type: "spring", stiffness: 400 }}
            >
              <Check className={iconSizes[size]} />
            </motion.div>
          ) : isAdding ? (
            <motion.div
              key="loading"
              initial={{ scale: 0 }}
              animate={{ scale: 1, rotate: 360 }}
              exit={{ scale: 0 }}
              transition={{ 
                rotate: { duration: 0.8, ease: "easeInOut" },
                scale: { type: "spring", stiffness: 400 }
              }}
            >
              <Plus className={iconSizes[size]} />
            </motion.div>
          ) : (
            <motion.div
              key="cart"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0 }}
              whileHover={{ rotate: 5 }}
              transition={{ type: "spring", stiffness: 400 }}
            >
              <ShoppingCart className={iconSizes[size]} />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Ripple Effect */}
        <motion.div
          className="absolute inset-0 rounded-full"
          initial={{ scale: 0, opacity: 0.5 }}
          animate={isAdding ? { scale: 2, opacity: 0 } : { scale: 0, opacity: 0.5 }}
          transition={{ duration: 0.6 }}
          style={{
            background: 'radial-gradient(circle, rgba(255, 255, 255, 0.3) 0%, transparent 70%)'
          }}
        />
      </motion.button>
    );
  }

  return (
    <div className="flex items-center gap-2">
      
      {/* Main Add to Cart Button */}
      <motion.button
        className={`${sizeClasses[size]} ${variantStyles[variant]} rounded-lg flex items-center justify-center font-semibold transition-colors ${className}`}
        onClick={handleAddToCart}
        disabled={isAdding || showSuccessState}
        whileHover={{ 
          scale: 1.05,
          boxShadow: variant === 'default' ? '0 8px 25px rgba(6, 182, 212, 0.3)' : undefined
        }}
        whileTap={{ scale: 0.95 }}
        transition={{
          type: "spring",
          stiffness: 400,
          damping: 17
        }}
      >
        <AnimatePresence mode="wait">
          {showSuccessState ? (
            <motion.div
              key="success"
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              exit={{ scale: 0, rotate: 180 }}
              transition={{ 
                type: "spring", 
                stiffness: 500,
                damping: 20 
              }}
              className="text-green-500"
            >
              <Check className={iconSizes[size]} />
            </motion.div>
          ) : isAdding ? (
            <motion.div
              key="loading"
              initial={{ scale: 0 }}
              animate={{ 
                scale: 1, 
                rotate: [0, 180, 360] 
              }}
              exit={{ scale: 0 }}
              transition={{ 
                rotate: { 
                  duration: 0.8, 
                  ease: "easeInOut",
                  repeat: 0
                },
                scale: { 
                  type: "spring", 
                  stiffness: 400 
                }
              }}
            >
              <Plus className={iconSizes[size]} />
            </motion.div>
          ) : (
            <motion.div
              key="cart"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0 }}
              whileHover={{ y: -1 }}
              transition={{ type: "spring", stiffness: 400 }}
            >
              <ShoppingCart className={iconSizes[size]} />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Loading Progress Bar */}
        {isAdding && (
          <motion.div
            className="absolute bottom-0 left-0 h-0.5 bg-white rounded-full"
            initial={{ width: '0%' }}
            animate={{ width: '100%' }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          />
        )}
      </motion.button>

      {/* Wishlist Button */}
      {variant === 'default' && (
        <motion.button
          className="w-10 h-10 bg-white border-2 border-slate-200 rounded-lg flex items-center justify-center hover:border-pink-300 transition-colors"
          onClick={handleWishlist}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          transition={{
            type: "spring",
            stiffness: 400,
            damping: 17
          }}
        >
          <motion.div
            animate={isWishlisted ? { scale: [1, 1.3, 1] } : { scale: 1 }}
            transition={{ duration: 0.3 }}
          >
            <Heart 
              className={`h-4 w-4 ${isWishlisted ? 'text-pink-500 fill-pink-500' : 'text-slate-600'}`}
            />
          </motion.div>
        </motion.button>
      )}
    </div>
  );
}

interface QuantityControlsProps {
  quantity: number;
  onQuantityChange: (newQuantity: number) => void;
  min?: number;
  max?: number;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export function MotionQuantityControls({
  quantity,
  onQuantityChange,
  min = 1,
  max = 99,
  size = 'md',
  className = ''
}: QuantityControlsProps) {
  const sizeClasses = {
    sm: 'w-6 h-6 text-xs',
    md: 'w-8 h-8 text-sm',
    lg: 'w-10 h-10 text-base'
  };

  const inputSizes = {
    sm: 'w-12 h-6 text-xs',
    md: 'w-16 h-8 text-sm',
    lg: 'w-20 h-10 text-base'
  };

  const handleDecrease = () => {
    if (quantity > min) {
      onQuantityChange(quantity - 1);
    }
  };

  const handleIncrease = () => {
    if (quantity < max) {
      onQuantityChange(quantity + 1);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value) || min;
    const clampedValue = Math.min(Math.max(value, min), max);
    onQuantityChange(clampedValue);
  };

  return (
    <div className={`flex items-center gap-2 ${className}`}>
      
      {/* Decrease Button */}
      <motion.button
        className={`${sizeClasses[size]} bg-slate-100 hover:bg-slate-200 rounded-lg flex items-center justify-center font-bold text-slate-600 border border-slate-200`}
        onClick={handleDecrease}
        disabled={quantity <= min}
        whileHover={quantity > min ? { scale: 1.1 } : {}}
        whileTap={quantity > min ? { scale: 0.9 } : {}}
        transition={{
          type: "spring",
          stiffness: 400,
          damping: 17
        }}
      >
        <motion.span
          animate={{ rotate: quantity === min ? [0, -10, 0] : 0 }}
          transition={{ duration: 0.3 }}
        >
          −
        </motion.span>
      </motion.button>

      {/* Quantity Input */}
      <motion.input
        type="number"
        min={min}
        max={max}
        value={quantity}
        onChange={handleInputChange}
        className={`${inputSizes[size]} text-center border border-slate-200 rounded-lg font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent`}
        key={quantity} // Force re-render for animation
        initial={{ scale: 1.1 }}
        animate={{ scale: 1 }}
        transition={{ duration: 0.2 }}
      />

      {/* Increase Button */}
      <motion.button
        className={`${sizeClasses[size]} bg-cyan-500 hover:bg-cyan-600 text-white rounded-lg flex items-center justify-center font-bold border border-cyan-500`}
        onClick={handleIncrease}
        disabled={quantity >= max}
        whileHover={quantity < max ? { scale: 1.1 } : {}}
        whileTap={quantity < max ? { scale: 0.9 } : {}}
        transition={{
          type: "spring",
          stiffness: 400,
          damping: 17
        }}
      >
        <motion.span
          animate={{ rotate: quantity === max ? [0, 10, 0] : 0 }}
          transition={{ duration: 0.3 }}
        >
          +
        </motion.span>
      </motion.button>
    </div>
  );
}

interface AddToCartFeedbackProps {
  isVisible: boolean;
  product: {
    name: string;
    image: string;
    price: string;
  };
  onClose: () => void;
}

export function AddToCartFeedback({ isVisible, product, onClose }: AddToCartFeedbackProps) {
  React.useEffect(() => {
    if (isVisible) {
      const timer = setTimeout(onClose, 3000);
      return () => clearTimeout(timer);
    }
  }, [isVisible, onClose]);

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          className="fixed top-4 right-4 z-50 bg-white rounded-xl shadow-lg border border-slate-200 p-4 max-w-sm"
          initial={{ x: 300, opacity: 0, scale: 0.8 }}
          animate={{ x: 0, opacity: 1, scale: 1 }}
          exit={{ x: 300, opacity: 0, scale: 0.8 }}
          transition={{
            type: "spring",
            stiffness: 300,
            damping: 20
          }}
        >
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <motion.div
                initial={{ scale: 0, rotate: -180 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ delay: 0.2, type: "spring", stiffness: 400 }}
              >
                <Check className="h-6 w-6 text-green-500" />
              </motion.div>
            </div>
            
            <div className="flex-1">
              <motion.h3 
                className="font-semibold text-slate-900 text-sm"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
              >
                Zum Warenkorb hinzugefügt!
              </motion.h3>
              <motion.p 
                className="text-xs text-slate-600"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
              >
                {product.name}
              </motion.p>
            </div>

            <motion.button
              onClick={onClose}
              className="w-6 h-6 text-slate-400 hover:text-slate-600 transition-colors"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              ×
            </motion.button>
          </div>

          {/* Progress Bar */}
          <motion.div
            className="mt-3 h-1 bg-slate-100 rounded-full overflow-hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            <motion.div
              className="h-full bg-green-500 rounded-full"
              initial={{ width: '100%' }}
              animate={{ width: '0%' }}
              transition={{ duration: 3, ease: "linear" }}
            />
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}