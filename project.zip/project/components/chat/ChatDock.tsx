import React, { useState, useEffect, useRef } from 'react';
import { MessageCircle, X, Headphones } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { AIChatBot } from './AIChatBot';

interface ChatDockProps {
  position?: 'bottom-right' | 'bottom-left';
  onEscalateToHuman?: () => void;
}

export function ChatDock({ 
  position = 'bottom-right',
  onEscalateToHuman 
}: ChatDockProps) {
  const [isOpen, setIsOpen] = useState(false);
  const panelRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);

  // Positionierungsklassen
  const positionClasses = {
    'bottom-right': 'bottom-6 right-6',
    'bottom-left': 'bottom-6 left-6'
  };

  // Overlay schließen beim Klick außerhalb
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (isOpen && 
          panelRef.current && 
          !panelRef.current.contains(event.target as Node) &&
          triggerRef.current &&
          !triggerRef.current.contains(event.target as Node)) {
        closeChat();
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  // ESC-Taste schließt Chat
  useEffect(() => {
    const handleEscapeKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && isOpen) {
        closeChat();
      }
    };

    if (isOpen) {
      document.addEventListener('keydown', handleEscapeKey);
    }

    return () => {
      document.removeEventListener('keydown', handleEscapeKey);
    };
  }, [isOpen]);

  // Fokus-Management für Accessibility
  useEffect(() => {
    if (isOpen && panelRef.current) {
      // Fokus in das Panel setzen
      const firstFocusableElement = panelRef.current.querySelector(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
      ) as HTMLElement;
      
      if (firstFocusableElement) {
        firstFocusableElement.focus();
      }
    }
  }, [isOpen]);

  const openChat = () => {
    setIsOpen(true);
  };

  const closeChat = () => {
    setIsOpen(false);
    // Fokus zurück auf Trigger Button
    if (triggerRef.current) {
      triggerRef.current.focus();
    }
  };

  const handleEscalateToHuman = () => {
    // Chat schließen und Human Escalation auslösen
    closeChat();
    if (onEscalateToHuman) {
      onEscalateToHuman();
    }
  };

  return (
    <>
      {/* Overlay für Panel-Schließung */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-40 bg-black/20 backdrop-blur-sm"
            onClick={closeChat}
            aria-hidden="true"
          />
        )}
      </AnimatePresence>

      {/* Floating Chat Button */}
      <AnimatePresence>
        {!isOpen && (
          <motion.button
            ref={triggerRef}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            whileHover={{ 
              scale: 1.05,
              boxShadow: '0 0 25px rgba(6, 182, 212, 0.4)'
            }}
            whileTap={{ scale: 0.95 }}
            onClick={openChat}
            className={`fixed ${positionClasses[position]} z-50 w-16 h-16 bg-gradient-to-br from-cyan-500 to-blue-600 text-white rounded-full shadow-lg transition-all duration-300 flex items-center justify-center group`}
            aria-label="Support Chat öffnen"
            role="button"
            tabIndex={0}
          >
            <MessageCircle className="h-6 w-6 group-hover:scale-110 transition-transform" />
            
            {/* Pulsing Ring Effect */}
            <motion.div
              className="absolute inset-0 rounded-full border-2 border-cyan-400"
              animate={{
                scale: [1, 1.3, 1],
                opacity: [0.5, 0, 0.5],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />
          </motion.button>
        )}
      </AnimatePresence>

      {/* Chat Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            ref={panelRef}
            initial={{ 
              opacity: 0, 
              y: 100, 
              scale: 0.8,
              x: position === 'bottom-left' ? -20 : 20
            }}
            animate={{ 
              opacity: 1, 
              y: 0, 
              scale: 1,
              x: 0
            }}
            exit={{ 
              opacity: 0, 
              y: 100, 
              scale: 0.8,
              x: position === 'bottom-left' ? -20 : 20
            }}
            transition={{
              type: "spring",
              stiffness: 300,
              damping: 30
            }}
            className={`fixed ${positionClasses[position]} z-50 w-96 h-[520px] max-w-[calc(100vw-2rem)] max-h-[calc(100vh-2rem)] overflow-hidden`}
            style={{
              background: 'rgba(15, 23, 42, 0.95)',
              backdropFilter: 'blur(20px)',
              border: '1px solid rgba(255, 255, 255, 0.1)',
              borderRadius: '24px',
              boxShadow: '0 20px 60px rgba(0, 0, 0, 0.3), 0 0 40px rgba(6, 182, 212, 0.1)'
            }}
            role="dialog"
            aria-modal="true"
            aria-labelledby="chat-panel-title"
          >
            {/* Panel Header */}
            <div className="flex items-center justify-between p-6 border-b border-slate-700">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-full flex items-center justify-center">
                  <MessageCircle className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h3 
                    id="chat-panel-title"
                    className="text-white font-semibold text-lg"
                  >
                    Support Chat
                  </h3>
                  <p className="text-slate-400 text-sm">
                    AI-Assistent • 24/7 verfügbar
                  </p>
                </div>
              </div>
              
              <button
                onClick={closeChat}
                className="p-2 hover:bg-slate-700 rounded-lg transition-colors group"
                aria-label="Chat schließen"
                type="button"
              >
                <X className="h-5 w-5 text-slate-400 group-hover:text-white transition-colors" />
              </button>
            </div>

            {/* Chat Content Container */}
            <div 
              className="p-4 h-[calc(100%-88px)] overflow-hidden custom-scrollbar"
              style={{
                background: 'linear-gradient(135deg, rgba(15, 23, 42, 0.9) 0%, rgba(30, 41, 59, 0.9) 100%)'
              }}
            >
              {/* AI Chat Bot Content */}
              <div className="h-full overflow-y-auto custom-scrollbar">
                <AIChatBot onEscalateToHuman={handleEscalateToHuman} />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}