import React, { useEffect, useState } from 'react';

interface SafePageTransitionProps {
  children: React.ReactNode;
  pageKey: string;
  transitionType?: 'fade' | 'slide' | 'scale';
  direction?: 'left' | 'right' | 'up' | 'down';
  duration?: number;
  className?: string;
}

export function SafePageTransition({ 
  children, 
  pageKey,
  transitionType = 'fade',
  direction = 'right',
  duration = 300,
  className = ''
}: SafePageTransitionProps) {
  const [isVisible, setIsVisible] = useState(false);
  const [currentKey, setCurrentKey] = useState(pageKey);

  useEffect(() => {
    if (pageKey !== currentKey) {
      // Start exit animation
      setIsVisible(false);
      
      // Wait for exit animation, then change content
      setTimeout(() => {
        setCurrentKey(pageKey);
        // Start enter animation
        setTimeout(() => setIsVisible(true), 50);
      }, duration);
    } else {
      // Initial mount
      setTimeout(() => setIsVisible(true), 50);
    }
  }, [pageKey, currentKey, duration]);

  const getTransitionClasses = () => {
    let classes = 'safe-page-transition';
    
    if (transitionType === 'slide') {
      classes += ` safe-page-slide-${direction}`;
    } else if (transitionType === 'scale') {
      classes += ' safe-page-scale';
    } else {
      classes += ' safe-page-fade';
    }
    
    if (isVisible) {
      classes += ' safe-page-visible';
    }
    
    return classes;
  };

  return (
    <div 
      className={`${getTransitionClasses()} ${className}`}
      style={{ 
        transitionDuration: `${duration}ms`
      }}
    >
      {children}
    </div>
  );
}

// Simple Loading Transition without complex state management
export function SafeLoadingTransition({ 
  isLoading, 
  children 
}: { 
  isLoading: boolean; 
  children: React.ReactNode; 
}) {
  return (
    <div className={`safe-loading-transition ${!isLoading ? 'safe-loading-complete' : ''}`}>
      {children}
    </div>
  );
}