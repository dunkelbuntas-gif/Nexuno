/**
 * Printful Product Grid Component
 * Displays real Printful products with live data
 */

import React, { useState, useEffect } from 'react';
import { printfulApi, printfulHelpers, type PrintfulProduct } from '../../lib/printful-api';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Skeleton } from '../ui/skeleton';
import { ShoppingCart, Eye, Heart } from 'lucide-react';

interface PrintfulProductGridProps {
  category?: string;
  onProductSelect?: (product: PrintfulProduct) => void;
}

export function PrintfulProductGrid({ category, onProductSelect }: PrintfulProductGridProps) {
  const [products, setProducts] = useState<PrintfulProduct[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadProducts();
  }, [category]);

  const loadProducts = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await printfulApi.getProducts(category);
      setProducts(response.result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load products');
    } finally {
      setLoading(false);
    }
  };

  const handleProductClick = (product: PrintfulProduct) => {
    if (onProductSelect) {
      onProductSelect(product);
    }
  };

  if (loading) {
    return <ProductGridSkeleton />;
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <div className="text-red-500 mb-4">
          <p>Error loading products: {error}</p>
        </div>
        <Button onClick={loadProducts} variant="outline">
          Try Again
        </Button>
      </div>
    );
  }

  if (products.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500 mb-4">No products found</p>
        <Button onClick={loadProducts} variant="outline">
          Refresh
        </Button>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {products.map((product, index) => (
        <div
          key={product.id}
          className="animate-fade-in-up"
          style={{ animationDelay: `${index * 0.1}s` }}
        >
          <PrintfulProductCard 
            product={product} 
            onSelect={() => handleProductClick(product)}
          />
        </div>
      ))}
    </div>
  );
}

interface PrintfulProductCardProps {
  product: PrintfulProduct;
  onSelect: () => void;
}

function PrintfulProductCard({ product, onSelect }: PrintfulProductCardProps) {
  const [imageLoading, setImageLoading] = useState(true);
  const [imageError, setImageError] = useState(false);

  return (
    <Card className="group hover:shadow-lg transition-all duration-300 overflow-hidden bg-white border-gray-200">
      {/* Product Image */}
      <div className="relative aspect-square overflow-hidden bg-gray-100">
        {imageLoading && (
          <div className="absolute inset-0 bg-gray-200 animate-pulse" />
        )}
        {!imageError ? (
          <img
            src={product.thumbnail_url}
            alt={product.name}
            className={`w-full h-full object-cover transition-transform duration-300 group-hover:scale-105 ${
              imageLoading ? 'opacity-0' : 'opacity-100'
            }`}
            onLoad={() => setImageLoading(false)}
            onError={() => {
              setImageLoading(false);
              setImageError(true);
            }}
          />
        ) : (
          <div className="flex items-center justify-center h-full text-gray-400">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-2 bg-gray-300 rounded-lg flex items-center justify-center">
                <ShoppingCart className="w-8 h-8" />
              </div>
              <p className="text-sm">No Image</p>
            </div>
          </div>
        )}

        {/* Overlay Actions */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300 flex items-center justify-center opacity-0 group-hover:opacity-100">
          <div className="flex gap-2">
            <Button
              size="sm"
              variant="secondary"
              className="bg-white/90 hover:bg-white text-gray-900"
              onClick={onSelect}
            >
              <Eye className="w-4 h-4 mr-2" />
              View Details
            </Button>
          </div>
        </div>

        {/* Product Status Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-1">
          {product.synced ? (
            <Badge variant="secondary" className="bg-green-100 text-green-800 text-xs">
              Available
            </Badge>
          ) : (
            <Badge variant="destructive" className="text-xs">
              Not Synced
            </Badge>
          )}
          {product.variants > 0 && (
            <Badge variant="outline" className="text-xs bg-white/90">
              {product.variants} variants
            </Badge>
          )}
        </div>
      </div>

      {/* Product Info */}
      <div className="p-4">
        <div className="space-y-2">
          <h3 className="font-medium text-gray-900 line-clamp-2 group-hover:text-cyan-600 transition-colors">
            {product.name}
          </h3>
          
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-500">
              ID: {product.external_id || product.id}
            </span>
            {product.variants > 0 && (
              <span className="text-sm text-gray-500">
                {product.variants} option{product.variants !== 1 ? 's' : ''}
              </span>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="mt-4 flex gap-2">
          <Button
            onClick={onSelect}
            className="flex-1 bg-gradient-to-r from-cyan-500 to-cyan-600 hover:from-cyan-600 hover:to-cyan-700 text-white"
            size="sm"
          >
            <ShoppingCart className="w-4 h-4 mr-2" />
            Customize
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="border-gray-300 hover:border-cyan-500 hover:text-cyan-600"
          >
            <Heart className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </Card>
  );
}

function ProductGridSkeleton() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {Array.from({ length: 8 }).map((_, index) => (
        <Card key={index} className="overflow-hidden">
          <Skeleton className="aspect-square w-full" />
          <div className="p-4 space-y-3">
            <Skeleton className="h-5 w-3/4" />
            <Skeleton className="h-4 w-1/2" />
            <div className="flex gap-2">
              <Skeleton className="h-8 flex-1" />
              <Skeleton className="h-8 w-10" />
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
}

export default PrintfulProductGrid;