import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ShoppingCart, Plus, Eye, Star, Package } from 'lucide-react';
import { useCart } from './CartContext';
import { Button } from '../ui/button';
import { Card } from '../ui/card';
import { Badge } from '../ui/badge';
import { MiniCart } from './MiniCart';
import { CartDrawer } from './CartDrawer';
import { toast } from 'sonner@2.0.3';

export function CartDemo() {
  const { addItem, state } = useCart();
  const [showDrawer, setShowDrawer] = useState(false);

  // Demo products
  const demoProducts = [
    {
      id: 'demo-tshirt-1',
      name: 'Future Tech T-Shirt',
      description: 'Minimalistisches T-Shirt mit futuristischem Design',
      price: 39.99,
      image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=500&h=500&fit=crop',
      category: 'T-Shirts',
      rating: 4.8,
      reviews: 42,
      sizes: ['S', 'M', 'L', 'XL'],
      colors: ['Schwarz', 'Weiß', 'Grau']
    },
    {
      id: 'demo-hoodie-1',
      name: 'Cyber Future Hoodie',
      description: 'Premium Hoodie mit futuristischem Cyber-Design',
      price: 79.99,
      image: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=500&h=500&fit=crop',
      category: 'Hoodies',
      rating: 4.9,
      reviews: 37,
      sizes: ['M', 'L', 'XL'],
      colors: ['Schwarz', 'Navy', 'Grau']
    },
    {
      id: 'demo-accessory-1',
      name: 'Neural Interface Band',
      description: 'Futuristisches Armband mit LED-Details',
      price: 149.99,
      image: 'https://images.unsplash.com/photo-1611652022419-a9419f74343d?w=500&h=500&fit=crop',
      category: 'Accessoires',
      rating: 4.7,
      reviews: 28,
      sizes: ['One Size'],
      colors: ['Neon Grün', 'Cyber Blau', 'Hot Pink']
    }
  ];

  const handleAddToCart = (product: any) => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      category: product.category,
      size: product.sizes[0], // Default size
      color: product.colors[0] // Default color
    });
    
    toast.success(`${product.name} wurde zum Warenkorb hinzugefügt!`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-gray-100 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            🛒 Nexuno Cart System Demo
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Erleben Sie unser umfassendes, stylisches Shopping Cart System mit 
            glassmorphism-Effekten, smooth Animationen und erstklassiger UX.
          </p>
        </div>

        {/* Cart Components Overview */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          {/* MiniCart Demo */}
          <Card className="p-6 bg-white/80 backdrop-blur-sm">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-gradient-to-r from-cyan-500 to-cyan-600 rounded-lg">
                <ShoppingCart className="w-5 h-5 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900">MiniCart</h3>
            </div>
            <p className="text-gray-600 mb-4">
              Kompakter Cart für den Header mit Dropdown-Funktionalität
            </p>
            <div className="flex justify-center">
              <MiniCart onCheckout={() => toast.success('Checkout gestartet!')} />
            </div>
          </Card>

          {/* CartDrawer Demo */}
          <Card className="p-6 bg-white/80 backdrop-blur-sm">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-gradient-to-r from-purple-500 to-purple-600 rounded-lg">
                <Package className="w-5 h-5 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900">CartDrawer</h3>
            </div>
            <p className="text-gray-600 mb-4">
              Bottom-Sheet Style Cart für mobile Geräte
            </p>
            <Button
              onClick={() => setShowDrawer(true)}
              className="w-full bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white"
            >
              Drawer öffnen
            </Button>
          </Card>

          {/* Cart Stats */}
          <Card className="p-6 bg-gradient-to-r from-cyan-50 to-blue-50 border border-cyan-200">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-gradient-to-r from-green-500 to-green-600 rounded-lg">
                <Star className="w-5 h-5 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900">Cart Status</h3>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-600">Artikel im Warenkorb:</span>
                <Badge variant="outline">{state.itemCount}</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Gesamtwert:</span>
                <span className="font-semibold">€{state.total.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Cart Status:</span>
                <Badge variant={state.isOpen ? 'default' : 'secondary'}>
                  {state.isOpen ? 'Geöffnet' : 'Geschlossen'}
                </Badge>
              </div>
            </div>
          </Card>
        </div>

        {/* Demo Products */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">
            Demo Produkte - Zum Warenkorb hinzufügen
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {demoProducts.map((product, index) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="p-6 bg-white/80 backdrop-blur-sm hover:shadow-lg transition-all duration-300 group">
                  {/* Product Image */}
                  <div className="relative aspect-square rounded-lg overflow-hidden mb-4">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  </div>

                  {/* Product Info */}
                  <div className="space-y-3">
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-1">{product.name}</h3>
                      <p className="text-sm text-gray-600">{product.description}</p>
                    </div>

                    {/* Rating */}
                    <div className="flex items-center gap-2">
                      <div className="flex items-center">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-4 h-4 ${
                              i < Math.floor(product.rating)
                                ? 'text-yellow-400 fill-current'
                                : 'text-gray-300'
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-sm text-gray-600">
                        {product.rating} ({product.reviews} Bewertungen)
                      </span>
                    </div>

                    {/* Price and Actions */}
                    <div className="flex items-center justify-between">
                      <span className="text-xl font-bold text-gray-900">
                        €{product.price}
                      </span>
                      
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          className="p-2"
                          onClick={() => toast.info('Quick View wird geöffnet...')}
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                        
                        <Button
                          size="sm"
                          onClick={() => handleAddToCart(product)}
                          className="bg-gradient-to-r from-cyan-500 to-cyan-600 hover:from-cyan-600 hover:to-cyan-700 text-white"
                        >
                          <Plus className="w-4 h-4 mr-1" />
                          Hinzufügen
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Features Overview */}
        <Card className="p-8 bg-gradient-to-r from-slate-800 to-slate-900 text-white">
          <h2 className="text-2xl font-bold mb-6 text-center">
            🚀 Cart System Features
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-cyan-500 to-cyan-600 rounded-lg flex items-center justify-center mx-auto mb-3">
                <ShoppingCart className="w-6 h-6" />
              </div>
              <h3 className="font-semibold mb-2">Multiple Cart Views</h3>
              <p className="text-sm text-gray-300">
                Sidebar, Drawer, Page und MiniCart für verschiedene Use Cases
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-purple-600 rounded-lg flex items-center justify-center mx-auto mb-3">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                >
                  <Star className="w-6 h-6" />
                </motion.div>
              </div>
              <h3 className="font-semibold mb-2">Smooth Animations</h3>
              <p className="text-sm text-gray-300">
                Framer Motion powered Animationen für erstklassige UX
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-green-600 rounded-lg flex items-center justify-center mx-auto mb-3">
                <Package className="w-6 h-6" />
              </div>
              <h3 className="font-semibold mb-2">Complete Checkout</h3>
              <p className="text-sm text-gray-300">
                Multi-step Checkout Process mit Validierung und Confirmation
              </p>
            </div>
          </div>
        </Card>
      </div>

      {/* CartDrawer */}
      <CartDrawer
        isOpen={showDrawer}
        onClose={() => setShowDrawer(false)}
        onCheckout={() => {
          setShowDrawer(false);
          toast.success('Checkout gestartet!');
        }}
      />
    </div>
  );
}