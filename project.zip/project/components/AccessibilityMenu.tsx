import { useState, useEffect, useRef } from 'react';
import { X, Accessibility, Eye, Type, MousePointer, Volume2, RotateCcw, Plus, Minus } from 'lucide-react';

interface AccessibilitySettings {
  highContrast: boolean;
  largeText: boolean;
  textSize: number; // 100-200%
  focusEnhanced: boolean;
  colorblindFriendly: boolean;
  keyboardNavigation: boolean;
  reduceMotion: boolean;
  screenReaderMode: boolean;
}

const defaultSettings: AccessibilitySettings = {
  highContrast: false,
  largeText: false,
  textSize: 100,
  focusEnhanced: false,
  colorblindFriendly: false,
  keyboardNavigation: false,
  reduceMotion: false,
  screenReaderMode: false
};

export function AccessibilityMenu() {
  const [isOpen, setIsOpen] = useState(false);
  const [settings, setSettings] = useState<AccessibilitySettings>(defaultSettings);
  const dialogRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const firstFocusableRef = useRef<HTMLInputElement>(null);

  // Load settings on mount - Performance optimized
  useEffect(() => {
    try {
      const saved = localStorage.getItem('nexuno-accessibility-settings');
      if (saved) {
        const parsed = JSON.parse(saved);
        setSettings(parsed);
        applySettingsToDOM(parsed);
      }

      // Respect system preferences
      if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        updateSetting('reduceMotion', true);
      }
      if (window.matchMedia('(prefers-contrast: high)').matches) {
        updateSetting('highContrast', true);
      }
    } catch (error) {
      console.warn('Could not load accessibility settings:', error);
    }
  }, []);

  // Apply settings to DOM - Optimized batch operations
  const applySettingsToDOM = (newSettings: AccessibilitySettings) => {
    const html = document.documentElement;
    
    // Remove all classes first (batch operation)
    html.classList.remove(
      'high-contrast',
      'large-text', 
      'focus-visible-enhanced',
      'colorblind-friendly',
      'keyboard-navigation',
      'reduce-motion',
      'screen-reader-mode'
    );

    // Apply active settings (batch operation)
    const classesToAdd: string[] = [];
    
    if (newSettings.highContrast) classesToAdd.push('high-contrast');
    if (newSettings.largeText) classesToAdd.push('large-text');
    if (newSettings.focusEnhanced) classesToAdd.push('focus-visible-enhanced');
    if (newSettings.colorblindFriendly) classesToAdd.push('colorblind-friendly');
    if (newSettings.keyboardNavigation) classesToAdd.push('keyboard-navigation');
    if (newSettings.reduceMotion) classesToAdd.push('reduce-motion');
    if (newSettings.screenReaderMode) classesToAdd.push('screen-reader-mode');

    if (classesToAdd.length > 0) {
      html.classList.add(...classesToAdd);
    }

    // Apply custom text size
    if (newSettings.textSize !== 100) {
      html.style.setProperty('--accessibility-text-scale', `${newSettings.textSize}%`);
    } else {
      html.style.removeProperty('--accessibility-text-scale');
    }
  };

  // Update individual setting - Performance optimized
  const updateSetting = (key: keyof AccessibilitySettings, value: boolean | number) => {
    const newSettings = { ...settings, [key]: value };
    setSettings(newSettings);
    applySettingsToDOM(newSettings);
    
    // Save to localStorage
    try {
      localStorage.setItem('nexuno-accessibility-settings', JSON.stringify(newSettings));
    } catch (error) {
      console.warn('Could not save accessibility settings:', error);
    }

    // Announce change to screen readers
    announceChange(key, value);
  };

  // Screen reader announcements - WCAG 2.1 AA compliant
  const announceChange = (setting: keyof AccessibilitySettings, value: boolean | number) => {
    const messages: Record<string, string> = {
      highContrast: value ? 'Hoher Kontrast aktiviert' : 'Hoher Kontrast deaktiviert',
      largeText: value ? 'Große Schrift aktiviert' : 'Große Schrift deaktiviert',
      focusEnhanced: value ? 'Verstärkte Fokus-Hervorhebung aktiviert' : 'Verstärkte Fokus-Hervorhebung deaktiviert',
      colorblindFriendly: value ? 'Farbenblind-freundliche Farben aktiviert' : 'Farbenblind-freundliche Farben deaktiviert',
      keyboardNavigation: value ? 'Erweiterte Tastatur-Navigation aktiviert' : 'Erweiterte Tastatur-Navigation deaktiviert',
      reduceMotion: value ? 'Reduzierte Bewegungen aktiviert' : 'Reduzierte Bewegungen deaktiviert',
      screenReaderMode: value ? 'Screen Reader Modus aktiviert' : 'Screen Reader Modus deaktiviert',
      textSize: `Textgröße auf ${value}% eingestellt`
    };

    const announcement = document.createElement('div');
    announcement.setAttribute('aria-live', 'polite');
    announcement.setAttribute('aria-atomic', 'true');
    announcement.className = 'sr-only';
    announcement.textContent = messages[setting];
    document.body.appendChild(announcement);
    
    setTimeout(() => {
      if (document.body.contains(announcement)) {
        document.body.removeChild(announcement);
      }
    }, 1000);
  };

  // Reset all settings - WCAG 2.1 AA compliant
  const resetSettings = () => {
    setSettings(defaultSettings);
    applySettingsToDOM(defaultSettings);
    
    try {
      localStorage.removeItem('nexuno-accessibility-settings');
    } catch (error) {
      console.warn('Could not reset accessibility settings:', error);
    }

    // Announce reset
    const announcement = document.createElement('div');
    announcement.setAttribute('aria-live', 'polite');
    announcement.setAttribute('aria-atomic', 'true');
    announcement.className = 'sr-only';
    announcement.textContent = 'Alle Barrierefreiheits-Einstellungen zurückgesetzt';
    document.body.appendChild(announcement);
    
    setTimeout(() => {
      if (document.body.contains(announcement)) {
        document.body.removeChild(announcement);
      }
    }, 1000);
  };

  // Keyboard navigation and focus management - WCAG 2.1 AA
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsOpen(false);
        triggerRef.current?.focus();
      }

      // Tab trapping for modal
      if (e.key === 'Tab') {
        const focusableElements = dialogRef.current?.querySelectorAll(
          'button, input[type="checkbox"], input[type="range"], [tabindex]:not([tabindex="-1"])'
        );
        
        if (!focusableElements || focusableElements.length === 0) return;

        const firstElement = focusableElements[0] as HTMLElement;
        const lastElement = focusableElements[focusableElements.length - 1] as HTMLElement;

        if (e.shiftKey) {
          if (document.activeElement === firstElement) {
            e.preventDefault();
            lastElement.focus();
          }
        } else {
          if (document.activeElement === lastElement) {
            e.preventDefault();
            firstElement.focus();
          }
        }
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    
    // Focus first element when modal opens
    setTimeout(() => {
      firstFocusableRef.current?.focus();
    }, 100);

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen]);

  // Text size adjustment helpers
  const adjustTextSize = (delta: number) => {
    const newSize = Math.max(100, Math.min(200, settings.textSize + delta));
    updateSetting('textSize', newSize);
  };

  // Close modal when clicking backdrop
  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      setIsOpen(false);
    }
  };

  return (
    <>
      {/* Accessibility Trigger Button - WCAG 2.1 AA compliant */}
      <button
        ref={triggerRef}
        className="accessibility-trigger"
        aria-label="Barrierefreiheits-Einstellungen öffnen"
        aria-expanded={isOpen}
        aria-haspopup="dialog"
        onClick={() => setIsOpen(true)}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            setIsOpen(true);
          }
        }}
      >
        <Accessibility size={24} aria-hidden="true" />
        <span className="sr-only">Barrierefreiheits-Einstellungen</span>
      </button>

      {/* Modal Backdrop */}
      {isOpen && (
        <div 
          className="accessibility-backdrop"
          onClick={handleBackdropClick}
          aria-hidden="true"
        />
      )}

      {/* Accessibility Menu Modal - WCAG 2.1 AA compliant */}
      {isOpen && (
        <div
          ref={dialogRef}
          className="accessibility-menu"
          role="dialog"
          aria-modal="true"
          aria-labelledby="accessibility-menu-title"
          aria-describedby="accessibility-menu-desc"
        >
          {/* Header */}
          <div className="accessibility-menu-header">
            <h2 id="accessibility-menu-title" className="accessibility-menu-title">
              <Accessibility size={20} aria-hidden="true" />
              Barrierefreiheits-Einstellungen
            </h2>
            <button
              className="accessibility-close-btn"
              onClick={() => setIsOpen(false)}
              aria-label="Einstellungen schließen"
            >
              <X size={20} aria-hidden="true" />
            </button>
          </div>

          {/* Content */}
          <div className="accessibility-menu-content">
            <p id="accessibility-menu-desc" className="accessibility-help-text" style={{ marginBottom: '20px' }}>
              Passen Sie die Website an Ihre Bedürfnisse an. Alle Einstellungen werden automatisch gespeichert und sind WCAG 2.1 AA konform.
            </p>

            {/* Visual & Contrast Section */}
            <div className="accessibility-section">
              <h3 className="accessibility-section-title">
                <Eye size={16} aria-hidden="true" />
                Sehen & Kontrast
              </h3>
              <div className="accessibility-controls">
                <label className="accessibility-control">
                  <div className="accessibility-control-label">
                    <input
                      ref={firstFocusableRef}
                      type="checkbox"
                      checked={settings.highContrast}
                      onChange={(e) => updateSetting('highContrast', e.target.checked)}
                      aria-describedby="high-contrast-desc"
                    />
                    <strong>Hoher Kontrast</strong>
                  </div>
                  <div id="high-contrast-desc" className="accessibility-control-desc">
                    Verstärkt Farben und Kontraste auf 200% für bessere Sichtbarkeit (WCAG AAA Level)
                  </div>
                </label>

                <label className="accessibility-control">
                  <div className="accessibility-control-label">
                    <input
                      type="checkbox"
                      checked={settings.colorblindFriendly}
                      onChange={(e) => updateSetting('colorblindFriendly', e.target.checked)}
                      aria-describedby="colorblind-desc"
                    />
                    <strong>Farbenblind-freundlich</strong>
                  </div>
                  <div id="colorblind-desc" className="accessibility-control-desc">
                    Optimierte Farben für Deuteranopie und Protanopie (Rot-Grün-Blindheit)
                  </div>
                </label>
              </div>
            </div>

            {/* Text & Typography Section */}
            <div className="accessibility-section">
              <h3 className="accessibility-section-title">
                <Type size={16} aria-hidden="true" />
                Text & Typografie
              </h3>
              <div className="accessibility-controls">
                <label className="accessibility-control">
                  <div className="accessibility-control-label">
                    <input
                      type="checkbox"
                      checked={settings.largeText}
                      onChange={(e) => updateSetting('largeText', e.target.checked)}
                      aria-describedby="large-text-desc"
                    />
                    <strong>Große Schrift</strong>
                  </div>
                  <div id="large-text-desc" className="accessibility-control-desc">
                    Vergrößert alle Texte um 150% für bessere Lesbarkeit (WCAG AAA Level)
                  </div>
                </label>

                <div className="accessibility-control">
                  <div className="accessibility-control-label">
                    <strong>Textgröße anpassen: {settings.textSize}%</strong>
                  </div>
                  <div className="accessibility-slider-control">
                    <button
                      onClick={() => adjustTextSize(-10)}
                      aria-label="Text verkleinern"
                      disabled={settings.textSize <= 100}
                    >
                      <Minus size={16} aria-hidden="true" />
                    </button>
                    <input
                      type="range"
                      min="100"
                      max="200"
                      step="10"
                      value={settings.textSize}
                      onChange={(e) => updateSetting('textSize', parseInt(e.target.value))}
                      className="accessibility-slider"
                      aria-label={`Textgröße: ${settings.textSize} Prozent`}
                    />
                    <button
                      onClick={() => adjustTextSize(10)}
                      aria-label="Text vergrößern"
                      disabled={settings.textSize >= 200}
                    >
                      <Plus size={16} aria-hidden="true" />
                    </button>
                  </div>
                  <div className="accessibility-control-desc">
                    Feine Anpassung der Textgröße von 100% bis 200% in 10%-Schritten
                  </div>
                </div>
              </div>
            </div>

            {/* Navigation & Interaction Section */}
            <div className="accessibility-section">
              <h3 className="accessibility-section-title">
                <MousePointer size={16} aria-hidden="true" />
                Navigation & Interaktion
              </h3>
              <div className="accessibility-controls">
                <label className="accessibility-control">
                  <div className="accessibility-control-label">
                    <input
                      type="checkbox"
                      checked={settings.focusEnhanced}
                      onChange={(e) => updateSetting('focusEnhanced', e.target.checked)}
                      aria-describedby="focus-desc"
                    />
                    <strong>Verstärkte Fokus-Hervorhebung</strong>
                  </div>
                  <div id="focus-desc" className="accessibility-control-desc">
                    Gelber 3px Rahmen mit Schatten um fokussierte Elemente für bessere Sichtbarkeit
                  </div>
                </label>

                <label className="accessibility-control">
                  <div className="accessibility-control-label">
                    <input
                      type="checkbox"
                      checked={settings.keyboardNavigation}
                      onChange={(e) => updateSetting('keyboardNavigation', e.target.checked)}
                      aria-describedby="keyboard-desc"
                    />
                    <strong>Erweiterte Tastatur-Navigation</strong>
                  </div>
                  <div id="keyboard-desc" className="accessibility-control-desc">
                    Optimierte Tab-Reihenfolge und Z-Index-Management für reine Tastatur-Bedienung
                  </div>
                </label>

                <label className="accessibility-control">
                  <div className="accessibility-control-label">
                    <input
                      type="checkbox"
                      checked={settings.reduceMotion}
                      onChange={(e) => updateSetting('reduceMotion', e.target.checked)}
                      aria-describedby="motion-desc"
                    />
                    <strong>Bewegungen reduzieren</strong>
                  </div>
                  <div id="motion-desc" className="accessibility-control-desc">
                    Entfernt Animationen und Bewegungseffekte für Menschen mit Vestibular-Störungen
                  </div>
                </label>
              </div>
            </div>

            {/* Screen Reader Section */}
            <div className="accessibility-section">
              <h3 className="accessibility-section-title">
                <Volume2 size={16} aria-hidden="true" />
                Screen Reader Support
              </h3>
              <div className="accessibility-controls">
                <label className="accessibility-control">
                  <div className="accessibility-control-label">
                    <input
                      type="checkbox"
                      checked={settings.screenReaderMode}
                      onChange={(e) => updateSetting('screenReaderMode', e.target.checked)}
                      aria-describedby="screen-reader-desc"
                    />
                    <strong>Screen Reader Optimierung</strong>
                  </div>
                  <div id="screen-reader-desc" className="accessibility-control-desc">
                    Optimiert für NVDA, JAWS und VoiceOver - entfernt störende visuelle Effekte
                  </div>
                </label>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="accessibility-menu-footer">
            <button
              className="accessibility-reset-btn"
              onClick={resetSettings}
              aria-label="Alle Einstellungen auf Standard zurücksetzen"
            >
              <RotateCcw size={16} aria-hidden="true" />
              Zurücksetzen
            </button>
            <div className="accessibility-help-text">
              WCAG 2.1 AA konform • Nexuno Barrierefreiheit
            </div>
          </div>
        </div>
      )}
    </>
  );
}

export default AccessibilityMenu;