import { useState } from 'react';
import { Mail, MapPin, Phone, Send, Instagram, Youtube } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { BackButton } from '../BackButton';

interface ContactPageProps {
  onBack?: () => void;
}

export function ContactPage({ onBack }: ContactPageProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log('Form submitted:', formData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div className="min-h-screen" style={{ background: 'var(--bg-secondary)' }}>
      {/* Hero Section */}
      <section className="gradient-footer py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Back Button */}
          <div className="mb-8">
            <BackButton onBack={onBack} />
          </div>
          
          {/* Header */}
          <div className="text-center">
            <h1 className="mb-4 text-5xl font-bold text-white font-['Poppins']">
              <span className="bg-gradient-to-r from-[var(--accent-cyan)] to-[var(--accent-magenta)] bg-clip-text text-[rgba(182,241,171,0.47)] text-[48px]">
                Kontakt
              </span>
            </h1>
            <p className="text-xl text-slate-300 max-w-2xl mx-auto font-['Inter']">
              Hast du Fragen, Feedback oder möchtest mit uns zusammenarbeiten? 
              Wir freuen uns auf deine Nachricht!
            </p>
          </div>
        </div>
      </section>

      {/* Content Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Contact Form */}
            <div className="lg:col-span-2">
              <div className="content-box">
                <h2 className="text-3xl font-bold mb-6 font-['Poppins']" style={{ color: 'var(--text-headline)' }}>
                  Schreib uns eine Nachricht
                </h2>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name" style={{ color: '#0F172A' }}>Name *</Label>
                    <Input
                      id="name"
                      name="name"
                      type="text"
                      required
                      value={formData.name}
                      onChange={handleChange}
                      className="mt-1"
                      style={{ 
                        backgroundColor: '#FFFFFF',
                        borderColor: '#E2E8F0',
                        color: '#0F172A'
                      }}
                    />
                  </div>
                  <div>
                    <Label htmlFor="email" style={{ color: '#0F172A' }}>E-Mail *</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      required
                      value={formData.email}
                      onChange={handleChange}
                      className="mt-1"
                      style={{ 
                        backgroundColor: '#FFFFFF',
                        borderColor: '#E2E8F0',
                        color: '#0F172A'
                      }}
                    />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="subject" style={{ color: '#0F172A' }}>Betreff</Label>
                  <Input
                    id="subject"
                    name="subject"
                    type="text"
                    value={formData.subject}
                    onChange={handleChange}
                    className="mt-1"
                    style={{ 
                      backgroundColor: '#FFFFFF',
                      borderColor: '#E2E8F0',
                      color: '#0F172A'
                    }}
                  />
                </div>
                
                <div>
                  <Label htmlFor="message" style={{ color: '#0F172A' }}>Nachricht *</Label>
                  <Textarea
                    id="message"
                    name="message"
                    required
                    rows={6}
                    value={formData.message}
                    onChange={handleChange}
                    className="mt-1"
                    placeholder="Teile uns deine Gedanken mit..."
                    style={{ 
                      backgroundColor: '#FFFFFF',
                      borderColor: '#E2E8F0',
                      color: '#0F172A'
                    }}
                  />
                </div>
                
                <Button
                  type="submit"
                  size="lg"
                  className="w-full btn-primary"
                >
                  <Send className="mr-2 h-5 w-5" />
                  Nachricht senden
                </Button>
              </form>
            </div>
          </div>

            {/* Contact Info */}
            <div className="space-y-8">
              {/* Company Info */}
              <div className="content-box">
                <h3 className="text-xl font-semibold mb-4 font-['Poppins']" style={{ color: 'var(--text-headline)' }}>
                  Kontaktdaten
                </h3>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <MapPin className="h-5 w-5 mt-0.5" style={{ color: 'var(--accent-cyan)' }} />
                  <div>
                    <p style={{ fontWeight: '500', color: '#0F172A' }}>Adresse</p>
                    <p style={{ color: '#0F172A' }}>
                      Fließstraße 6<br />
                      12439 Berlin<br />
                      Deutschland
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <Mail className="h-5 w-5" style={{ color: 'var(--accent-pink)' }} />
                  <div>
                    <p style={{ fontWeight: '500', color: '#0F172A' }}>E-Mail</p>
                    <a 
                      href="mailto:info@nexuno.eu" 
                      style={{ 
                        color: 'var(--accent-cyan)',
                        textDecoration: 'none'
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.color = 'var(--accent-pink)';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.color = 'var(--accent-cyan)';
                      }}
                    >
                      info@nexuno.eu
                    </a>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <Phone className="h-5 w-5" style={{ color: 'var(--accent-violet)' }} />
                  <div>
                    <p style={{ fontWeight: '500', color: '#0F172A' }}>Telefon</p>
                    <a 
                      href="tel:+493012345678" 
                      style={{ 
                        color: 'var(--accent-cyan)',
                        textDecoration: 'none'
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.color = 'var(--accent-pink)';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.color = 'var(--accent-cyan)';
                      }}
                    >
                      +49 30 12345678
                    </a>
                  </div>
                </div>
              </div>
            </div>

            {/* Business Hours */}
            <div className="content-box">
              <h3 style={{ 
                fontSize: '1.25rem',
                lineHeight: '1.75rem',
                fontWeight: '600',
                color: '#0F172A',
                fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
                marginBottom: '1rem'
              }}>
                Öffnungszeiten
              </h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span style={{ color: '#0F172A' }}>Montag - Freitag</span>
                  <span style={{ color: '#0F172A', opacity: '0.8' }}>9:00 - 18:00</span>
                </div>
                <div className="flex justify-between">
                  <span style={{ color: '#0F172A' }}>Samstag</span>
                  <span style={{ color: '#0F172A', opacity: '0.8' }}>10:00 - 16:00</span>
                </div>
                <div className="flex justify-between">
                  <span style={{ color: '#0F172A' }}>Sonntag</span>
                  <span style={{ color: '#0F172A', opacity: '0.8' }}>Geschlossen</span>
                </div>
              </div>
            </div>

            {/* Social Media */}
            <div className="content-box">
              <h3 style={{ 
                fontSize: '1.25rem',
                lineHeight: '1.75rem',
                fontWeight: '600',
                color: '#0F172A',
                fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
                marginBottom: '1rem'
              }}>
                Folge uns
              </h3>
              <div className="grid grid-cols-2 gap-3">
                <a 
                  href="#" 
                  className="flex items-center gap-2 p-3 rounded-lg transition-all duration-300"
                  style={{ 
                    border: '1px solid #E2E8F0',
                    backgroundColor: '#FFFFFF',
                    textDecoration: 'none'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.borderColor = 'var(--accent-cyan)';
                    e.currentTarget.style.backgroundColor = '#F8FAFC';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.borderColor = '#E2E8F0';
                    e.currentTarget.style.backgroundColor = '#FFFFFF';
                  }}
                >
                  <Instagram className="h-5 w-5" style={{ color: 'var(--accent-cyan)' }} />
                  <span style={{ 
                    fontSize: '0.875rem', 
                    fontWeight: '500',
                    color: '#0F172A'
                  }}>
                    Instagram
                  </span>
                </a>
                <a 
                  href="#" 
                  className="flex items-center gap-2 p-3 rounded-lg transition-all duration-300"
                  style={{ 
                    border: '1px solid #E2E8F0',
                    backgroundColor: '#FFFFFF',
                    textDecoration: 'none'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.borderColor = 'var(--accent-pink)';
                    e.currentTarget.style.backgroundColor = '#F8FAFC';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.borderColor = '#E2E8F0';
                    e.currentTarget.style.backgroundColor = '#FFFFFF';
                  }}
                >
                  <Youtube className="h-5 w-5" style={{ color: 'var(--accent-pink)' }} />
                  <span style={{ 
                    fontSize: '0.875rem', 
                    fontWeight: '500',
                    color: '#0F172A'
                  }}>
                    YouTube
                  </span>
                </a>
              </div>
            </div>
          </div>
        </div>

        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 gradient-section">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold font-['Poppins']" style={{ color: 'var(--text-headline)' }}>
              Häufig gestellte Fragen
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[
              {
                question: 'Wie lange dauert der Versand?',
                answer: 'Standard-Versand dauert 2-3 Werktage innerhalb Deutschlands. Express-Versand ist in 1-2 Werktagen möglich.'
              },
              {
                question: 'Kann ich Artikel zurückgeben?',
                answer: 'Ja, du hast 14 Tage Zeit, um Artikel in originalem Zustand zurückzusenden. Der Rückversand ist kostenlos.'
              },
              {
                question: 'Gibt es Größenberatung?',
                answer: 'Unsere Größentabelle findest du bei jedem Artikel. Bei Fragen zur Passform kontaktiere uns gerne.'
              },
              {
                question: 'Sind die Materialien nachhaltig?',
                answer: 'Ja, wir verwenden ausschließlich nachhaltige und umweltfreundliche Materialien für unsere Produkte.'
              }
            ].map((faq, index) => (
              <div key={index} className="content-box">
                <h3 className="text-lg font-semibold mb-3 font-['Poppins']" style={{ color: 'var(--text-headline)' }}>
                  {faq.question}
                </h3>
                <p className="font-['Inter']" style={{ color: 'var(--text-body)', lineHeight: '1.7' }}>
                  {faq.answer}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}