import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Truck, Shield, Headphones, Award, Package, Palette, Zap } from 'lucide-react';
import { AccessibilityEnhancement } from './AccessibilityEnhancement';
import { AccessibleFashionHeader } from './AccessibleFashionHeader';
import { AccessibleHeroSection } from './AccessibleHeroSection';
import { AccessibleProductGrid } from './AccessibleProductGrid';
import { SearchOverlay } from './SearchOverlay';
import { useCart } from './cart/CartContext';
import { EnhancedCartSidebar } from './cart/EnhancedCartSidebar';
import ErrorBoundary from './ErrorBoundary';

interface AccessibleFashionStorePageProps {
  onNavigate?: (page: string) => void;
}

export function AccessibleFashionStorePage({ onNavigate }: AccessibleFashionStorePageProps = {}) {
  const [currentPage, setCurrentPage] = useState<string>('shop');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [showSearch, setShowSearch] = useState(false);
  const [currentTab, setCurrentTab] = useState<'collection' | 'printful'>('collection');
  const [announceMessage, setAnnounceMessage] = useState('');
  
  const { state: cartState, toggleCart } = useCart();

  // Screen reader announcements
  const announceToScreenReader = (message: string) => {
    setAnnounceMessage(message);
    setTimeout(() => setAnnounceMessage(''), 1000);
  };

  // Navigation handlers with accessibility
  const handleNavigation = (page: string) => {
    if (page === 'search') {
      setShowSearch(!showSearch);
      announceToScreenReader(showSearch ? 'Suche geschlossen' : 'Suche geöffnet');
      return;
    }
    if (page === 'cart') {
      onNavigate?.('cart');
      announceToScreenReader('Navigation zum Warenkorb');
      return;
    }
    
    setCurrentPage(page);
    setSelectedCategory(null);
    announceToScreenReader(`Navigation zu ${page}`);
  };

  const handleCategoryClick = (category: string) => {
    setSelectedCategory(category);
    announceToScreenReader(`Kategorie ${category} ausgewählt`);
    
    // Scroll to products section
    const productsSection = document.getElementById('products-section');
    if (productsSection) {
      productsSection.scrollIntoView({ behavior: 'smooth' });
      // Focus products section for screen reader users
      productsSection.focus();
    }
  };

  const handleTabSwitch = (tab: 'collection' | 'printful') => {
    setCurrentTab(tab);
    const tabName = tab === 'collection' ? 'Ready-to-Wear Collection' : 'Design Your Own';
    announceToScreenReader(`Tab gewechselt zu ${tabName}`);
  };

  // USPs with enhanced accessibility
  const usps = [
    { 
      icon: <Truck className="h-8 w-8" aria-hidden="true" />, 
      title: 'Kostenloser Versand', 
      description: 'Bei Bestellungen über € 69', 
      color: 'text-green-400',
      longDescription: 'Kostenloser Versand für alle Bestellungen über 69 Euro innerhalb Deutschlands. Express-Versand verfügbar.'
    },
    { 
      icon: <Shield className="h-8 w-8" aria-hidden="true" />, 
      title: '14 Tage Rückgaberecht', 
      description: 'Einfache Rücksendung', 
      color: 'text-blue-400',
      longDescription: '14 Tage kostenloses Rückgaberecht. Einfacher Rückversand mit vorfrankiertem Etikett.'
    },
    { 
      icon: <Headphones className="h-8 w-8" aria-hidden="true" />, 
      title: '24/7 Support', 
      description: 'Immer für dich da', 
      color: 'text-purple-400',
      longDescription: 'Rund um die Uhr Kundenservice per Chat, E-Mail oder Telefon. Experten helfen bei allen Fragen.'
    },
    { 
      icon: <Award className="h-8 w-8" aria-hidden="true" />, 
      title: 'Premium Qualität', 
      description: 'Nur das Beste für dich', 
      color: 'text-orange-400',
      longDescription: 'Hochwertige Materialien und nachhaltige Produktion. Zertifizierte Qualität seit über 10 Jahren.'
    },
  ];

  return (
    <AccessibilityEnhancement>
      <div className="min-h-screen bg-slate-950 text-white">
        
        {/* Accessible Header */}
        <AccessibleFashionHeader
          currentPage={currentPage}
          selectedCategory={selectedCategory}
          cartCount={cartState.itemCount}
          onNavigationClick={handleNavigation}
          onCategoryClick={handleCategoryClick}
          onSearchClick={() => setShowSearch(true)}
          onCartClick={toggleCart}
          onContactPageNavigate={() => setCurrentPage('contact')}
        />

        {/* Search Overlay */}
        <SearchOverlay 
          isOpen={showSearch} 
          onClose={() => {
            setShowSearch(false);
            announceToScreenReader('Suche geschlossen');
          }} 
          onProductSelect={(productId) => {
            announceToScreenReader(`Produkt ${productId} ausgewählt`);
          }} 
        />

        {/* Hero Section */}
        <AccessibleHeroSection
          onExploreClick={() => {
            const productsSection = document.getElementById('products-section');
            if (productsSection) {
              productsSection.scrollIntoView({ behavior: 'smooth' });
              productsSection.focus();
            }
          }}
          onShopNowClick={() => handleNavigation('shop')}
        />

        {/* USPs Section */}
        <section 
          className="relative z-10 py-20 bg-gradient-to-br from-slate-800 via-slate-700 to-blue-800 text-white overflow-hidden"
          aria-labelledby="usps-heading"
        >
          <div className="absolute inset-0 opacity-10 pointer-events-none">
            <div className="tech-grid-minimal" aria-hidden="true"></div>
          </div>
          
          <div className="max-w-7xl mx-auto px-6 relative z-10">
            <div className="text-center mb-14">
              <h2 id="usps-heading" className="text-3xl md:text-4xl font-bold mb-4 text-white glow-text-tech">
                Ihre Zukunft trägt Intelligence
              </h2>
              <p className="text-lg text-slate-300 max-w-2xl mx-auto leading-relaxed">
                Erleben Sie Mode, die mit Ihnen denkt, sich anpasst und Ihre Persönlichkeit 
                in jedem Stoff zum Leben erweckt. Willkommen in der Neural Fashion Era.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {usps.map((usp, index) => (
                <motion.div
                  key={index}
                  className="text-center group focus-within:ring-2 focus-within:ring-yellow-400 focus-within:ring-offset-2 focus-within:ring-offset-slate-800 rounded-lg p-4"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  viewport={{ once: true }}
                  tabIndex={0}
                  role="article"
                  aria-labelledby={`usp-title-${index}`}
                  aria-describedby={`usp-desc-${index}`}
                >
                  <div className={`inline-flex items-center justify-center w-14 h-14 rounded-xl bg-slate-800 group-hover:bg-slate-700 group-focus:bg-slate-700 transition-all duration-200 mb-5 ${usp.color}`}>
                    {usp.icon}
                  </div>
                  <h3 id={`usp-title-${index}`} className="text-lg font-semibold mb-2">
                    {usp.title}
                  </h3>
                  <p id={`usp-desc-${index}`} className="text-slate-300 text-sm">
                    {usp.description}
                  </p>
                  <p className="sr-only">{usp.longDescription}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Products Section */}
        <section 
          id="products-section" 
          className="relative z-10 py-20 bg-gradient-to-br from-slate-700 via-slate-800 to-blue-900 text-white overflow-hidden focus:outline-none" 
          tabIndex={-1}
          aria-labelledby="products-heading"
        >
          <div className="absolute inset-0 opacity-10 pointer-events-none">
            <div className="tech-grid-minimal" aria-hidden="true"></div>
          </div>
          
          <div className="max-w-7xl mx-auto px-6 relative z-10">
            
            {/* Section Header with Tab Navigation */}
            <div className="text-center mb-12">
              <h2 id="products-heading" className="text-3xl md:text-4xl font-bold mb-6 text-white glow-text-tech">
                Nexuno Fashion Store
              </h2>
              
              {/* Tab Navigation */}
              <div className="flex justify-center mb-8" role="tablist" aria-label="Produktkategorien">
                <div className="bg-slate-800/50 rounded-xl p-2 backdrop-blur-lg border border-slate-600">
                  <button
                    onClick={() => handleTabSwitch('collection')}
                    className={`px-6 py-3 rounded-lg transition-all duration-300 font-medium focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:ring-offset-2 focus:ring-offset-slate-800 ${
                      currentTab === 'collection'
                        ? 'bg-gradient-to-r from-cyan-500 to-cyan-600 text-white shadow-lg'
                        : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
                    }`}
                    role="tab"
                    aria-selected={currentTab === 'collection'}
                    aria-controls="collection-panel"
                    id="collection-tab"
                  >
                    <div className="flex items-center gap-2">
                      <Package className="w-5 h-5" aria-hidden="true" />
                      <span>Ready-to-Wear Collection</span>
                    </div>
                  </button>
                  
                  <button
                    onClick={() => handleTabSwitch('printful')}
                    className={`px-6 py-3 rounded-lg transition-all duration-300 font-medium focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:ring-offset-2 focus:ring-offset-slate-800 ${
                      currentTab === 'printful'
                        ? 'bg-gradient-to-r from-cyan-500 to-cyan-600 text-white shadow-lg'
                        : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
                    }`}
                    role="tab"
                    aria-selected={currentTab === 'printful'}
                    aria-controls="printful-panel"
                    id="printful-tab"
                  >
                    <div className="flex items-center gap-2">
                      <Palette className="w-5 h-5" aria-hidden="true" />
                      <span>Design Your Own</span>
                    </div>
                  </button>
                </div>
              </div>
            </div>

            {/* Collection Tab Panel */}
            {currentTab === 'collection' && (
              <div 
                id="collection-panel"
                role="tabpanel"
                aria-labelledby="collection-tab"
                tabIndex={0}
              >
                <ErrorBoundary 
                  onError={(error) => {
                    announceToScreenReader('Fehler beim Laden der Produkte');
                    console.error('ProductGrid error:', error);
                  }}
                  fallback={
                    <div className="text-center py-12" role="alert">
                      <div className="bg-slate-800/50 rounded-lg p-8 max-w-md mx-auto">
                        <h3 className="text-xl font-semibold mb-4">Produkte werden geladen...</h3>
                        <p className="text-slate-300 mb-4">
                          Die Produktdaten werden von unserem lokalen Katalog abgerufen.
                        </p>
                        <div className="animate-pulse bg-slate-700 h-8 rounded-lg mx-auto w-32" aria-hidden="true"></div>
                      </div>
                    </div>
                  }
                >
                  <AccessibleProductGrid selectedCategory={selectedCategory} />
                </ErrorBoundary>
              </div>
            )}

            {/* Printful Tab Panel */}
            {currentTab === 'printful' && (
              <div 
                id="printful-panel"
                role="tabpanel"
                aria-labelledby="printful-tab"
                tabIndex={0}
              >
                <div className="space-y-8">
                  {/* Print-on-Demand Hero */}
                  <div className="text-center mb-12">
                    <div className="bg-gradient-to-r from-slate-800/80 to-slate-700/80 rounded-2xl p-8 backdrop-blur-sm border border-slate-600">
                      <div className="flex justify-center mb-6" aria-hidden="true">
                        <div className="flex items-center gap-4">
                          <div className="bg-cyan-500/20 p-4 rounded-xl">
                            <Package className="w-8 h-8 text-cyan-400" />
                          </div>
                          <div className="bg-cyan-500/20 p-4 rounded-xl">
                            <Palette className="w-8 h-8 text-cyan-400" />
                          </div>
                          <div className="bg-cyan-500/20 p-4 rounded-xl">
                            <Zap className="w-8 h-8 text-cyan-400" />
                          </div>
                        </div>
                      </div>
                      
                      <h3 className="text-2xl font-bold mb-4 text-white">
                        Design Your Perfect Style
                      </h3>
                      <p className="text-slate-300 max-w-2xl mx-auto leading-relaxed">
                        Erstellen Sie einzigartige Designs auf Premium-Produkten. Von T-Shirts bis Hoodies - 
                        Ihre Kreativität wird Realität durch unsere Print-on-Demand Technologie.
                      </p>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
                        {[
                          {
                            icon: <Palette className="w-6 h-6 text-cyan-400 mx-auto" aria-hidden="true" />,
                            title: 'Design Upload',
                            description: 'Laden Sie Ihr Design hoch oder erstellen Sie Text-Designs'
                          },
                          {
                            icon: <Package className="w-6 h-6 text-cyan-400 mx-auto" aria-hidden="true" />,
                            title: 'Premium Products',
                            description: 'Hochwertige Materialien von Printful'
                          },
                          {
                            icon: <Truck className="w-6 h-6 text-cyan-400 mx-auto" aria-hidden="true" />,
                            title: 'Global Fulfillment',
                            description: 'Weltweiter Versand direkt zu Ihnen'
                          }
                        ].map((feature, index) => (
                          <div key={index} className="text-center" tabIndex={0}>
                            <div className="bg-slate-700/50 rounded-lg p-4 mb-3">
                              {feature.icon}
                            </div>
                            <h4 className="font-semibold text-white mb-2">{feature.title}</h4>
                            <p className="text-sm text-slate-400">{feature.description}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Placeholder for Printful Integration */}
                  <div className="text-center py-12">
                    <div className="bg-slate-800/50 rounded-lg p-8 max-w-md mx-auto">
                      <h3 className="text-xl font-semibold mb-4">Print-on-Demand Coming Soon</h3>
                      <p className="text-slate-300 mb-4">
                        Printful-Integration wird in Kürze verfügbar sein.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </section>

        {/* Footer */}
        <footer 
          className="bg-slate-900 text-white py-16 relative z-10"
          role="contentinfo"
          aria-labelledby="footer-heading"
        >
          <div className="max-w-7xl mx-auto px-6">
            <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center">
              <p className="text-gray-400 text-sm mb-4 md:mb-0">
                © 2025 Nexuno Fashion. Alle Rechte vorbehalten.
              </p>
              
              <nav aria-label="Footer Links">
                <div className="flex flex-wrap gap-4 justify-center md:justify-end">
                  {[
                    { text: 'Impressum', action: () => setCurrentPage('impressum') },
                    { text: 'Datenschutz', action: () => setCurrentPage('datenschutz') },
                    { text: 'AGB', action: () => setCurrentPage('agb') },
                    { text: 'Widerrufsrecht', action: () => setCurrentPage('widerruf') },
                    { text: 'Kontakt', action: () => setCurrentPage('contact') }
                  ].map((link, index) => (
                    <button
                      key={index}
                      onClick={link.action}
                      className="text-gray-400 hover:text-white text-sm transition-colors cursor-pointer focus:outline-none focus:underline focus:text-white"
                    >
                      {link.text}
                    </button>
                  ))}
                </div>
              </nav>
            </div>
          </div>
        </footer>

        {/* Enhanced Cart Sidebar */}
        <EnhancedCartSidebar
          onCheckout={() => onNavigate?.('checkout')}
          onContinueShopping={() => {
            const productsSection = document.getElementById('products-section');
            if (productsSection) {
              productsSection.scrollIntoView({ behavior: 'smooth' });
            }
          }}
        />

        {/* Screen Reader Live Region */}
        <div
          role="status"
          aria-live="polite"
          aria-atomic="true"
          className="sr-only"
        >
          {announceMessage}
        </div>
      </div>
    </AccessibilityEnhancement>
  );
}