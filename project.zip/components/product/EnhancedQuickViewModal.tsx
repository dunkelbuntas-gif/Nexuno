import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Plus, Minus, Heart, Share2, Star, ChevronLeft, ChevronRight } from 'lucide-react';
import { useCart } from '../cart/CartContext';
import { useWishlist } from '../wishlist/WishlistContext';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { NEXUNO_PRODUCTS } from '../../lib/local-products';

interface Product {
  id: string | number;
  name: string;
  description: string;
  thumbnail_url?: string;
  image?: string;
  price: string | number;
  images?: string[];
  variants?: any[];
  options?: {
    sizes: string[];
    colors: string[];
  };
  sizes?: string[];
  colors?: string[];
  rating?: number;
  reviews?: number;
  badge?: string;
  badgeColor?: string;
  originalPrice?: string;
  category?: string;
}

// Legacy products for backward compatibility
const products = NEXUNO_PRODUCTS.map(p => ({
  id: p.id,
  name: p.name,
  description: p.description,
  thumbnail_url: p.image,
  price: `€${p.price}`,
  images: p.images,
  options: {
    sizes: p.sizes,
    colors: p.colors
  },
  rating: 4.5,
  reviews: 42,
  category: p.categoryName
}));

interface EnhancedQuickViewModalProps {
  productId?: string | null;
  product?: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onNavigate?: (page: string) => void;
  onBack?: () => void;
  id?: number | null;
}

export function EnhancedQuickViewModal({ 
  productId, 
  product: propProduct, 
  isOpen, 
  onClose,
  onNavigate,
  onBack,
  id 
}: EnhancedQuickViewModalProps) {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [selectedColor, setSelectedColor] = useState<string>('');
  const [quantity, setQuantity] = useState(1);
  const [isLoading, setIsLoading] = useState(false);

  const { addItem } = useCart();
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();

  // Find product from local products or use prop product
  const product = propProduct || (productId ? products.find(p => p.id === parseInt(productId)) : null) || (id ? products.find(p => p.id === id) : null);

  const isWishlisted = product ? isInWishlist(product.id) : false;

  useEffect(() => {
    if (isOpen && product) {
      // Reset state when opening
      setCurrentImageIndex(0);
      setSelectedSize('');
      setSelectedColor('');
      setQuantity(1);
    }
  }, [isOpen, product]);

  useEffect(() => {
    // Handle escape key
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener('keydown', handleEscape);
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }

    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = '';
    };
  }, [isOpen, onClose]);

  if (!product) {
    return null;
  }

  const productImages = product.images && product.images.length > 0 ? product.images : [product.thumbnail_url];
  const availableSizes = product.options?.sizes || ['XS', 'S', 'M', 'L', 'XL'];
  const availableColors = product.options?.colors || ['Schwarz', 'Weiß', 'Grau'];

  const handlePrevImage = () => {
    setCurrentImageIndex((prev) => (prev === 0 ? productImages.length - 1 : prev - 1));
  };

  const handleNextImage = () => {
    setCurrentImageIndex((prev) => (prev === productImages.length - 1 ? 0 : prev + 1));
  };

  const handleAddToCart = () => {
    if (!selectedSize) {
      alert('Bitte wählen Sie eine Größe');
      return;
    }

    setIsLoading(true);
    
    setTimeout(() => {
      addItem({
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.thumbnail_url,
        quantity: quantity,
        size: selectedSize,
        color: selectedColor || availableColors[0]
      });
      setIsLoading(false);
      onClose();
    }, 500);
  };

  const handleWishlistToggle = () => {
    if (isWishlisted) {
      removeFromWishlist(product.id);
    } else {
      addToWishlist({
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.thumbnail_url,
        category: product.category || 'Fashion'
      });
    }
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: product.name,
        text: product.description,
        url: window.location.href
      });
    } else {
      // Fallback - copy to clipboard
      navigator.clipboard.writeText(window.location.href);
      alert('Link wurde in die Zwischenablage kopiert!');
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="quick-view-backdrop fixed inset-0"
            onClick={onClose}
          />

          {/* Modal */}
          <div className="fixed inset-0 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              transition={{ 
                type: "spring", 
                damping: 30, 
                stiffness: 300,
                duration: 0.3 
              }}
              className="quick-view-modal w-full max-w-4xl max-h-[90vh] overflow-hidden rounded-2xl relative"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Close Button */}
              <button
                onClick={onClose}
                className="absolute top-4 right-4 z-10 w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white transition-colors shadow-lg"
                aria-label="Schließen"
              >
                <X className="w-5 h-5 text-gray-600" />
              </button>

              <div className="flex flex-col lg:flex-row bg-white/95 backdrop-blur-sm h-full">
                {/* Image Gallery */}
                <div className="lg:w-1/2 relative bg-gray-50">
                  <div className="relative aspect-square lg:h-full">
                    <img
                      src={productImages[currentImageIndex]}
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                    
                    {/* Image Navigation */}
                    {productImages.length > 1 && (
                      <>
                        <button
                          onClick={handlePrevImage}
                          className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white transition-colors shadow-lg"
                          aria-label="Vorheriges Bild"
                        >
                          <ChevronLeft className="w-5 h-5 text-gray-600" />
                        </button>
                        <button
                          onClick={handleNextImage}
                          className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white transition-colors shadow-lg"
                          aria-label="Nächstes Bild"
                        >
                          <ChevronRight className="w-5 h-5 text-gray-600" />
                        </button>

                        {/* Image Dots */}
                        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                          {productImages.map((_, index) => (
                            <button
                              key={index}
                              onClick={() => setCurrentImageIndex(index)}
                              className={`w-2 h-2 rounded-full transition-colors ${
                                index === currentImageIndex ? 'bg-white' : 'bg-white/50'
                              }`}
                              aria-label={`Bild ${index + 1} anzeigen`}
                            />
                          ))}
                        </div>
                      </>
                    )}
                  </div>
                </div>

                {/* Product Details */}
                <div className="lg:w-1/2 p-6 lg:p-8 overflow-y-auto custom-scrollbar">
                  <div className="space-y-6">
                    {/* Header */}
                    <div>
                      <div className="flex items-start justify-between mb-2">
                        <h1 className="text-2xl lg:text-3xl font-bold text-gray-900">
                          {product.name}
                        </h1>
                        <div className="flex gap-2">
                          <button
                            onClick={handleWishlistToggle}
                            className={`p-2 rounded-full transition-colors ${
                              isWishlisted 
                                ? 'bg-red-100 text-red-600' 
                                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                            }`}
                            aria-label={isWishlisted ? 'Von Wunschliste entfernen' : 'Zur Wunschliste hinzufügen'}
                          >
                            <Heart className={`w-5 h-5 ${isWishlisted ? 'fill-current' : ''}`} />
                          </button>
                          <button
                            onClick={handleShare}
                            className="p-2 rounded-full bg-gray-100 text-gray-600 hover:bg-gray-200 transition-colors"
                            aria-label="Teilen"
                          >
                            <Share2 className="w-5 h-5" />
                          </button>
                        </div>
                      </div>

                      <div className="flex items-center gap-4 mb-4">
                        <span className="text-3xl font-bold text-gray-900">{product.price}</span>
                        {product.originalPrice && (
                          <span className="text-lg text-gray-500 line-through">{product.originalPrice}</span>
                        )}
                        {product.badge && (
                          <Badge variant="secondary" className={product.badgeColor || 'bg-cyan-500'}>
                            {product.badge}
                          </Badge>
                        )}
                      </div>

                      {/* Rating */}
                      {product.rating && (
                        <div className="flex items-center gap-2 mb-4">
                          <div className="flex items-center">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                className={`w-4 h-4 ${
                                  i < Math.floor(product.rating)
                                    ? 'text-yellow-400 fill-current'
                                    : 'text-gray-300'
                                }`}
                              />
                            ))}
                          </div>
                          <span className="text-sm text-gray-600">
                            {product.rating} ({product.reviews || 0} Bewertungen)
                          </span>
                        </div>
                      )}

                      <p className="text-gray-600 leading-relaxed">
                        {product.description}
                      </p>
                    </div>

                    {/* Size Selection */}
                    <div>
                      <h3 className="text-lg font-semibold mb-3">Größe</h3>
                      <div className="grid grid-cols-5 gap-2">
                        {availableSizes.map((size) => (
                          <button
                            key={size}
                            onClick={() => setSelectedSize(size)}
                            className={`py-2 px-3 border rounded-lg font-medium transition-all ${
                              selectedSize === size
                                ? 'size-btn-selected'
                                : 'size-btn-default'
                            }`}
                          >
                            {size}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Color Selection */}
                    <div>
                      <h3 className="text-lg font-semibold mb-3">Farbe</h3>
                      <div className="flex gap-3">
                        {availableColors.map((color) => (
                          <button
                            key={color}
                            onClick={() => setSelectedColor(color)}
                            className={`color-swatch ${
                              selectedColor === color ? 'color-swatch-selected' : ''
                            }`}
                            style={{ 
                              backgroundColor: color === 'Schwarz' ? '#000' : 
                                             color === 'Weiß' ? '#fff' : 
                                             color === 'Grau' ? '#6b7280' : color 
                            }}
                            aria-label={`Farbe ${color}`}
                          />
                        ))}
                      </div>
                      {selectedColor && (
                        <p className="text-sm text-gray-600 mt-2">Ausgewählt: {selectedColor}</p>
                      )}
                    </div>

                    {/* Quantity */}
                    <div>
                      <h3 className="text-lg font-semibold mb-3">Anzahl</h3>
                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => setQuantity(Math.max(1, quantity - 1))}
                          className="w-10 h-10 border rounded-lg flex items-center justify-center hover:bg-gray-50 transition-colors"
                          disabled={quantity <= 1}
                        >
                          <Minus className="w-4 h-4" />
                        </button>
                        <span className="text-lg font-medium w-12 text-center">{quantity}</span>
                        <button
                          onClick={() => setQuantity(quantity + 1)}
                          className="w-10 h-10 border rounded-lg flex items-center justify-center hover:bg-gray-50 transition-colors"
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Add to Cart Button */}
                    <Button
                      onClick={handleAddToCart}
                      disabled={!selectedSize || isLoading}
                      className="w-full h-12 text-lg font-semibold bg-gradient-to-r from-cyan-500 to-cyan-600 hover:from-cyan-600 hover:to-cyan-700 text-white disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {isLoading ? 'Wird hinzugefügt...' : 'In den Warenkorb'}
                    </Button>

                    {!selectedSize && (
                      <p className="text-sm text-gray-500 text-center">
                        Bitte wählen Sie eine Größe aus
                      </p>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      )}
    </AnimatePresence>
  );
}