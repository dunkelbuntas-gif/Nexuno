import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Settings, 
  Eye, 
  EyeOff, 
  Volume2, 
  VolumeX, 
  MousePointer, 
  Keyboard,
  Type,
  Contrast,
  Palette,
  Minus,
  Plus,
  RotateCcw,
  Accessibility,
  X
} from 'lucide-react';

interface AccessibilitySettings {
  reducedMotion: boolean;
  highContrast: boolean;
  largeText: boolean;
  focusVisible: boolean;
  screenReaderMode: boolean;
  soundEnabled: boolean;
  fontSize: number; // 100% = normal, 150% = large, 200% = extra large
  colorBlindFriendly: boolean;
  keyboardNavigation: boolean;
}

interface AccessibilityEnhancementProps {
  children: React.ReactNode;
}

export function AccessibilityEnhancement({ children }: AccessibilityEnhancementProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [settings, setSettings] = useState<AccessibilitySettings>({
    reducedMotion: false,
    highContrast: false,
    largeText: false,
    focusVisible: true,
    screenReaderMode: false,
    soundEnabled: true,
    fontSize: 100,
    colorBlindFriendly: false,
    keyboardNavigation: false,
  });

  const menuRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);

  // Load settings from localStorage
  useEffect(() => {
    const savedSettings = localStorage.getItem('accessibility-settings');
    if (savedSettings) {
      try {
        const parsed = JSON.parse(savedSettings);
        setSettings(prev => ({ ...prev, ...parsed }));
      } catch (error) {
        console.warn('Could not parse accessibility settings:', error);
      }
    }

    // Check for system preferences
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      setSettings(prev => ({ ...prev, reducedMotion: true }));
    }

    if (window.matchMedia('(prefers-contrast: high)').matches) {
      setSettings(prev => ({ ...prev, highContrast: true }));
    }
  }, []);

  // Save settings to localStorage and apply CSS changes
  useEffect(() => {
    localStorage.setItem('accessibility-settings', JSON.stringify(settings));
    
    const root = document.documentElement;
    
    // Apply reduced motion
    if (settings.reducedMotion) {
      root.style.setProperty('--animation-duration', '0s');
      root.style.setProperty('--transition-duration', '0s');
      root.classList.add('reduce-motion');
    } else {
      root.style.removeProperty('--animation-duration');
      root.style.removeProperty('--transition-duration');
      root.classList.remove('reduce-motion');
    }

    // Apply high contrast
    if (settings.highContrast) {
      root.classList.add('high-contrast');
    } else {
      root.classList.remove('high-contrast');
    }

    // Apply font size
    root.style.fontSize = `${settings.fontSize}%`;

    // Apply large text class
    if (settings.largeText) {
      root.classList.add('large-text');
    } else {
      root.classList.remove('large-text');
    }

    // Apply focus visible
    if (settings.focusVisible) {
      root.classList.add('focus-visible-enhanced');
    } else {
      root.classList.remove('focus-visible-enhanced');
    }

    // Apply color blind friendly
    if (settings.colorBlindFriendly) {
      root.classList.add('colorblind-friendly');
    } else {
      root.classList.remove('colorblind-friendly');
    }

    // Apply keyboard navigation
    if (settings.keyboardNavigation) {
      root.classList.add('keyboard-navigation');
    } else {
      root.classList.remove('keyboard-navigation');
    }

    // Screen reader announcements
    if (settings.screenReaderMode) {
      root.classList.add('screen-reader-mode');
    } else {
      root.classList.remove('screen-reader-mode');
    }
  }, [settings]);

  // Keyboard handling
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // ESC to close menu
      if (e.key === 'Escape' && isMenuOpen) {
        setIsMenuOpen(false);
        triggerRef.current?.focus();
      }

      // Alt + A to open accessibility menu
      if (e.altKey && e.key === 'a') {
        e.preventDefault();
        setIsMenuOpen(prev => !prev);
      }

      // Tab trapping in menu
      if (isMenuOpen && e.key === 'Tab') {
        const focusableElements = menuRef.current?.querySelectorAll(
          'button, input, select, textarea, [tabindex]:not([tabindex="-1"])'
        );
        if (focusableElements && focusableElements.length > 0) {
          const firstElement = focusableElements[0] as HTMLElement;
          const lastElement = focusableElements[focusableElements.length - 1] as HTMLElement;

          if (!e.shiftKey && document.activeElement === lastElement) {
            e.preventDefault();
            firstElement.focus();
          } else if (e.shiftKey && document.activeElement === firstElement) {
            e.preventDefault();
            lastElement.focus();
          }
        }
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isMenuOpen]);

  // Focus management
  useEffect(() => {
    if (isMenuOpen) {
      // Focus first interactive element in menu
      setTimeout(() => {
        const firstFocusable = menuRef.current?.querySelector(
          'button, input, select, textarea, [tabindex]:not([tabindex="-1"])'
        ) as HTMLElement;
        firstFocusable?.focus();
      }, 100);
    }
  }, [isMenuOpen]);

  const updateSetting = (key: keyof AccessibilitySettings, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));
    
    // Announce changes to screen readers
    if (settings.screenReaderMode || settings.focusVisible) {
      announceChange(key, value);
    }
  };

  const announceChange = (setting: string, value: any) => {
    const announcement = document.createElement('div');
    announcement.setAttribute('aria-live', 'polite');
    announcement.setAttribute('aria-atomic', 'true');
    announcement.className = 'sr-only';
    
    const settingNames: Record<string, string> = {
      reducedMotion: 'Reduzierte Bewegungen',
      highContrast: 'Hoher Kontrast',
      largeText: 'Große Schrift',
      fontSize: 'Schriftgröße',
      screenReaderMode: 'Screenreader-Modus',
      soundEnabled: 'Ton',
      colorBlindFriendly: 'Farbenblind-freundlich',
      keyboardNavigation: 'Tastaturnavigation',
      focusVisible: 'Sichtbarer Fokus'
    };

    const statusText = typeof value === 'boolean' 
      ? (value ? 'aktiviert' : 'deaktiviert')
      : `auf ${value} geändert`;
    
    announcement.textContent = `${settingNames[setting]} ${statusText}`;
    document.body.appendChild(announcement);
    
    setTimeout(() => {
      document.body.removeChild(announcement);
    }, 1000);
  };

  const resetSettings = () => {
    const defaultSettings: AccessibilitySettings = {
      reducedMotion: false,
      highContrast: false,
      largeText: false,
      focusVisible: true,
      screenReaderMode: false,
      soundEnabled: true,
      fontSize: 100,
      colorBlindFriendly: false,
      keyboardNavigation: false,
    };
    setSettings(defaultSettings);
    announceChange('reset', 'Einstellungen zurückgesetzt');
  };

  return (
    <>
      {/* Skip Links - WCAG 2.1 Requirement */}
      <div className="skip-links">
        <a 
          href="#main-content" 
          className="skip-link"
          onFocus={(e) => e.target.classList.add('skip-link-visible')}
          onBlur={(e) => e.target.classList.remove('skip-link-visible')}
        >
          Zum Hauptinhalt springen
        </a>
        <a 
          href="#navigation" 
          className="skip-link"
          onFocus={(e) => e.target.classList.add('skip-link-visible')}
          onBlur={(e) => e.target.classList.remove('skip-link-visible')}
        >
          Zur Navigation springen
        </a>
        <button 
          onClick={() => setIsMenuOpen(true)}
          className="skip-link"
          onFocus={(e) => e.target.classList.add('skip-link-visible')}
          onBlur={(e) => e.target.classList.remove('skip-link-visible')}
        >
          Barrierefreiheits-Einstellungen öffnen
        </button>
      </div>

      {/* Main Content with accessibility wrapper */}
      <div id="main-content" role="main">
        {children}
      </div>

      {/* Accessibility Menu Trigger */}
      <motion.button
        ref={triggerRef}
        onClick={() => setIsMenuOpen(true)}
        className="fixed bottom-6 right-24 z-50 w-14 h-14 bg-gradient-to-r from-teal-500 to-cyan-500 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-200 flex items-center justify-center"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        aria-label="Barrierefreiheits-Einstellungen öffnen (Alt + A)"
        title="Barrierefreiheits-Einstellungen"
      >
        <Accessibility className="h-6 w-6" aria-hidden="true" />
        <span className="sr-only">Barrierefreiheit</span>
      </motion.button>

      {/* Accessibility Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              className="accessibility-backdrop"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMenuOpen(false)}
              aria-hidden="true"
            />

            {/* Menu Panel */}
            <motion.div
              ref={menuRef}
              className="accessibility-menu"
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              transition={{ duration: 0.2 }}
              role="dialog"
              aria-modal="true"
              aria-label="Barrierefreiheits-Einstellungen"
            >
              {/* Header */}
              <div className="accessibility-menu-header">
                <h2 className="accessibility-menu-title">
                  <Accessibility className="h-5 w-5" aria-hidden="true" />
                  Barrierefreiheit
                </h2>
                <button
                  onClick={() => setIsMenuOpen(false)}
                  className="accessibility-close-btn"
                  aria-label="Menü schließen"
                >
                  <X className="h-5 w-5" aria-hidden="true" />
                </button>
              </div>

              {/* Settings */}
              <div className="accessibility-menu-content">
                <div className="accessibility-section">
                  <h3 className="accessibility-section-title">
                    <Eye className="h-4 w-4" aria-hidden="true" />
                    Visuell
                  </h3>
                  
                  <div className="accessibility-controls">
                    {/* High Contrast */}
                    <label className="accessibility-control">
                      <input
                        type="checkbox"
                        checked={settings.highContrast}
                        onChange={(e) => updateSetting('highContrast', e.target.checked)}
                        aria-describedby="high-contrast-desc"
                      />
                      <span className="accessibility-control-label">
                        <Contrast className="h-4 w-4" aria-hidden="true" />
                        Hoher Kontrast
                      </span>
                      <span id="high-contrast-desc" className="accessibility-control-desc">
                        Verbessert die Sichtbarkeit durch erhöhten Kontrast
                      </span>
                    </label>

                    {/* Font Size */}
                    <div className="accessibility-control">
                      <span className="accessibility-control-label">
                        <Type className="h-4 w-4" aria-hidden="true" />
                        Schriftgröße: {settings.fontSize}%
                      </span>
                      <div className="accessibility-slider-control">
                        <button
                          onClick={() => updateSetting('fontSize', Math.max(75, settings.fontSize - 25))}
                          aria-label="Schriftgröße verkleinern"
                        >
                          <Minus className="h-4 w-4" aria-hidden="true" />
                        </button>
                        <input
                          type="range"
                          min="75"
                          max="200"
                          step="25"
                          value={settings.fontSize}
                          onChange={(e) => updateSetting('fontSize', parseInt(e.target.value))}
                          aria-label="Schriftgröße"
                          className="accessibility-slider"
                        />
                        <button
                          onClick={() => updateSetting('fontSize', Math.min(200, settings.fontSize + 25))}
                          aria-label="Schriftgröße vergrößern"
                        >
                          <Plus className="h-4 w-4" aria-hidden="true" />
                        </button>
                      </div>
                    </div>

                    {/* Color Blind Friendly */}
                    <label className="accessibility-control">
                      <input
                        type="checkbox"
                        checked={settings.colorBlindFriendly}
                        onChange={(e) => updateSetting('colorBlindFriendly', e.target.checked)}
                        aria-describedby="colorblind-desc"
                      />
                      <span className="accessibility-control-label">
                        <Palette className="h-4 w-4" aria-hidden="true" />
                        Farbenblind-freundlich
                      </span>
                      <span id="colorblind-desc" className="accessibility-control-desc">
                        Angepasste Farben für Farbsehschwäche
                      </span>
                    </label>
                  </div>
                </div>

                <div className="accessibility-section">
                  <h3 className="accessibility-section-title">
                    <MousePointer className="h-4 w-4" aria-hidden="true" />
                    Navigation
                  </h3>
                  
                  <div className="accessibility-controls">
                    {/* Reduced Motion */}
                    <label className="accessibility-control">
                      <input
                        type="checkbox"
                        checked={settings.reducedMotion}
                        onChange={(e) => updateSetting('reducedMotion', e.target.checked)}
                        aria-describedby="motion-desc"
                      />
                      <span className="accessibility-control-label">
                        <EyeOff className="h-4 w-4" aria-hidden="true" />
                        Reduzierte Bewegungen
                      </span>
                      <span id="motion-desc" className="accessibility-control-desc">
                        Reduziert Animationen und Bewegungen
                      </span>
                    </label>

                    {/* Enhanced Focus */}
                    <label className="accessibility-control">
                      <input
                        type="checkbox"
                        checked={settings.focusVisible}
                        onChange={(e) => updateSetting('focusVisible', e.target.checked)}
                        aria-describedby="focus-desc"
                      />
                      <span className="accessibility-control-label">
                        <MousePointer className="h-4 w-4" aria-hidden="true" />
                        Verbesserter Fokus
                      </span>
                      <span id="focus-desc" className="accessibility-control-desc">
                        Deutlich sichtbare Fokus-Indikatoren
                      </span>
                    </label>

                    {/* Keyboard Navigation */}
                    <label className="accessibility-control">
                      <input
                        type="checkbox"
                        checked={settings.keyboardNavigation}
                        onChange={(e) => updateSetting('keyboardNavigation', e.target.checked)}
                        aria-describedby="keyboard-desc"
                      />
                      <span className="accessibility-control-label">
                        <Keyboard className="h-4 w-4" aria-hidden="true" />
                        Tastatur-Navigation
                      </span>
                      <span id="keyboard-desc" className="accessibility-control-desc">
                        Optimiert für Tastaturnutzung
                      </span>
                    </label>
                  </div>
                </div>

                <div className="accessibility-section">
                  <h3 className="accessibility-section-title">
                    <Volume2 className="h-4 w-4" aria-hidden="true" />
                    Audio & Screenreader
                  </h3>
                  
                  <div className="accessibility-controls">
                    {/* Screen Reader Mode */}
                    <label className="accessibility-control">
                      <input
                        type="checkbox"
                        checked={settings.screenReaderMode}
                        onChange={(e) => updateSetting('screenReaderMode', e.target.checked)}
                        aria-describedby="reader-desc"
                      />
                      <span className="accessibility-control-label">
                        <Volume2 className="h-4 w-4" aria-hidden="true" />
                        Screenreader-Modus
                      </span>
                      <span id="reader-desc" className="accessibility-control-desc">
                        Optimiert für Bildschirmleser
                      </span>
                    </label>

                    {/* Sound Effects */}
                    <label className="accessibility-control">
                      <input
                        type="checkbox"
                        checked={settings.soundEnabled}
                        onChange={(e) => updateSetting('soundEnabled', e.target.checked)}
                        aria-describedby="sound-desc"
                      />
                      <span className="accessibility-control-label">
                        {settings.soundEnabled ? (
                          <Volume2 className="h-4 w-4" aria-hidden="true" />
                        ) : (
                          <VolumeX className="h-4 w-4" aria-hidden="true" />
                        )}
                        Ton-Feedback
                      </span>
                      <span id="sound-desc" className="accessibility-control-desc">
                        Akustische Rückmeldungen
                      </span>
                    </label>
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="accessibility-menu-footer">
                <button
                  onClick={resetSettings}
                  className="accessibility-reset-btn"
                  aria-describedby="reset-desc"
                >
                  <RotateCcw className="h-4 w-4" aria-hidden="true" />
                  Zurücksetzen
                </button>
                <span id="reset-desc" className="accessibility-help-text">
                  Tastenkombination: Alt + A
                </span>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Screen Reader Live Region */}
      <div
        role="status"
        aria-live="polite"
        aria-atomic="true"
        className="sr-only"
        id="accessibility-announcements"
      />
    </>
  );
}

// CSS Classes (to be added to globals.css)
export const accessibilityStyles = `
/* Accessibility Enhancement Styles */
.skip-links {
  position: absolute;
  top: -1000px;
  left: 0;
  z-index: 9999;
}

.skip-link {
  position: absolute;
  top: -1000px;
  left: 6px;
  background: #000;
  color: #fff;
  padding: 8px 12px;
  text-decoration: none;
  border-radius: 4px;
  font-size: 14px;
  font-weight: 600;
  transition: all 0.3s ease;
}

.skip-link:focus,
.skip-link-visible {
  top: 6px;
  z-index: 10000;
}

.accessibility-trigger {
  position: fixed;
  bottom: 20px;
  left: 20px;
  z-index: 1000;
  background: linear-gradient(135deg, #0891b2, #06b6d4);
  color: white;
  border: none;
  border-radius: 50%;
  width: 56px;
  height: 56px;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 4px 12px rgba(6, 182, 212, 0.3);
  cursor: pointer;
  transition: all 0.3s ease;
}

.accessibility-trigger:hover {
  box-shadow: 0 6px 20px rgba(6, 182, 212, 0.4);
}

.accessibility-trigger:focus {
  outline: 3px solid #fbbf24;
  outline-offset: 2px;
}

.accessibility-backdrop {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: 9998;
}

.accessibility-menu {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background: white;
  border-radius: 12px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
  z-index: 9999;
  width: 90vw;
  max-width: 500px;
  max-height: 80vh;
  overflow: hidden;
  border: 1px solid #e5e7eb;
}

.accessibility-menu-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 20px;
  border-bottom: 1px solid #e5e7eb;
  background: #f9fafb;
}

.accessibility-menu-title {
  display: flex;
  align-items: center;
  gap: 8px;
  margin: 0;
  font-size: 18px;
  font-weight: 600;
  color: #111827;
}

.accessibility-close-btn {
  background: none;
  border: none;
  padding: 4px;
  border-radius: 4px;
  color: #6b7280;
  cursor: pointer;
  transition: all 0.2s ease;
}

.accessibility-close-btn:hover {
  background: #e5e7eb;
  color: #374151;
}

.accessibility-close-btn:focus {
  outline: 2px solid #3b82f6;
  outline-offset: 1px;
}

.accessibility-menu-content {
  padding: 20px;
  max-height: 60vh;
  overflow-y: auto;
}

.accessibility-section {
  margin-bottom: 24px;
}

.accessibility-section:last-child {
  margin-bottom: 0;
}

.accessibility-section-title {
  display: flex;
  align-items: center;
  gap: 8px;
  margin: 0 0 12px 0;
  font-size: 16px;
  font-weight: 600;
  color: #374151;
}

.accessibility-controls {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.accessibility-control {
  display: flex;
  flex-direction: column;
  gap: 4px;
  cursor: pointer;
}

.accessibility-control input[type="checkbox"] {
  margin-right: 8px;
}

.accessibility-control-label {
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 500;
  color: #374151;
}

.accessibility-control-desc {
  font-size: 14px;
  color: #6b7280;
  margin-left: 28px;
}

.accessibility-slider-control {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-top: 8px;
}

.accessibility-slider-control button {
  background: #f3f4f6;
  border: 1px solid #d1d5db;
  border-radius: 4px;
  padding: 4px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.accessibility-slider-control button:hover {
  background: #e5e7eb;
}

.accessibility-slider-control button:focus {
  outline: 2px solid #3b82f6;
  outline-offset: 1px;
}

.accessibility-slider {
  flex: 1;
  margin: 0 8px;
}

.accessibility-menu-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 20px;
  border-top: 1px solid #e5e7eb;
  background: #f9fafb;
}

.accessibility-reset-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  background: #ef4444;
  color: white;
  border: none;
  padding: 8px 16px;
  border-radius: 6px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s ease;
}

.accessibility-reset-btn:hover {
  background: #dc2626;
}

.accessibility-reset-btn:focus {
  outline: 2px solid #fbbf24;
  outline-offset: 2px;
}

.accessibility-help-text {
  font-size: 12px;
  color: #6b7280;
}

.sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border: 0;
}

/* High Contrast Mode */
.high-contrast {
  filter: contrast(150%) brightness(110%);
}

.high-contrast * {
  border-color: #000 !important;
}

.high-contrast a {
  text-decoration: underline !important;
}

/* Large Text Mode */
.large-text * {
  font-size: 120% !important;
  line-height: 1.6 !important;
}

/* Enhanced Focus */
.focus-visible-enhanced *:focus {
  outline: 3px solid #fbbf24 !important;
  outline-offset: 2px !important;
  box-shadow: 0 0 0 5px rgba(251, 191, 36, 0.3) !important;
}

/* Colorblind Friendly */
.colorblind-friendly {
  --store-green: #0891b2;
  --store-blue: #f59e0b; 
  --store-orange: #7c3aed;
}

/* Keyboard Navigation */
.keyboard-navigation *:focus {
  z-index: 9999 !important;
}

/* Reduced Motion */
.reduce-motion *,
.reduce-motion *::before,
.reduce-motion *::after {
  animation-duration: 0.01ms !important;
  animation-iteration-count: 1 !important;
  transition-duration: 0.01ms !important;
  scroll-behavior: auto !important;
}

/* Screen Reader Mode */
.screen-reader-mode .motion-safe {
  animation: none !important;
  transition: none !important;
}

.screen-reader-mode [aria-hidden="true"] {
  display: none !important;
}

@media (prefers-reduced-motion: reduce) {
  .accessibility-trigger {
    animation: none;
  }
  
  .accessibility-menu {
    transition: none !important;
  }
}
`;