/**
 * TimeoutSafeWrapper - Optimized für bessere Performance und weniger Timeouts
 * Verhindert lange Ladezeiten durch intelligente Timeout-Behandlung
 */

import React, { useState, useEffect, useRef, Suspense } from 'react';

interface TimeoutSafeWrapperProps {
  timeout?: number;
  componentName?: string;
  fallbackText?: string;
  showRetry?: boolean;
  children: React.ReactNode;
}

// Lightweight fallback component
const QuickFallback = ({ text }: { text: string }) => (
  <div className="flex items-center justify-center p-4 bg-slate-900/30 rounded-lg">
    <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-cyan-400 mr-3"></div>
    <span className="text-white/70 text-sm">{text}</span>
  </div>
);

const TimeoutSafeWrapper: React.FC<TimeoutSafeWrapperProps> = ({
  timeout = 8000, // Reduced from previous timeout
  componentName = 'Component',
  fallbackText = 'Lädt...',
  showRetry = true,
  children
}) => {
  const [hasTimedOut, setHasTimedOut] = useState(false);
  const [retryCount, setRetryCount] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const timeoutRef = useRef<NodeJS.Timeout>();
  const mountedRef = useRef(true);

  useEffect(() => {
    mountedRef.current = true;
    setHasTimedOut(false);
    setIsLoading(true);

    // Progressive timeout - start with shorter timeout, increase on retries
    const currentTimeout = timeout + (retryCount * 2000);
    
    // Clear any existing timeout
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }

    // Set new timeout
    timeoutRef.current = setTimeout(() => {
      if (mountedRef.current) {
        console.warn(`${componentName} timed out after ${currentTimeout}ms (retry ${retryCount})`);
        setHasTimedOut(true);
        setIsLoading(false);
      }
    }, currentTimeout);

    // Mark as loaded after a short delay
    const loadedTimeout = setTimeout(() => {
      if (mountedRef.current) {
        setIsLoading(false);
      }
    }, 100);

    return () => {
      mountedRef.current = false;
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
      clearTimeout(loadedTimeout);
    };
  }, [timeout, componentName, retryCount]);

  const handleRetry = () => {
    setRetryCount(prev => {
      const newCount = prev + 1;
      
      // After 3 retries, reload the entire page
      if (newCount >= 3) {
        console.warn(`${componentName} failed ${newCount} times, reloading page`);
        window.location.reload();
        return prev;
      }
      
      return newCount;
    });
  };

  // Show timeout error
  if (hasTimedOut) {
    return (
      <div className="flex items-center justify-center p-6 bg-red-900/20 rounded-lg border border-red-500/30 m-4">
        <div className="text-center">
          <div className="text-red-400 mb-3 text-xl">⏱️</div>
          <h3 className="text-white mb-2">Timeout: {componentName}</h3>
          <p className="text-white/70 text-sm mb-4">
            Komponente konnte nicht in {timeout / 1000}s geladen werden
          </p>
          
          {showRetry && (
            <div className="space-y-2">
              <button
                onClick={handleRetry}
                className="px-4 py-2 bg-cyan-500 hover:bg-cyan-600 text-white rounded-lg transition-colors text-sm"
              >
                Erneut versuchen ({retryCount}/3)
              </button>
              
              {retryCount >= 2 && (
                <div className="text-xs text-slate-400">
                  Beim nächsten Versuch wird die Seite neu geladen
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    );
  }

  // Wrap children in Suspense for better React performance
  return (
    <Suspense fallback={<QuickFallback text={fallbackText} />}>
      <div className="timeout-safe-wrapper">
        {children}
      </div>
    </Suspense>
  );
};

export default TimeoutSafeWrapper;