import React, { useEffect, useState } from 'react';
import { CheckCircle, AlertCircle, XCircle, Eye, Keyboard, Monitor } from 'lucide-react';

interface AccessibilityIssue {
  type: 'error' | 'warning' | 'info';
  category: 'contrast' | 'keyboard' | 'aria' | 'structure' | 'images';
  message: string;
  element?: string;
  suggestion: string;
  wcagLevel: 'A' | 'AA' | 'AAA';
  wcagCriterion: string;
}

interface AccessibilityValidatorProps {
  enabled?: boolean;
  showResults?: boolean;
}

export function AccessibilityValidator({ enabled = false, showResults = false }: AccessibilityValidatorProps) {
  const [issues, setIssues] = useState<AccessibilityIssue[]>([]);
  const [isValidating, setIsValidating] = useState(false);
  const [score, setScore] = useState<number>(0);

  useEffect(() => {
    if (!enabled) return;

    const validateAccessibility = async () => {
      setIsValidating(true);
      const foundIssues: AccessibilityIssue[] = [];

      try {
        // 1. Color Contrast Validation (WCAG 2.1 AA - 4.5:1 ratio)
        await validateColorContrast(foundIssues);

        // 2. Keyboard Navigation Validation
        validateKeyboardNavigation(foundIssues);

        // 3. ARIA Labels and Roles Validation
        validateAriaAttributes(foundIssues);

        // 4. Semantic Structure Validation
        validateSemanticStructure(foundIssues);

        // 5. Image Alt Text Validation
        validateImageAltText(foundIssues);

        // 6. Focus Management Validation
        validateFocusManagement(foundIssues);

        // 7. Form Accessibility Validation
        validateFormAccessibility(foundIssues);

        setIssues(foundIssues);
        
        // Calculate accessibility score
        const totalChecks = 50; // Total number of checks performed
        const errors = foundIssues.filter(issue => issue.type === 'error').length;
        const warnings = foundIssues.filter(issue => issue.type === 'warning').length;
        const calculatedScore = Math.max(0, 100 - (errors * 3) - (warnings * 1));
        setScore(calculatedScore);

      } catch (error) {
        console.error('Accessibility validation error:', error);
      } finally {
        setIsValidating(false);
      }
    };

    // Run validation after DOM is ready
    setTimeout(validateAccessibility, 1000);
  }, [enabled]);

  // Color Contrast Validation
  const validateColorContrast = async (issues: AccessibilityIssue[]) => {
    const textElements = document.querySelectorAll('p, h1, h2, h3, h4, h5, h6, a, button, span, div, label');
    
    for (const element of textElements) {
      const htmlElement = element as HTMLElement;
      if (!htmlElement.textContent?.trim()) continue;

      const styles = window.getComputedStyle(htmlElement);
      const color = styles.color;
      const backgroundColor = styles.backgroundColor;
      
      // Skip transparent backgrounds
      if (backgroundColor === 'rgba(0, 0, 0, 0)' || backgroundColor === 'transparent') continue;

      const contrastRatio = calculateContrastRatio(color, backgroundColor);
      
      if (contrastRatio < 4.5) {
        issues.push({
          type: 'error',
          category: 'contrast',
          message: `Unzureichender Farbkontrast: ${contrastRatio.toFixed(2)}:1 (erforderlich: 4.5:1)`,
          element: htmlElement.tagName.toLowerCase(),
          suggestion: 'Verwenden Sie dunklere Textfarben oder hellere Hintergründe für besseren Kontrast',
          wcagLevel: 'AA',
          wcagCriterion: '1.4.3 Contrast (Minimum)'
        });
      } else if (contrastRatio < 7) {
        issues.push({
          type: 'warning',
          category: 'contrast',
          message: `Kontrast könnte für AAA-Standard verbessert werden: ${contrastRatio.toFixed(2)}:1 (empfohlen: 7:1)`,
          element: htmlElement.tagName.toLowerCase(),
          suggestion: 'Für optimale Lesbarkeit höheren Kontrast verwenden',
          wcagLevel: 'AAA',
          wcagCriterion: '1.4.6 Contrast (Enhanced)'
        });
      }
    }
  };

  // Calculate contrast ratio between two colors
  const calculateContrastRatio = (color1: string, color2: string): number => {
    const getLuminance = (color: string): number => {
      const rgb = color.match(/\d+/g);
      if (!rgb || rgb.length < 3) return 0;
      
      const [r, g, b] = rgb.map(val => {
        const num = parseInt(val) / 255;
        return num <= 0.03928 ? num / 12.92 : Math.pow((num + 0.055) / 1.055, 2.4);
      });
      
      return 0.2126 * r + 0.7152 * g + 0.0722 * b;
    };

    const lum1 = getLuminance(color1);
    const lum2 = getLuminance(color2);
    const brightest = Math.max(lum1, lum2);
    const darkest = Math.min(lum1, lum2);
    
    return (brightest + 0.05) / (darkest + 0.05);
  };

  // Keyboard Navigation Validation
  const validateKeyboardNavigation = (issues: AccessibilityIssue[]) => {
    const interactiveElements = document.querySelectorAll('button, a, input, select, textarea, [tabindex]');
    
    interactiveElements.forEach((element) => {
      const htmlElement = element as HTMLElement;
      
      // Check if element is focusable
      const tabIndex = htmlElement.getAttribute('tabindex');
      if (tabIndex === '-1' && !['button', 'a', 'input', 'select', 'textarea'].includes(htmlElement.tagName.toLowerCase())) {
        issues.push({
          type: 'warning',
          category: 'keyboard',
          message: 'Element ist nicht per Tastatur erreichbar',
          element: htmlElement.tagName.toLowerCase(),
          suggestion: 'Entfernen Sie tabindex="-1" oder stellen Sie alternative Tastaturnavigation bereit',
          wcagLevel: 'A',
          wcagCriterion: '2.1.1 Keyboard'
        });
      }

      // Check for visible focus indicators
      const styles = window.getComputedStyle(htmlElement, ':focus');
      if (!styles.outline || styles.outline === 'none' || styles.outline === '0') {
        issues.push({
          type: 'error',
          category: 'keyboard',
          message: 'Fehlende Fokus-Indikatoren',
          element: htmlElement.tagName.toLowerCase(),
          suggestion: 'Fügen Sie sichtbare Fokus-Stile hinzu (outline, border, box-shadow)',
          wcagLevel: 'AA',
          wcagCriterion: '2.4.7 Focus Visible'
        });
      }
    });
  };

  // ARIA Attributes Validation
  const validateAriaAttributes = (issues: AccessibilityIssue[]) => {
    // Check for missing aria-labels on buttons without text
    const buttons = document.querySelectorAll('button');
    buttons.forEach((button) => {
      const hasText = button.textContent?.trim();
      const hasAriaLabel = button.getAttribute('aria-label');
      const hasAriaLabelledBy = button.getAttribute('aria-labelledby');
      
      if (!hasText && !hasAriaLabel && !hasAriaLabelledBy) {
        issues.push({
          type: 'error',
          category: 'aria',
          message: 'Button ohne zugänglichen Text',
          element: 'button',
          suggestion: 'Fügen Sie aria-label, aria-labelledby oder sichtbaren Text hinzu',
          wcagLevel: 'A',
          wcagCriterion: '4.1.2 Name, Role, Value'
        });
      }
    });

    // Check for proper heading structure
    const headings = document.querySelectorAll('h1, h2, h3, h4, h5, h6');
    let previousLevel = 0;
    
    headings.forEach((heading) => {
      const level = parseInt(heading.tagName.charAt(1));
      if (level > previousLevel + 1) {
        issues.push({
          type: 'warning',
          category: 'structure',
          message: `Überschriftenebene übersprungen: von h${previousLevel} zu h${level}`,
          element: heading.tagName.toLowerCase(),
          suggestion: 'Verwenden Sie Überschriften in logischer Reihenfolge ohne Ebenen zu überspringen',
          wcagLevel: 'AA',
          wcagCriterion: '1.3.1 Info and Relationships'
        });
      }
      previousLevel = level;
    });

    // Check for landmark roles
    const main = document.querySelector('main, [role="main"]');
    if (!main) {
      issues.push({
        type: 'error',
        category: 'structure',
        message: 'Fehlendes main-Element oder role="main"',
        element: 'page',
        suggestion: 'Fügen Sie ein <main> Element oder role="main" für den Hauptinhalt hinzu',
        wcagLevel: 'A',
        wcagCriterion: '1.3.1 Info and Relationships'
      });
    }
  };

  // Semantic Structure Validation
  const validateSemanticStructure = (issues: AccessibilityIssue[]) => {
    // Check for proper list structure
    const lists = document.querySelectorAll('ul, ol');
    lists.forEach((list) => {
      const directChildren = Array.from(list.children);
      const nonListItems = directChildren.filter(child => child.tagName !== 'LI');
      
      if (nonListItems.length > 0) {
        issues.push({
          type: 'error',
          category: 'structure',
          message: 'Liste enthält Nicht-Listen-Elemente als direkte Kinder',
          element: list.tagName.toLowerCase(),
          suggestion: 'Listen sollten nur <li> Elemente als direkte Kinder haben',
          wcagLevel: 'A',
          wcagCriterion: '1.3.1 Info and Relationships'
        });
      }
    });

    // Check for table headers
    const tables = document.querySelectorAll('table');
    tables.forEach((table) => {
      const hasHeaders = table.querySelector('th');
      if (!hasHeaders) {
        issues.push({
          type: 'warning',
          category: 'structure',
          message: 'Tabelle ohne Kopfzeilen',
          element: 'table',
          suggestion: 'Verwenden Sie <th> Elemente für Tabellenkopfzeilen',
          wcagLevel: 'A',
          wcagCriterion: '1.3.1 Info and Relationships'
        });
      }
    });
  };

  // Image Alt Text Validation
  const validateImageAltText = (issues: AccessibilityIssue[]) => {
    const images = document.querySelectorAll('img');
    images.forEach((img) => {
      const alt = img.getAttribute('alt');
      const isDecorative = alt === '';
      const hasAlt = alt !== null;
      
      if (!hasAlt) {
        issues.push({
          type: 'error',
          category: 'images',
          message: 'Bild ohne alt-Attribut',
          element: 'img',
          suggestion: 'Fügen Sie ein alt-Attribut hinzu (leer für dekorative Bilder)',
          wcagLevel: 'A',
          wcagCriterion: '1.1.1 Non-text Content'
        });
      } else if (!isDecorative && alt && alt.length < 3) {
        issues.push({
          type: 'warning',
          category: 'images',
          message: 'Alt-Text zu kurz oder nicht beschreibend',
          element: 'img',
          suggestion: 'Verwenden Sie beschreibende Alt-Texte, die den Bildinhalt erklären',
          wcagLevel: 'A',
          wcagCriterion: '1.1.1 Non-text Content'
        });
      }
    });
  };

  // Focus Management Validation
  const validateFocusManagement = (issues: AccessibilityIssue[]) => {
    // Check for skip links
    const skipLinks = document.querySelectorAll('a[href="#main"], a[href="#content"], .skip-link');
    if (skipLinks.length === 0) {
      issues.push({
        type: 'warning',
        category: 'keyboard',
        message: 'Keine Skip-Links gefunden',
        element: 'page',
        suggestion: 'Fügen Sie Skip-Links für Tastaturnutzer hinzu',
        wcagLevel: 'A',
        wcagCriterion: '2.4.1 Bypass Blocks'
      });
    }

    // Check for focus trapping in modals
    const modals = document.querySelectorAll('[role="dialog"], .modal, [aria-modal="true"]');
    modals.forEach((modal) => {
      const focusableElements = modal.querySelectorAll('button, a, input, select, textarea, [tabindex]:not([tabindex="-1"])');
      if (focusableElements.length === 0) {
        issues.push({
          type: 'error',
          category: 'keyboard',
          message: 'Modal ohne fokussierbare Elemente',
          element: 'modal',
          suggestion: 'Stellen Sie sicher, dass Modals fokussierbare Elemente enthalten',
          wcagLevel: 'AA',
          wcagCriterion: '2.4.3 Focus Order'
        });
      }
    });
  };

  // Form Accessibility Validation
  const validateFormAccessibility = (issues: AccessibilityIssue[]) => {
    const inputs = document.querySelectorAll('input, select, textarea');
    inputs.forEach((input) => {
      const htmlInput = input as HTMLInputElement;
      const hasLabel = document.querySelector(`label[for="${htmlInput.id}"]`);
      const hasAriaLabel = htmlInput.getAttribute('aria-label');
      const hasAriaLabelledBy = htmlInput.getAttribute('aria-labelledby');
      
      if (!hasLabel && !hasAriaLabel && !hasAriaLabelledBy) {
        issues.push({
          type: 'error',
          category: 'aria',
          message: 'Formularfeld ohne zugängliches Label',
          element: htmlInput.tagName.toLowerCase(),
          suggestion: 'Verknüpfen Sie jedes Formularfeld mit einem Label oder aria-label',
          wcagLevel: 'A',
          wcagCriterion: '1.3.1 Info and Relationships'
        });
      }

      // Check for required field indicators
      if (htmlInput.required && !htmlInput.getAttribute('aria-required')) {
        issues.push({
          type: 'warning',
          category: 'aria',
          message: 'Pflichtfeld ohne aria-required',
          element: htmlInput.tagName.toLowerCase(),
          suggestion: 'Fügen Sie aria-required="true" zu Pflichtfeldern hinzu',
          wcagLevel: 'A',
          wcagCriterion: '3.3.2 Labels or Instructions'
        });
      }
    });
  };

  if (!showResults) return null;

  return (
    <div className="fixed bottom-4 right-4 max-w-md bg-white rounded-lg shadow-2xl border border-gray-200 z-50">
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Eye className="w-5 h-5 text-blue-600" />
            <h3 className="font-semibold text-gray-900">WCAG 2.1 Validator</h3>
          </div>
          <div className="flex items-center gap-2">
            <div className={`w-3 h-3 rounded-full ${score >= 90 ? 'bg-green-500' : score >= 70 ? 'bg-yellow-500' : 'bg-red-500'}`} />
            <span className="text-sm font-medium text-gray-700">{score}%</span>
          </div>
        </div>
        
        {isValidating && (
          <div className="mt-2 flex items-center gap-2 text-sm text-gray-600">
            <div className="animate-spin w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full" />
            <span>Validierung läuft...</span>
          </div>
        )}
      </div>

      <div className="max-h-80 overflow-y-auto">
        {issues.length === 0 && !isValidating ? (
          <div className="p-4 text-center">
            <CheckCircle className="w-8 h-8 text-green-500 mx-auto mb-2" />
            <p className="text-sm text-gray-600">Keine kritischen Probleme gefunden!</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-200">
            {issues.map((issue, index) => (
              <div key={index} className="p-3">
                <div className="flex items-start gap-2">
                  {issue.type === 'error' ? (
                    <XCircle className="w-4 h-4 text-red-500 mt-0.5 flex-shrink-0" />
                  ) : issue.type === 'warning' ? (
                    <AlertCircle className="w-4 h-4 text-yellow-500 mt-0.5 flex-shrink-0" />
                  ) : (
                    <CheckCircle className="w-4 h-4 text-blue-500 mt-0.5 flex-shrink-0" />
                  )}
                  
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900">{issue.message}</p>
                    <p className="text-xs text-gray-600 mt-1">{issue.suggestion}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-xs bg-gray-100 text-gray-700 px-1.5 py-0.5 rounded">
                        WCAG {issue.wcagLevel}
                      </span>
                      <span className="text-xs text-gray-500">{issue.wcagCriterion}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="p-3 bg-gray-50 text-xs text-gray-600 rounded-b-lg">
        <div className="flex items-center justify-between">
          <span>EU Accessibility Act 2025 konform</span>
          <div className="flex items-center gap-2">
            <Keyboard className="w-3 h-3" />
            <Monitor className="w-3 h-3" />
            <Eye className="w-3 h-3" />
          </div>
        </div>
      </div>
    </div>
  );
}