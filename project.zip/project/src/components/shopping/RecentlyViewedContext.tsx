import { createContext, useContext, useState, ReactNode } from 'react';
const C = createContext<{ ids:string[]; push:(id:string)=>void } | null>(null);
export function RecentlyViewedProvider({ children }: { children: ReactNode }) {
  const [ids, set] = useState<string[]>([]);
  return <C.Provider value={{ ids, push:(id)=>set(x=>[id, ...x.filter(v=>v!==id)].slice(0,20)) }}>{children}</C.Provider>;
}
export const useRecentlyViewed = () => {
  const v = useContext(C);
  if (!v) throw new Error('RecentlyViewedContext missing');
  return v;
};