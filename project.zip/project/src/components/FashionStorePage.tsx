export function FashionStorePage({ onNavigate }: { onNavigate: (p:any)=>void }) {
  return (
    <section style={{padding:24}}>
      <h1>Fashion Store</h1>
      <p>Platzhalter – hier kommt die Startseite.</p>
      <button onClick={()=>onNavigate('cart')}>Zum Warenkorb</button>
    </section>
  );
}