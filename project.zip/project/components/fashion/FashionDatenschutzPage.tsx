import React from 'react';
import { ArrowLeft, Shield, Eye, Database, Cookie } from 'lucide-react';

interface FashionDatenschutzPageProps {
  onBack?: () => void;
}

export function FashionDatenschutzPage({ onBack }: FashionDatenschutzPageProps) {
  return (
    <div className="min-h-screen bg-slate-950 text-white">
      {/* Header */}
      <header className="bg-slate-900 border-b border-slate-700">
        <div className="max-w-4xl mx-auto px-6 py-8">
          {/* Back Button */}
          <button
            onClick={onBack}
            className="mb-6 flex items-center space-x-2 text-slate-300 hover:text-cyan-400 transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
            <span className="font-medium">Zurück zum Shop</span>
          </button>

          {/* Title */}
          <div className="text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-cyan-500 to-blue-600 text-white rounded-2xl mb-4">
              <Shield className="h-8 w-8" />
            </div>
            <h1 className="text-4xl font-bold text-white mb-4">
              Datenschutzerklärung
            </h1>
            <p className="text-xl text-slate-300">
              Wir nehmen den Schutz Ihrer Daten sehr ernst
            </p>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="py-16 bg-slate-950 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 pointer-events-none">
          <div className="tech-grid-minimal"></div>
        </div>
        <div className="max-w-4xl mx-auto px-6 relative z-10">
          <div className="bg-slate-900 rounded-3xl shadow-lg border border-slate-700 p-8 md:p-12">
            
            <div className="space-y-12">
              {/* Einleitung */}
              <div className="bg-slate-800 rounded-2xl p-6">
                <h2 className="text-2xl font-bold text-white mb-4">
                  Allgemeine Hinweise
                </h2>
                <p className="text-slate-300 leading-relaxed">
                  Die folgenden Hinweise geben einen einfachen Überblick darüber, was mit Ihren personenbezogenen Daten 
                  passiert, wenn Sie diese Website besuchen. Personenbezogene Daten sind alle Daten, mit denen Sie 
                  persönlich identifiziert werden können.
                </p>
              </div>

              {/* Datenerfassung */}
              <div>
                <h2 className="text-2xl font-bold text-white mb-6 pb-3 border-b-2 border-cyan-500 flex items-center">
                  <Database className="h-6 w-6 mr-3" />
                  Datenerfassung auf dieser Website
                </h2>
                
                <div className="space-y-6">
                  <div>
                    <h3 className="text-xl font-semibold text-slate-200 mb-3">
                      Wer ist verantwortlich für die Datenerfassung auf dieser Website?
                    </h3>
                    <p className="text-slate-300 leading-relaxed">
                      Die Datenverarbeitung auf dieser Website erfolgt durch den Websitebetreiber. Dessen Kontaktdaten 
                      können Sie dem Impressum dieser Website entnehmen.
                    </p>
                  </div>

                  <div>
                    <h3 className="text-xl font-semibold text-slate-200 mb-3">
                      Wie erfassen wir Ihre Daten?
                    </h3>
                    <p className="text-slate-300 leading-relaxed">
                      Ihre Daten werden zum einen dadurch erhoben, dass Sie uns diese mitteilen. Hierbei kann es sich 
                      z.B. um Daten handeln, die Sie in ein Kontaktformular eingeben.
                    </p>
                  </div>

                  <div>
                    <h3 className="text-xl font-semibold text-slate-200 mb-3">
                      Wofür nutzen wir Ihre Daten?
                    </h3>
                    <p className="text-slate-300 leading-relaxed">
                      Ein Teil der Daten wird erhoben, um eine fehlerfreie Bereitstellung der Website zu gewährleisten. 
                      Andere Daten können zur Analyse Ihres Nutzerverhaltens verwendet werden.
                    </p>
                  </div>
                </div>
              </div>

              {/* Server Log-Dateien */}
              <div>
                <h2 className="text-2xl font-bold text-white mb-6 pb-3 border-b-2 border-emerald-500 flex items-center">
                  <Eye className="h-6 w-6 mr-3" />
                  Server-Log-Dateien
                </h2>
                
                <p className="text-slate-300 leading-relaxed mb-4">
                  Der Provider der Seiten erhebt und speichert automatisch Informationen in so genannten Server-Log-Dateien, 
                  die Ihr Browser automatisch an uns übermittelt. Dies sind:
                </p>
                
                <ul className="list-disc list-inside text-slate-300 space-y-2 ml-4">
                  <li>Browsertyp und Browserversion</li>
                  <li>verwendetes Betriebssystem</li>
                  <li>Referrer URL</li>
                  <li>Hostname des zugreifenden Rechners</li>
                  <li>Uhrzeit der Serveranfrage</li>
                  <li>IP-Adresse</li>
                </ul>
                
                <p className="text-slate-300 leading-relaxed mt-4">
                  Eine Zusammenführung dieser Daten mit anderen Datenquellen wird nicht vorgenommen.
                </p>
              </div>

              {/* Cookies */}
              <div>
                <h2 className="text-2xl font-bold text-white mb-6 pb-3 border-b-2 border-orange-500 flex items-center">
                  <Cookie className="h-6 w-6 mr-3" />
                  Cookies
                </h2>
                
                <div className="bg-slate-800 rounded-2xl p-6 mb-6">
                  <h3 className="text-xl font-semibold text-slate-200 mb-3">
                    Was sind Cookies?
                  </h3>
                  <p className="text-slate-300 leading-relaxed">
                    Die Internetseiten verwenden teilweise so genannte Cookies. Cookies richten auf Ihrem Rechner keinen 
                    Schaden an und enthalten keine Viren. Cookies dienen dazu, unser Angebot nutzerfreundlicher, 
                    effektiver und sicherer zu machen.
                  </p>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div className="bg-slate-800 border border-slate-600 rounded-xl p-6">
                    <h4 className="font-semibold text-slate-200 mb-3">Technische Cookies</h4>
                    <p className="text-slate-300 text-sm">
                      Notwendig für die Funktion der Website und können nicht deaktiviert werden.
                    </p>
                  </div>
                  
                  <div className="bg-slate-800 border border-slate-600 rounded-xl p-6">
                    <h4 className="font-semibold text-slate-200 mb-3">Funktionale Cookies</h4>
                    <p className="text-slate-300 text-sm">
                      Speichern Ihre Einstellungen und Präferenzen für eine bessere Nutzererfahrung.
                    </p>
                  </div>
                </div>
              </div>

              {/* Kontakt & Newsletter */}
              <div>
                <h2 className="text-2xl font-bold text-white mb-6 pb-3 border-b-2 border-purple-500">
                  Kontaktformular & Newsletter
                </h2>
                
                <div className="space-y-6">
                  <div>
                    <h3 className="text-xl font-semibold text-slate-200 mb-3">
                      Kontaktformular
                    </h3>
                    <p className="text-slate-300 leading-relaxed">
                      Wenn Sie uns per Kontaktformular Anfragen zukommen lassen, werden Ihre Angaben aus dem 
                      Anfrageformular inklusive der von Ihnen dort angegebenen Kontaktdaten zwecks Bearbeitung 
                      der Anfrage und für den Fall von Anschlussfragen bei uns gespeichert.
                    </p>
                  </div>

                  <div>
                    <h3 className="text-xl font-semibold text-slate-200 mb-3">
                      Newsletter-Daten
                    </h3>
                    <p className="text-slate-300 leading-relaxed">
                      Wenn Sie den auf der Website angebotenen Newsletter beziehen möchten, benötigen wir von Ihnen 
                      eine E-Mail-Adresse sowie Informationen, welche uns die Überprüfung gestatten, dass Sie der 
                      Inhaber der angegebenen E-Mail-Adresse sind.
                    </p>
                  </div>
                </div>
              </div>

              {/* Ihre Rechte */}
              <div className="bg-slate-800 rounded-2xl p-8">
                <h2 className="text-2xl font-bold text-white mb-6">
                  Ihre Rechte
                </h2>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-lg font-semibold text-slate-200 mb-2">Auskunftsrecht</h3>
                    <p className="text-slate-300 text-sm">
                      Sie haben das Recht, Auskunft über Ihre bei uns gespeicherten personenbezogenen Daten zu erhalten.
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-semibold text-slate-200 mb-2">Berichtigungsrecht</h3>
                    <p className="text-slate-300 text-sm">
                      Sie haben das Recht, unvollständige oder unrichtige Daten korrigieren zu lassen.
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-semibold text-slate-200 mb-2">Löschungsrecht</h3>
                    <p className="text-slate-300 text-sm">
                      Sie können die Löschung Ihrer bei uns gespeicherten Daten verlangen.
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-semibold text-slate-200 mb-2">Widerspruchsrecht</h3>
                    <p className="text-slate-300 text-sm">
                      Sie können der Verarbeitung Ihrer Daten zu Werbezwecken widersprechen.
                    </p>
                  </div>
                </div>
              </div>

              {/* Kontakt für Datenschutz */}
              <div className="bg-slate-800 rounded-2xl p-6">
                <h3 className="text-xl font-semibold text-slate-200 mb-3">
                  Fragen zum Datenschutz?
                </h3>
                <p className="text-slate-300 leading-relaxed">
                  Bei Fragen zum Datenschutz können Sie sich jederzeit an uns wenden:<br />
                  <strong>E-Mail:</strong> info@nexuno.eu<br />
                  <strong>Telefon:</strong> +49 30 12345678
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default FashionDatenschutzPage;