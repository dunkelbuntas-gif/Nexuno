import React, { useState } from 'react';
import { Filter, X, ChevronDown, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { PRODUCT_CATEGORIES, ProductCategory } from '../../src/lib/api';

export interface FilterOptions {
  categories: ProductCategory[];
  priceRange: { min: number; max: number };
  sortBy: 'newest' | 'price-low' | 'price-high' | 'popular' | 'name';
  availability: 'all' | 'in-stock' | 'out-of-stock';
}

interface AdvancedFiltersProps {
  filters: FilterOptions;
  onFiltersChange: (filters: FilterOptions) => void;
  isOpen: boolean;
  onToggle: () => void;
}

export function AdvancedFilters({ 
  filters, 
  onFiltersChange, 
  isOpen, 
  onToggle 
}: AdvancedFiltersProps) {
  const [localFilters, setLocalFilters] = useState<FilterOptions>(filters);

  const applyFilters = () => {
    onFiltersChange(localFilters);
    onToggle();
  };

  const resetFilters = () => {
    const defaultFilters: FilterOptions = {
      categories: [],
      priceRange: { min: 0, max: 100 },
      sortBy: 'newest',
      availability: 'all'
    };
    setLocalFilters(defaultFilters);
    onFiltersChange(defaultFilters);
  };

  const toggleCategory = (category: ProductCategory) => {
    setLocalFilters(prev => ({
      ...prev,
      categories: prev.categories.includes(category)
        ? prev.categories.filter(c => c !== category)
        : [...prev.categories, category]
    }));
  };

  const hasActiveFilters = 
    localFilters.categories.length > 0 || 
    localFilters.priceRange.min > 0 || 
    localFilters.priceRange.max < 100 ||
    localFilters.availability !== 'all' ||
    localFilters.sortBy !== 'newest';

  return (
    <div className="relative">
      {/* Filter Toggle Button */}
      <motion.button
        onClick={onToggle}
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        className={`
          flex items-center gap-2 px-4 py-2 rounded-lg border font-medium transition-all duration-200
          ${isOpen 
            ? 'bg-cyan-50 border-cyan-200 text-cyan-700' 
            : 'bg-white border-slate-200 text-slate-700 hover:border-cyan-200 hover:text-cyan-600'
          }
        `}
      >
        <Filter className="w-4 h-4" />
        Filter
        {hasActiveFilters && (
          <span className="w-2 h-2 bg-cyan-500 rounded-full"></span>
        )}
        <ChevronDown className={`w-4 h-4 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </motion.button>

      {/* Filter Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className="absolute top-full left-0 mt-2 w-80 bg-white rounded-xl border border-slate-200 shadow-xl z-40"
          >
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-slate-900">Filter</h3>
                <button
                  onClick={onToggle}
                  className="p-1 text-slate-400 hover:text-slate-600 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-6">
                {/* Categories */}
                <div>
                  <h4 className="text-sm font-medium text-slate-900 mb-3">Kategorien</h4>
                  <div className="space-y-2">
                    {Object.entries(PRODUCT_CATEGORIES).map(([key, category]) => (
                      <label
                        key={key}
                        className="flex items-center gap-3 cursor-pointer group"
                      >
                        <div className="relative">
                          <input
                            type="checkbox"
                            checked={localFilters.categories.includes(key as ProductCategory)}
                            onChange={() => toggleCategory(key as ProductCategory)}
                            className="sr-only"
                          />
                          <div className={`
                            w-4 h-4 rounded border-2 flex items-center justify-center transition-all duration-200
                            ${localFilters.categories.includes(key as ProductCategory)
                              ? 'bg-cyan-500 border-cyan-500' 
                              : 'border-slate-300 group-hover:border-cyan-400'
                            }
                          `}>
                            {localFilters.categories.includes(key as ProductCategory) && (
                              <Check className="w-3 h-3 text-white" />
                            )}
                          </div>
                        </div>
                        <span className="text-sm text-slate-700 group-hover:text-slate-900">
                          {category.name}
                        </span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Price Range */}
                <div>
                  <h4 className="text-sm font-medium text-slate-900 mb-3">Preisspanne</h4>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <input
                        type="number"
                        value={localFilters.priceRange.min}
                        onChange={(e) => setLocalFilters(prev => ({
                          ...prev,
                          priceRange: { ...prev.priceRange, min: Number(e.target.value) }
                        }))}
                        className="w-20 px-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
                        placeholder="Min"
                      />
                      <span className="text-slate-400">–</span>
                      <input
                        type="number"
                        value={localFilters.priceRange.max}
                        onChange={(e) => setLocalFilters(prev => ({
                          ...prev,
                          priceRange: { ...prev.priceRange, max: Number(e.target.value) }
                        }))}
                        className="w-20 px-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
                        placeholder="Max"
                      />
                      <span className="text-sm text-slate-500">€</span>
                    </div>
                  </div>
                </div>

                {/* Sort By */}
                <div>
                  <h4 className="text-sm font-medium text-slate-900 mb-3">Sortieren nach</h4>
                  <select
                    value={localFilters.sortBy}
                    onChange={(e) => setLocalFilters(prev => ({
                      ...prev,
                      sortBy: e.target.value as FilterOptions['sortBy']
                    }))}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
                  >
                    <option value="newest">Neueste zuerst</option>
                    <option value="price-low">Preis: Niedrig → Hoch</option>
                    <option value="price-high">Preis: Hoch → Niedrig</option>
                    <option value="popular">Beliebtheit</option>
                    <option value="name">Name A-Z</option>
                  </select>
                </div>

                {/* Availability */}
                <div>
                  <h4 className="text-sm font-medium text-slate-900 mb-3">Verfügbarkeit</h4>
                  <div className="space-y-2">
                    {[
                      { value: 'all', label: 'Alle Artikel' },
                      { value: 'in-stock', label: 'Auf Lager' },
                      { value: 'out-of-stock', label: 'Nicht verfügbar' }
                    ].map((option) => (
                      <label key={option.value} className="flex items-center gap-3 cursor-pointer group">
                        <div className="relative">
                          <input
                            type="radio"
                            name="availability"
                            value={option.value}
                            checked={localFilters.availability === option.value}
                            onChange={(e) => setLocalFilters(prev => ({
                              ...prev,
                              availability: e.target.value as FilterOptions['availability']
                            }))}
                            className="sr-only"
                          />
                          <div className={`
                            w-4 h-4 rounded-full border-2 flex items-center justify-center transition-all duration-200
                            ${localFilters.availability === option.value
                              ? 'bg-cyan-500 border-cyan-500' 
                              : 'border-slate-300 group-hover:border-cyan-400'
                            }
                          `}>
                            {localFilters.availability === option.value && (
                              <div className="w-2 h-2 bg-white rounded-full"></div>
                            )}
                          </div>
                        </div>
                        <span className="text-sm text-slate-700 group-hover:text-slate-900">
                          {option.label}
                        </span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-3 mt-6 pt-6 border-t border-slate-200">
                <button
                  onClick={resetFilters}
                  className="flex-1 px-4 py-2 text-sm font-medium text-slate-600 bg-slate-100 rounded-lg hover:bg-slate-200 transition-colors"
                >
                  Zurücksetzen
                </button>
                <button
                  onClick={applyFilters}
                  className="flex-1 px-4 py-2 text-sm font-medium text-white bg-gradient-to-r from-cyan-500 to-teal-600 rounded-lg hover:from-cyan-600 hover:to-teal-700 transition-all duration-200"
                >
                  Filter anwenden
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}